// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TPeer.cs" company="Exit Games GmbH">
//   Protocol & Photon Client Lib - Copyright (C) 2010 Exit Games GmbH
// </copyright>
// <summary>
//   Implementation of a TCP-using peer for Photon.
// </summary>
// <author>developer@photonengine.com</author>
// --------------------------------------------------------------------------------------------------------------------

namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    internal class TPeer : PeerBase
    {
        #region Fields & Properties

        /// <summary>TCP "Package" header: 7 bytes</summary>
        internal const int TCP_HEADER_BYTES = 7;

        /// <summary>TCP "Message" header: 2 bytes</summary>
        internal const int MSG_HEADER_BYTES = 2;

        /// <summary>TCP header combined: 9 bytes</summary>
        public const int ALL_HEADER_BYTES = TCP_HEADER_BYTES + MSG_HEADER_BYTES;

        internal override int QueuedIncomingCommandsCount
        {
            get
            {
                return this.incomingList.Count;
            }
        }

        internal override int QueuedOutgoingCommandsCount
        {
            get
            {
                return this.outgoingCommandsInStream;
            }
        }

        private Queue<byte[]> incomingList = new Queue<byte[]>(32);
        internal List<byte[]> outgoingStream;


        private int lastPingResult;
        private byte[] pingRequest = { 0xF0, 0, 0, 0, 0 };

        internal static readonly byte[] tcpFramedMessageHead = new byte[] { 0xFB, 0, 0, 0, 0, 0, 0, 0xF3, 2 };  // TCP framing is done with these bytes. includes: tcpMsgHead
        internal static readonly byte[] tcpMsgHead = new byte[] { 0xF3, 2 };                                    // TCP photon messages begin with this

        internal byte[] messageHeader;

        /// <summary>Defines if the (TCP) socket implementation needs to do "framing".</summary>
        /// <remarks>The WebSocket protocol (e.g.) includes framing, so when that is used, we set DoFraming to false.</remarks>
        internal protected bool DoFraming = true;

        #endregion

        // ------------------------------------------------------------------------------------------------------------------

        internal TPeer()
        {
            peerCount++;
            this.InitOnce();
            this.TrafficPackageHeaderSize = 0; //Note: There is no per-package header in TCP. In UDP this is: NCommand.HEADER_UDP_PACK_LENGTH
        }

        internal TPeer(IPhotonPeerListener listener) : this()
        {
            // the check that the listener is non-null is done in PhotonPeer (where this is created)
            this.Listener = listener;
        }

        internal override void InitPeerBase()
        {
            base.InitPeerBase();
            this.incomingList = new Queue<byte[]>(32);
        }

#if SDK_V4
        internal override bool Connect(string serverAddress, string appID, object customData)
        {
            if (peerConnectionState != ConnectionStateValue.Disconnected)
            {
                this.Listener.DebugReturn(DebugLevel.WARNING, "Connect() can't be called if peer is not Disconnected. Not connecting.");
                return false;
            }

            if (debugOut >= DebugLevel.ALL)
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "Connect()");
            }

            this.ServerAddress = serverAddress;
            this.InitPeerBase();

            outgoingStream = new List<byte[]>();

            // the RealtimeServer can run multiple applications (by name/applicationName) - the default is called "LoadBalancing"
            if (appID == null)
            {
                appID = "LoadBalancing";
            }

#if NoSocket
            this.rt = null; // TODO: add native TCP socket?
#elif (NETFX_CORE || WINDOWS_PHONE)
            this.rt = new SocketTcpNetFxCore(this);
#else

            if (SocketImplementation != null)
            {
                // TODO: this should not be hardcoded. clean this up when the proof of concept phase is done
                rt = (IPhotonSocket)Activator.CreateInstance(SocketImplementation, this);
            }

            if (this.rt == null)
            {
                this.rt = new SocketTcp(this);
            }
#endif

            if (this.rt == null)
            {
                this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() failed, because SocketImplementation or socket was null. Set PhotonPeer.SocketImplementation before Connect().");
                return false;
            }


            // messageHeader might be framed or non-framed (e.g. websockets do their own framing)
            this.messageHeader = (this.DoFraming) ? tcpFramedMessageHead : tcpMsgHead;


            // the connection itself is created and started in the thread
            if (this.rt.Connect())
            {
                peerConnectionState = ConnectionStateValue.Connecting;


                byte[] data = PrepareConnectData(rt.ServerAddress, appID, customData);
                this.EnqueueInit2(data);
                this.SendOutgoingCommands();

                // moved the connect command to the run() thread, as the MTU is not available otherwise!
                // queueOutgoingReliableCommand(  new NCommand(this, NCommand.CT_CONNECT, null)  );
                return true;
            }

            peerConnectionState = ConnectionStateValue.Disconnected;
            return false;
        }
#endif//SDK_V4

        internal override bool Connect(string serverAddress, string appID)
        {
            if (peerConnectionState != ConnectionStateValue.Disconnected)
            {
                this.Listener.DebugReturn(DebugLevel.WARNING, "Connect() can't be called if peer is not Disconnected. Not connecting.");
                return false;
            }

            if (debugOut >= DebugLevel.ALL)
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "Connect()");
            }

            this.ServerAddress = serverAddress;
            this.InitPeerBase();

            outgoingStream = new List<byte[]>();

            // the RealtimeServer can run multiple applications (by name/applicationName) - the default is called "LoadBalancing"
            if (appID == null)
            {
                appID = "LoadBalancing";
            }
            for (int i = 0; i < 32; i++)
            {
                INIT_BYTES[i + 9] = (i < appID.Length) ? (byte) appID[i] : (byte) 0;
            }

#if NoSocket

            if (SocketImplementation != null)
            {
                // TODO: this should not be hardcoded. clean this up when the proof of concept phase is done
                try
                {
                    rt = (IPhotonSocket)Activator.CreateInstance(SocketImplementation, this);
                }
                catch (Exception e)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "CreateInstance() failed: " + e);
                }
            }
            //this.rt = null; // TODO: add native TCP socket?
#elif (NETFX_CORE || WINDOWS_PHONE)
            this.rt = new SocketTcpNetFxCore(this);
#else

            if (SocketImplementation != null)
            {
                // TODO: this should not be hardcoded. clean this up when the proof of concept phase is done
                rt = (IPhotonSocket)Activator.CreateInstance(SocketImplementation, this);
            }
            else
            {
                this.rt = new SocketTcp(this);
            }
#endif

            if (this.rt == null)
            {
                this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() failed, because SocketImplementation or socket was null. Set PhotonPeer.SocketImplementation before Connect(). SocketImplementation: " + this.SocketImplementation);
                return false;
            }


            // messageHeader might be framed or non-framed (e.g. websockets do their own framing)
            this.messageHeader = (this.DoFraming) ? tcpFramedMessageHead : tcpMsgHead;


            // the connection itself is created and started in the thread
            if (this.rt.Connect())
            {
                peerConnectionState = ConnectionStateValue.Connecting;

                this.EnqueueInit();
                this.SendOutgoingCommands();

                // moved the connect command to the run() thread, as the MTU is not available otherwise!
                // queueOutgoingReliableCommand(  new NCommand(this, NCommand.CT_CONNECT, null)  );
                return true;
            }

            peerConnectionState = ConnectionStateValue.Disconnected;
            return false;
        }

        internal override void Disconnect()
        {
            if (this.peerConnectionState == ConnectionStateValue.Disconnected || this.peerConnectionState == ConnectionStateValue.Disconnecting)
            {
                return;
            }

            if (this.debugOut >= DebugLevel.ALL)
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "TPeer.Disconnect()");
            }

            // destroy self by stopping the connection thread. functionality moved to a method.
            this.StopConnection();
        }

        internal override void StopConnection()
        {
            this.peerConnectionState = ConnectionStateValue.Disconnecting;
            if (this.rt != null)
            {
                this.rt.Disconnect();
            }

            lock (this.incomingList)
            {
                this.incomingList.Clear();
            }
            peerConnectionState = ConnectionStateValue.Disconnected;
            this.Listener.OnStatusChanged(StatusCode.Disconnect);
        }

        internal override void FetchServerTimestamp()
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.INFO)
                {
                    this.Listener.DebugReturn(DebugLevel.INFO, "FetchServerTimestamp() was skipped, as the client is not connected. Current ConnectionState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return;
            }

            // fetching the timestamp is done by ping in TCP implementation
            this.SendPing();

            // serverTimestampOffset is only updated when it's unavailable (means it's off by same value all the time)
            this.serverTimeOffsetIsAvailable = false;
        }

        private void EnqueueInit()
        {
            if (!this.DoFraming) return;

            MemoryStream bout = new MemoryStream(0);
            BinaryWriter bsw = new BinaryWriter(bout);

            // write init header + application name to connect to
            var tcpheader = new byte[] { 0xFB, 0, 0, 0, 0, 0, 1 };
            //SupportClass.NumberToByteArray(tcpheader, 1, INIT_BYTES.Length + tcpheader.Length); // write length

            // write length from index 1 on (4 bytes)
            int offsetForLength = 1;
            Protocol.Serialize((int)INIT_BYTES.Length + tcpheader.Length, tcpheader, ref offsetForLength);

            bsw.Write(tcpheader);
            bsw.Write(INIT_BYTES);
            byte[] init = bout.ToArray();

            if (this.TrafficStatsEnabled)
            {
                this.TrafficStatsOutgoing.TotalPacketCount++;
                this.TrafficStatsOutgoing.TotalCommandsInPackets++;
                this.TrafficStatsOutgoing.CountControlCommand(init.Length);
            }

            this.EnqueueMessageAsPayload(true, init, 0);
        }

#if SDK_V4
        private void EnqueueInit2(byte[] data)
        {
            if (!this.DoFraming)
            {
                return;
            }

            var bout = new MemoryStream(data.Length + 32);
            var bsw = new BinaryWriter(bout);

            // write init header + application name to connect to
            var tcpheader = new byte[] { 0xFB, 0, 0, 0, 0, 0, 1 };
            //SupportClass.NumberToByteArray(tcpheader, 1, INIT_BYTES.Length + tcpheader.Length); // write length

            // write length from index 1 on (4 bytes)
            var offsetForLength = 1;
            Protocol.Serialize(data.Length + tcpheader.Length, tcpheader, ref offsetForLength);

            bsw.Write(tcpheader);
            bsw.Write(data);
            var init = bout.ToArray();

            if (this.TrafficStatsEnabled)
            {
                this.TrafficStatsOutgoing.TotalPacketCount++;
                this.TrafficStatsOutgoing.TotalCommandsInPackets++;
                this.TrafficStatsOutgoing.CountControlCommand(init.Length);
            }

            this.EnqueueMessageAsPayload(true, init, 0);
        }
#endif//SDK_V4

        /// <summary>
        /// Checks the incoming queue and Dispatches received data if possible. Returns if a Dispatch happened or
        /// not, which shows if more Dispatches might be needed.
        /// </summary>
        internal override bool DispatchIncomingCommands()
        {
            // dispatch action queue keeping the lock minimal (this is done intentionally)
            MyAction action;
            while (true)
            {
                lock (this.ActionQueue)
                {
                    if (this.ActionQueue.Count <= 0) { break; }
                    action = this.ActionQueue.Dequeue();
                }

                action();
            }

            // dispatch commands
            byte[] payload;
            lock (this.incomingList)
            {
                if (this.incomingList.Count <= 0)
                {
                    return false;
                }

                payload = (byte[]) this.incomingList.Dequeue();
            }

            this.ByteCountCurrentDispatch = payload.Length + 3; // count in the EG-TCP-Header of 3 bytes
            return this.DeserializeMessageAndCallback(payload); // either calls eventAction() OR OnStatusChanged() - return: success
        }

        /// <summary>
        /// gathers commands from all (out)queues until udp-packet is full and sends it!
        /// </summary>
        internal override bool SendOutgoingCommands()
        {
            if (this.peerConnectionState == ConnectionStateValue.Disconnected)
            {
                return false;
            }

            if (!this.rt.Connected)
            {
                return false;
            }

            this.timeInt = SupportClass.GetTickCount() - this.timeBase;
            this.timeLastSendOutgoing = this.timeInt;

            // Check timeout for Ping and enqueue/send one if needed
            if (this.peerConnectionState == ConnectionStateValue.Connected && SupportClass.GetTickCount() - this.lastPingResult > this.timePingInterval)
            {
                this.SendPing();
            }

            lock (this.outgoingStream)
            {
                foreach (var msg in this.outgoingStream)
                {
                    this.SendData(msg);
                }
                this.outgoingStream.Clear();
                this.outgoingCommandsInStream = 0;
            }

            return false;
        }

        /// <summary>Sends a ping in intervals to keep connection alive (server will timeout connection if nothing is sent).</summary>
        /// <returns>Always false in this case (local queues are ignored. true would be: "call again to send remaining data").</returns>
        internal override bool SendAcksOnly()
        {
            if (this.rt == null || !this.rt.Connected)
            {
                return false;
            }

            this.timeInt = SupportClass.GetTickCount() - this.timeBase;
            this.timeLastSendOutgoing = this.timeInt;

            // Check timeout for Ping and enqueue/send one if needed
            if (this.peerConnectionState == ConnectionStateValue.Connected && SupportClass.GetTickCount() - this.lastPingResult > this.timePingInterval)
            {
                this.SendPing();
            }

            return false;
        }

        internal override bool EnqueueOperation(Dictionary<byte, object> parameters, byte opCode, bool sendReliable, byte channelId, bool encrypt, EgMessageType messageType)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: " + opCode + "! Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            if (channelId >= this.ChannelCount)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Selected channel (" + channelId + ")>= channelCount (" + this.ChannelCount + ").");
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            byte[] opBytes = this.SerializeOperationToMessage(opCode, parameters, messageType, encrypt);
            // serialiseOperation() increments the invocID by 1 after the assigning one to this op
            return this.EnqueueMessageAsPayload(sendReliable, opBytes, channelId); // send() does takes account of the now "too high" invocID or returns -1
        }

#if SDK_V4
        internal override bool EnqueueMessage(object msg, bool sendReliable, byte channelId, bool encrypt)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send message! Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            if (channelId >= this.ChannelCount)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Selected channel (" + channelId + ")>= channelCount (" + this.ChannelCount + ").");
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            byte[] opBytes = this.SerializeMessageToMessage(msg, encrypt, messageHeader);
            // serialiseOperation() increments the invocID by 1 after the assigning one to this op
            return this.EnqueueMessageAsPayload(sendReliable, opBytes, channelId); // send() does takes account of the now "too high" invocID or returns -1
        }

        internal override bool EnqueueRawMessage(byte[] data, bool sendReliable, byte channelId, bool encrypt)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send message! Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            if (channelId >= this.ChannelCount)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Selected channel (" + channelId + ")>= channelCount (" + this.ChannelCount + ").");
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            byte[] opBytes = this.SerializeRawMessageToMessage(data, encrypt, messageHeader);
            // serialiseOperation() increments the invocID by 1 after the assigning one to this op
            return this.EnqueueMessageAsPayload(sendReliable, opBytes, channelId); // send() does takes account of the now "too high" invocID or returns -1
        }
#endif//SDK_V4


        /// <summary> Returns the UDP Payload starting with Magic Number for binary protocol </summary>
        internal override byte[] SerializeOperationToMessage(byte opc, Dictionary<byte, object> parameters, EgMessageType messageType, bool encrypt)
        {
            byte[] fullMessageBytes;

            lock (this.SerializeMemStream)
            {
                // re-set the mem stream for next message and op (in message)
                this.SerializeMemStream.Position = 0;
                this.SerializeMemStream.SetLength(0);

                // write (prelimiary) message header (might be changed later on, due to encryption, etc)
                if (!encrypt)
                {
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                }

                // write bytes of op to memstream
                Protocol.SerializeOperationRequest(this.SerializeMemStream, opc, parameters, false);

                // if we encrypt, the message header was left out, as we encrypt only the operation bytes
                if (encrypt)
                {
                    byte[] opBytes = this.SerializeMemStream.ToArray();
                    opBytes = this.CryptoProvider.Encrypt(opBytes);

                    this.SerializeMemStream.Position = 0;
                    this.SerializeMemStream.SetLength(0);
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                    this.SerializeMemStream.Write(opBytes, 0, opBytes.Length);
                }

                fullMessageBytes = this.SerializeMemStream.ToArray();
            }

            // now update the message header according to type
            if (messageType != EgMessageType.Operation)
            {
                fullMessageBytes[messageHeader.Length - 1] = (byte)messageType;
            }

            if (encrypt)
            {
                fullMessageBytes[messageHeader.Length - 1] = (byte)(fullMessageBytes[messageHeader.Length - 1] | 0x80);
            }

            if (this.DoFraming)
            {
                // update length in tcp header. it's at position 1 (to 4)
                int offsetForLength = 1;
                Protocol.Serialize((int)fullMessageBytes.Length, fullMessageBytes, ref offsetForLength);
            }

            return fullMessageBytes;
        }

        /// <summary>enqueues serialized operations to be sent as tcp stream / package</summary>
        internal bool EnqueueMessageAsPayload(bool sendReliable, byte[] opMessage, byte channelId)
        {
            if (opMessage == null)
            {
                return false;
            }

            if (this.DoFraming)
            {
                // with our own framing, we have channelID and reliability. this needs to be filled in now.
                opMessage[5] = channelId;                            // the channelId (not part of the OP)
                opMessage[6] = sendReliable ? (byte)1 : (byte)0;     // reliable or not in rUDP (default: 0 = unreliable)
            }

            // enqueue and warn if queue is a multiple of commandBufferSize
            lock (this.outgoingStream)
            {
                this.outgoingStream.Add(opMessage);          // write operation
                this.outgoingCommandsInStream++;

                if (this.outgoingCommandsInStream % this.warningSize == 0)
                {
                    this.Listener.OnStatusChanged(StatusCode.QueueOutgoingReliableWarning);
                }
            }

            int payloadByteCount = opMessage.Length;
            this.ByteCountLastOperation = payloadByteCount;
            if (this.TrafficStatsEnabled)
            {
                if (sendReliable)
                {
                    this.TrafficStatsOutgoing.CountReliableOpCommand(payloadByteCount);
                }
                else
                {
                    this.TrafficStatsOutgoing.CountUnreliableOpCommand(payloadByteCount);
                }

                this.TrafficStatsGameLevel.CountOperation(payloadByteCount);
            }

            return true;
        }

        //------------------------------------------------------------------------------------------------------------------

        /// <summary>Sends a ping and modifies this.lastPingResult to avoid another ping for a while.</summary>
        internal void SendPing()
        {
            this.lastPingResult = SupportClass.GetTickCount(); // prevents sending another ping immediately

            if (!this.DoFraming)
            {
                // without framing, we don't have to use an operation to fetch the timestamp.
                Int32 timestamp = SupportClass.GetTickCount();
                this.EnqueueOperation(new Dictionary<byte, object> { { 1, timestamp } }, PhotonCodes.Ping, true, 0, false, EgMessageType.InternalOperationRequest);
            }
            else
            {
                // with framing, we send a special byte-sequence to fetch a timestamp
                int offset = 1;
                Protocol.Serialize(SupportClass.GetTickCount(), this.pingRequest, ref offset);

                if (this.TrafficStatsEnabled)
                {
                    this.TrafficStatsOutgoing.CountControlCommand(this.pingRequest.Length);
                }

                this.SendData(this.pingRequest);
            }
        }

        internal void SendData(byte[] data)
        {
            try
            {
                this.bytesOut += data.Length;
                if (this.TrafficStatsEnabled)
                {
                    this.TrafficStatsOutgoing.TotalPacketCount++;
                    this.TrafficStatsOutgoing.TotalCommandsInPackets += this.outgoingCommandsInStream;
                }

                #if DEBUG
                if (NetworkSimulationSettings.IsSimulationEnabled)
                {
                    this.SendNetworkSimulated(delegate { this.rt.Send(data, data.Length); });
                }
                else
                {
                    this.rt.Send(data, data.Length);
                }
                #else
                this.rt.Send(data, data.Length);
                #endif
            }
            catch (Exception ex)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, ex.ToString());
                }

                SupportClass.WriteStackTrace(ex);
            }
        }

        // ------------------------------------------------------------------------------------------------------------------

        //------------------------------------------------------------------------------------------------------------------

        /// <summary>reads incoming tcp-packages to create and queue incoming commands*</summary>
        internal override void ReceiveIncomingCommands(byte[] inbuff, int dataLength)
        {
            // NOTE: in this method, we don't know anymore if something was reliable/unreliable or in which channel it came

            if (inbuff == null)
            {
                // NOTE: WIP: trying to find cause of nullref issue
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.EnqueueDebugReturn(DebugLevel.ERROR, "checkAndQueueIncomingCommands() inBuff: null");
                }
                return;
            }

            this.timestampOfLastReceive = SupportClass.GetTickCount();

            this.timeInt = SupportClass.GetTickCount() - this.timeBase;
            this.timeLastSendOutgoing = this.timeInt;

            // our TCP message header got removed before this method was called. add those bytes to the count
            this.bytesIn += inbuff.Length + TCP_HEADER_BYTES;
            if (this.TrafficStatsEnabled)
            {
                this.TrafficStatsIncoming.TotalPacketCount++;
                this.TrafficStatsIncoming.TotalCommandsInPackets++;
            }

            if (inbuff[0] == 0xF3 || inbuff[0] == 0xF4)
            {
                lock (this.incomingList)
                {
                    // enqueue and warn if queue is a multiple of commandBufferSize
                    this.incomingList.Enqueue(inbuff);

                    if (this.incomingList.Count % warningSize == 0)
                    {
                        this.EnqueueStatusCallback(StatusCode.QueueIncomingReliableWarning);
                    }
                }
            }
            else if (inbuff[0] == 0xF0)
            {
                // its a ping-result (timestamp). get and use it
                TrafficStatsIncoming.CountControlCommand(inbuff.Length);
                this.ReadPingResult(inbuff);
            }
            else if (debugOut >= DebugLevel.ERROR)
            {
                this.EnqueueDebugReturn(DebugLevel.ERROR, "receiveIncomingCommands() MagicNumber should be 0xF0, 0xF3 or 0xF4. Is: " + inbuff[0]);
            }
        }

        private void ReadPingResult(byte[] inbuff)
        {
            int serverSentTime = 0;
            int clientSentTime = 0;
            int offset = 1;
            Protocol.Deserialize(out serverSentTime, inbuff, ref offset);
            Protocol.Deserialize(out clientSentTime, inbuff, ref offset);

            //Listener.DebugReturn(String.Format("inbuff: {0} serverSentTime: {1} clientSentTime: {2}", BitConverter.ToString(inbuff), serverSentTime, clientSentTime));

            lastRoundTripTime = SupportClass.GetTickCount() - clientSentTime;
            if (!serverTimeOffsetIsAvailable)
            {
                roundTripTime = lastRoundTripTime;
            }
            this.UpdateRoundTripTimeAndVariance(lastRoundTripTime);

            if (!serverTimeOffsetIsAvailable)
            {
                serverTimeOffset = serverSentTime + (lastRoundTripTime >> 1) - SupportClass.GetTickCount();
                serverTimeOffsetIsAvailable = true;
            }
        }

        internal protected void ReadPingResult(OperationResponse operationResponse)
        {
            int serverSentTime = (int)operationResponse.Parameters[(byte)2];
            int clientSentTime = (int)operationResponse.Parameters[(byte)1];

            // this.Listener.DebugReturn(DebugLevel.ERROR, operationResponse.ToStringFull() + " " + this.lastPingResult);
            // this.Listener.DebugReturn(DebugLevel.INFO, String.Format("serverSentTime: {0} clientSentTime: {1}", serverSentTime, clientSentTime));

            lastRoundTripTime = SupportClass.GetTickCount() - clientSentTime;
            if (!serverTimeOffsetIsAvailable)
            {
                roundTripTime = lastRoundTripTime;
            }
            this.UpdateRoundTripTimeAndVariance(lastRoundTripTime);

            if (!serverTimeOffsetIsAvailable)
            {
                serverTimeOffset = serverSentTime + (lastRoundTripTime >> 1) - SupportClass.GetTickCount();
                serverTimeOffsetIsAvailable = true;
            }
        }

        //------------------------------------------------------------------------------------------------------------------
    }
    //#endif
}