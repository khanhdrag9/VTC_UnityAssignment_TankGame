﻿// -----------------------------------------------------------------------
// <copyright file="InvocationCache.cs" company="Exit Games GmbH">
//   Copyright (c) Exit Games GmbH.  All rights reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;

    internal class InvocationCache
    {
        private readonly LinkedList<CachedOperation> cache = new LinkedList<CachedOperation>();

        private int nextInvocationId = 1;

        public int NextInvocationId
        {
            get
            {
                return this.nextInvocationId;
            }
        }

        public int Count
        {
            get { return this.cache.Count; }
        }

        public void Reset()
        {
            lock (this.cache)
            {
                this.nextInvocationId = 1;
                cache.Clear();
            }
        }

        public void Invoke(int invocationId, Action action)
        {
            lock (this.cache)
            {
                if (invocationId < nextInvocationId)
                {
                    return;
                }
                if (invocationId == nextInvocationId)
                {
                    ++this.nextInvocationId;
                    action();

                    if (this.cache.Count > 0)
                    {
                        var n = this.cache.First;
                        while (n != null && n.Value.InvocationId == nextInvocationId)
                        {
                            nextInvocationId++;
                            n.Value.Action();
                            n = n.Next;
                            this.cache.RemoveFirst();
                        }
                    }
                    return;
                }

                var op = new CachedOperation { InvocationId = invocationId, Action = action };
                if (this.cache.Count == 0)
                {
                    this.cache.AddLast(op);
                    return;
                }

                var node = this.cache.First;
                while (node != null)
                {
                    if (node.Value.InvocationId > invocationId)
                    {
                        this.cache.AddBefore(node, op);
                        return;
                    }

                    node = node.Next;
                }

                this.cache.AddLast(op);
            }
        }

        private class CachedOperation
        {
            public int InvocationId { get; set; }

            public Action Action { get; set; }
        }
    }
}
