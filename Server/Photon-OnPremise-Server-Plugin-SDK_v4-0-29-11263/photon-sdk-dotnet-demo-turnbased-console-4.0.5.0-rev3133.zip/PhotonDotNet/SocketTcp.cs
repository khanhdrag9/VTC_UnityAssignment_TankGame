// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SocketTcp.cs" company="Exit Games GmbH">
//   Copyright (c) Exit Games GmbH.  All rights reserved.
// </copyright>
// <summary>
//   Internal class to encapsulate the network i/o functionality for the realtime libary.
// </summary>
// <author>developer@photonengine.com</author>
// --------------------------------------------------------------------------------------------------------------------
#if !NoSocket
namespace ExitGames.Client.Photon
{
    using System;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Security;
    using System.Threading;

    /// <summary>
    /// Internal class to encapsulate the network i/o functionality for the realtime libary.
    /// </summary>
    internal class SocketTcp : IPhotonSocket, IDisposable
    {
        private Socket sock;

        private readonly object syncer = new object();

        public SocketTcp(PeerBase npeer) : base(npeer)
        {
            if (this.ReportDebugOfLevel(DebugLevel.ALL))
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "SocketTcp: TCP, DotNet, Unity.");
            }

            this.Protocol = ConnectionProtocol.Tcp;
            this.PollReceive = false;
        }

        public void Dispose()
        {
            this.State = PhotonSocketState.Disconnecting;

            if (this.sock != null)
            {
                try
                {
                    if (this.sock.Connected) this.sock.Close();
                }
                catch (Exception ex)
                {
                    this.EnqueueDebugReturn(DebugLevel.INFO, "Exception in Dispose(): " + ex);
                }
            }

            this.sock = null;
            this.State = PhotonSocketState.Disconnected;
        }

        public override bool Connect()
        {
            bool baseOk = base.Connect();
            if (!baseOk)
            {
                return false;
            }

            this.State = PhotonSocketState.Connecting;

            Thread dns = new Thread(this.DnsAndConnect);
            dns.Name = "photon dns thread";
            dns.IsBackground = true;
            dns.Start();

            return true;
        }

        public override bool Disconnect()
        {
            if (this.ReportDebugOfLevel(DebugLevel.INFO))
            {
                this.EnqueueDebugReturn(DebugLevel.INFO, "SocketTcp.Disconnect()");
            }

            this.State = PhotonSocketState.Disconnecting;

            lock (this.syncer)
            {
                if (this.sock != null)
                {
                    try
                    {
                        this.sock.Close();
                    }
                    catch (Exception ex)
                    {
                        this.EnqueueDebugReturn(DebugLevel.INFO, "Exception in Disconnect(): " + ex);
                    }
                    this.sock = null;
                }
            }

            this.State = PhotonSocketState.Disconnected;
            return true;
        }

        /// <summary>
        /// used by TPeer*
        /// </summary>
        public override PhotonSocketError Send(byte[] data, int length)
        {
            if (!this.sock.Connected)
            {
                return PhotonSocketError.Skipped;
            }

            try
            {
                this.sock.Send(data);
            }
            catch (Exception e)
            {
                if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                {
                    this.EnqueueDebugReturn(DebugLevel.ERROR, "Cannot send to: " + this.ServerAddress + ". " + e.Message);
                }

                this.HandleException(StatusCode.Exception);
                return PhotonSocketError.Exception;
            }

            return PhotonSocketError.Success;
        }

        public override PhotonSocketError Receive(out byte[] data)
        {
            data = null;
            return PhotonSocketError.NoData;
        }

        public void DnsAndConnect()
        {
            try
            {
                IPAddress ipAddress = IPhotonSocket.GetIpAddress(this.ServerAddress);
                if (ipAddress == null)
                {
                    throw new ArgumentException("Invalid IPAddress. Address: " + this.ServerAddress);
                }
                if (ipAddress.AddressFamily != AddressFamily.InterNetwork && ipAddress.AddressFamily != AddressFamily.InterNetworkV6)
                {
                    throw new ArgumentException("AddressFamily '" + ipAddress.AddressFamily + "' not supported. Address: " + this.ServerAddress);
                }

                this.sock = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                this.sock.NoDelay = true;
                this.sock.Connect(ipAddress, this.ServerPort);

                this.State = PhotonSocketState.Connected;
            }
            catch (SecurityException se)
            {
                if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() to '" + this.ServerAddress + "' failed: " + se.ToString());
                }

                this.HandleException(StatusCode.SecurityExceptionOnConnect);
                return;
            }
            catch (Exception se)
            {
                if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() to '" + this.ServerAddress + "' failed: " + se.ToString());
                }

                this.HandleException(StatusCode.ExceptionOnConnect);
                return;
            }

#if TCPPREFIX
            // send prefix if any is defined
            if (this.peerBase.TcpConnectionPrefix != null && this.peerBase.TcpConnectionPrefix.Length > 0)
            {
                this.Send(this.peerBase.TcpConnectionPrefix, this.peerBase.TcpConnectionPrefix.Length);
            }
#endif

            Thread run = new Thread(new ThreadStart(ReceiveLoop));
            run.Name = "photon receive thread";
            run.IsBackground = true;
            run.Start();
        }

        public void ReceiveLoop()
        {
            MemoryStream opCollectionStream = new MemoryStream(this.MTU);
            while (this.State == PhotonSocketState.Connected)
            {
                opCollectionStream.Position = 0;
                opCollectionStream.SetLength(0);

                try
                {
                    // first step: reading only headers (tcp and msg)
                    int bytesRead = 0;
                    int bytesReadThisTime = 0;
                    byte[] inBuff = new byte[TPeer.ALL_HEADER_BYTES];

                    while (bytesRead < TPeer.ALL_HEADER_BYTES)
                    {
                        bytesReadThisTime = this.sock.Receive(inBuff, bytesRead, TPeer.ALL_HEADER_BYTES - bytesRead, SocketFlags.None);
                        bytesRead += bytesReadThisTime;

                        // Receive() is supposed to block. if it returns with 0 bytes, the socket is most likely closed (even if its Connected prop is not set correctly)
                        if (bytesReadThisTime == 0)
                        {
                            throw new SocketException((int)SocketError.ConnectionReset); // receiving 0 bytes with blocking Receive() tells us the server closed the connection
                        }
                    }

                    // check if it's a ping-result (first byte = 0xF0). this is 9 bytes in total. no other headers!
                    // note: its a coincidence that ping-result-size == header-size. if this changes we have to refactor this
                    if (inBuff[0] == 0xF0)
                    {
                        this.HandleReceivedDatagram(inBuff, inBuff.Length, false);
                        continue;
                    }

                    // inBuff should now contain a complete header of TCP and MSG headers
                    int length = inBuff[1] << 24 | inBuff[2] << 16 | inBuff[3] << 8 | inBuff[4];

                    if (this.peerBase.TrafficStatsEnabled)
                    {
                        bool isReliable = inBuff[5] == 0;
                        if (isReliable)
                        {
                            this.peerBase.TrafficStatsIncoming.CountReliableOpCommand(length);
                        }
                        else
                        {
                            this.peerBase.TrafficStatsIncoming.CountUnreliableOpCommand(length);
                        }
                    }

                    if (this.ReportDebugOfLevel(DebugLevel.ALL))
                    {
                        this.EnqueueDebugReturn(DebugLevel.ALL, "message length: " + length);
                    }

                    // write the MSG header to a stream which collects this and the MSG itself
                    opCollectionStream.Write(inBuff, TPeer.TCP_HEADER_BYTES, bytesRead - TPeer.TCP_HEADER_BYTES);

                    // read the MSG now, until it's complete
                    bytesRead = 0;
                    length -= TPeer.ALL_HEADER_BYTES;
                    inBuff = new byte[length];

                    while (bytesRead < length)
                    {
                        bytesReadThisTime = this.sock.Receive(inBuff, bytesRead, length - bytesRead, SocketFlags.None);
                        bytesRead += bytesReadThisTime;

                        // Receive() is supposed to block. if it returns with 0 bytes, the socket is most likely closed (even if its Connected prop is not set correctly)
                        if (bytesReadThisTime == 0)
                        {
                            throw new SocketException((int)SocketError.ConnectionReset); // receiving 0 bytes with blocking Receive() tells us the server closed the connection
                        }
                    }

                    // copy to opCollectionStream and this complete package is ready for being queued!
                    opCollectionStream.Write(inBuff, 0, bytesRead);

                    // get data and split the datagram into two buffers: head and body
                    if (opCollectionStream.Length > 0)
                    {
                        this.HandleReceivedDatagram(opCollectionStream.ToArray(), (int)opCollectionStream.Length, false);
                    }

                    if (this.ReportDebugOfLevel(DebugLevel.ALL))
                    {
                        this.EnqueueDebugReturn(DebugLevel.ALL, "TCP < " + opCollectionStream.Length + ((opCollectionStream.Length == length + TPeer.MSG_HEADER_BYTES) ? " OK" : " BAD"));
                    }
                }
                catch (SocketException e)
                {
                    if (this.State != PhotonSocketState.Disconnecting && this.State != PhotonSocketState.Disconnected)
                    {
                        if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                        {
                            this.EnqueueDebugReturn(DebugLevel.ERROR, "Receiving failed. SocketException: " + e.SocketErrorCode);
                        }

                        if (e.SocketErrorCode == SocketError.ConnectionReset || e.SocketErrorCode == SocketError.ConnectionAborted)
                        {
                            // StatusCode.DisconnectByServer
                            this.HandleException(StatusCode.DisconnectByServer);
                        }
                        else
                        {
                            this.HandleException(StatusCode.ExceptionOnReceive);
                        }
                    }
                }
                catch (Exception e)
                {
                    if (this.State != PhotonSocketState.Disconnecting && this.State != PhotonSocketState.Disconnected)
                    {
                        if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                        {
                            this.EnqueueDebugReturn(DebugLevel.ERROR, "Receive issue. State: " + this.State + ". Server: '" + this.ServerAddress + "' Exception: " + e);
                        }

                        this.HandleException(StatusCode.ExceptionOnReceive);
                    }
                }
            } // while connected

            this.Disconnect();
        }
    } // class
}
#endif