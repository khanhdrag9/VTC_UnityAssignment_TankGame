﻿//#define DEBUG_LOG_REQ_RESP

using System;
using System.IO;
using System.Net;
using System.Threading;
using ExitGames.Client.Photon;

namespace ExitGames.Client
{
    internal class HttpPeer : HttpPeerBase
    {
        #region Constructors

        internal HttpPeer()
        {
            // we set it to 2 mor than expected max connections, just to be sure
            ServicePointManager.DefaultConnectionLimit = 100;
        }

        internal HttpPeer(IPhotonPeerListener listener)
        :base(listener)
        { }
        #endregion

        #region RequestState

        class RequestState : RequestStateBase
        {
            #region Fields

            private IAsyncResult AsyncResult;
            private RegisteredWaitHandle RegWaitHandle;

            public RequestState(byte[] data, MessageType type, int id, HttpPeerBase peer)
                : base(data, type, id, peer)
            {
            }

            #endregion

            #region Properties

            private HttpWebRequest Request { get; set; }
            #endregion

            #region Public Methods
            public override void CancelTimeout()
            {
                if (this.RegWaitHandle != null)
                {
                    this.RegWaitHandle.Unregister(this.AsyncResult.AsyncWaitHandle);
                    this.RegWaitHandle = null;
                }

                this.AsyncResult = null;
            }

            public override void Abort()
            {
                if (this.Request != null)
                {
                    this.Request.Abort();
                }
            }

            public override void StartRequest(bool useGet, string url)
            {
                var request = (HttpWebRequest)WebRequest.Create(url);
                if (useGet)
                {
                    request.Method = "GET";
                    request.Pipelined = true;
                }
                else
                {
                    request.Method = "POST";
                }

#if !SILVERLIGHT

                // we allow setting the proxy programatically
                if (!(WebRequest.DefaultWebProxy is WebProxy))
                {
                    request.Proxy = null;
                }

#endif
                this.Request = request;
                request.KeepAlive = true;

                if (useGet)
                {
                    // Start the asynchronous operation to get the response
                    var result = request.BeginGetResponse(this.GetResponseCallback, this);
                    this.AsyncResult = result;
                    this.RegWaitHandle = ThreadPool.RegisterWaitForSingleObject(
                        result.AsyncWaitHandle,
                        this.TimeoutCallback,
                        this,
                        10000,
                        true);
                }
                else
                {
                    request.BeginGetRequestStream(this.GetRequestStreamCallback, this);
                }

            }

            public override void Cleanup()
            {
                base.Cleanup();
                this.Request = null;
            }

            #endregion

            #region Private Methods
            private void GetRequestStreamCallback(IAsyncResult asynchronousResult)
            {
                var state = (RequestStateBase)asynchronousResult.AsyncState;
                state.CancelTimeout();
                var request = this.Request;

                try
                {
                    var postStream = request.EndGetRequestStream(asynchronousResult);
                    {
                        if (state.OutgoingData != null)
                        {
                            postStream.Write(state.OutgoingData, 0, state.OutgoingData.Length);
                        }
                    }

                    postStream.Close();

                    // Start the asynchronous operation to get the response
                    var result = request.BeginGetResponse(this.GetResponseCallback, state);
                    this.AsyncResult = result;
                }
                catch (WebException webEx)
                {
                    ((HttpPeer)this.peer).WebExceptionHandler(state, request, webEx);
                }
            }

            private void TimeoutCallback(object stateObject, bool timedOut)
            {
                if (timedOut && this.Request != null)
                {
                    if (this.peer.debugOut >= DebugLevel.WARNING)
                    {
                        this.peer.Listener.DebugReturn(
                            DebugLevel.WARNING,
                            String.Format("Request {0} for pid={1} cid={2} aborted by timeout", this.Id, this.peer.HttpPeerId, this.peer.ChallengId));
                    }

                    this.Aborted = true;
                    this.Request.Abort();
                }
            }

            private void GetResponseCallback(IAsyncResult asynchronousResult)
            {
                var state = (RequestState)asynchronousResult.AsyncState;
                var request = state.Request;

                state.CancelTimeout();

                if (state.IsDisconnect)
                {
                    return;
                }

                try
                {
                    // End the operation
                    byte[] responseData;
                    using (var response = (HttpWebResponse) request.EndGetResponse(asynchronousResult))
                    {
                        using (var streamResponse = response.GetResponseStream())
                        {
                            if (streamResponse == null)
                            {
                                throw new Exception("response.GetResponseStream() is null.");
                            }

                            using (var binReader = new BinaryReader(streamResponse))
                            {
                                responseData = binReader.ReadBytes((int) response.ContentLength);

                                // Close the stream object
                                streamResponse.Close();
                                binReader.Close();
                            }
                        }

                        // Release the HttpWebResponse
                        response.Close();
                    }

                    this.peer.OnReceiveData(responseData, state.Id);
                }
                catch (WebException webEx)
                {
                    if (((HttpPeer) this.peer).WebExceptionHandler(state, request, webEx))
                    {
                        return;
                    }
                }
                catch (Exception e)
                {
                    if (this.peer.debugOut >= DebugLevel.ERROR)
                    {
                        this.peer.Listener.DebugReturn(DebugLevel.ERROR, e.Message);
                    }

                    this.peer.RerequestState(state, this.peer.UrlParameters, request.RequestUri.ToString());
                    return;
                }
                this.peer.OnRequestHandled(state);
            }

            #endregion
        }
        #endregion RequestState

        #region Methods

#if SDK_V4
        internal override bool Connect(string serverAddress, string appID, object custom)
        {
            if (this.peerConnectionState != ConnectionStateValue.Disconnected)
            {
                if (this.debugOut >= DebugLevel.WARNING)
                {
                    this.Listener.DebugReturn(DebugLevel.WARNING, "Connect() called while peerConnectionState != Disconnected. Nothing done.");
                }

                return false;
            }

            this.outgoingStream = new MemoryStream(outgoingStreamBufferSize);

            this.Reset();
            this.peerConnectionState = ConnectionStateValue.Connecting;
            this.ServerAddress = serverAddress;
            var srvMax = this.rhttpMinConnections + 1;
            this.urlParameters = "?init&rmax=" + (srvMax > 1 ? srvMax : 0) + "&cid=";

            this.urlParameters += this.challengId;

            // the RealtimeServer can run multiple applications (by name/applicationName) - the default is called "Lite"
            if (appID == null)
            {
                appID = "NUnit";
            }

            this.urlParameters += "&app=" + appID;
            this.urlParameters += "&clientversion=" + ClientVersion;
            this.urlParameters += "&protocol=" + Protocol.protocolType; // GpBinaryV16, GpBinaryV17 or json

            // set a ping timestamp
            this.lastPingTimeStamp = this.GetLocalMsTimestamp();

            var customData = Protocol.Serialize(custom);

            // the initial request will do DNS resolution, which is not handled async
            // this thread "hides" DNS resolution
            var thread = new Thread(() => this.Request(customData, this.urlParameters, MessageType.Connect));
            thread.Start();

            return true;
        }

#endif // SDK_V4

        //TODO: implement this Connect using Connect with custom data
        internal override bool Connect(string serverAddress, string appID)
        {
            if (this.peerConnectionState != ConnectionStateValue.Disconnected)
            {
                if (this.debugOut >= DebugLevel.WARNING)
                {
                    this.Listener.DebugReturn(DebugLevel.WARNING, "Connect() called while peerConnectionState != Disconnected. Nothing done.");
                }

                return false;
            }

            if (string.IsNullOrEmpty(serverAddress) || !serverAddress.StartsWith("http", true, null))
            {
                this.Listener.DebugReturn(
                    DebugLevel.ERROR,
                    "Connect() with RHTTP failed. ServerAddress must include 'http://' or 'https://' prefix. Was: " + serverAddress);
                return false;
            }

            this.outgoingStream = new MemoryStream(outgoingStreamBufferSize);

            this.Reset();
            this.peerConnectionState = ConnectionStateValue.Connecting;
            this.ServerAddress = serverAddress;
            var srvMax = this.rhttpMinConnections + 1;
            this.urlParameters = "?init&rmax=" + (srvMax > 1 ? srvMax : 0) + "&cid=";

            this.urlParameters += this.challengId;

            // the RealtimeServer can run multiple applications (by name/applicationName) - the default is called "Lite"
            if (appID == null)
            {
                appID = "NUnit";
            }

            this.urlParameters += "&app=" + appID;
            this.urlParameters += "&clientversion=" + ClientVersion;
            this.urlParameters += "&protocol=" + Protocol.protocolType; // GpBinaryV16, GpBinaryV17 or json

            // set a ping timestamp
            this.lastPingTimeStamp = this.GetLocalMsTimestamp();

            // the initial request will do DNS resolution, which is not handled async
            // this thread "hides" DNS resolution
            var thread = new Thread(() => this.Request(null, this.urlParameters, MessageType.Connect));
            thread.Start();

            return true;
        }


        protected override RequestStateBase CreateRequestState(byte[] data, MessageType type, int id)
        {
            return new RequestState(data, type, id, this);
        }

        private bool WebExceptionHandler(RequestStateBase state, HttpWebRequest request, WebException webEx)
        {
            if (webEx.Status == WebExceptionStatus.RequestCanceled && !state.Aborted)
            {
                // request was canceled during call to either 'Diconnect' or 'Connect'
                return true;
            }

            var response = (HttpWebResponse)webEx.Response;
            this.LogWebException(state, webEx, response);

            switch (this.peerConnectionState)
            {
                case ConnectionStateValue.Connecting:
                    this.EnqueueErrorDisconnect(StatusCode.ExceptionOnConnect);
                    break;
                case ConnectionStateValue.Connected:
                {
                    if (state.Aborted)
                    {
                        this.EnqueueErrorDisconnect(StatusCode.TimeoutDisconnect);
                    }
                    else
                    {
                        if (response != null)
                        {
                            if (GotIgnoreStatus((int)response.StatusCode))
                            {
                                if (this.debugOut >= DebugLevel.ALL)
                                {
                                    this.Listener.DebugReturn(DebugLevel.ALL, 
                                        string.Format("got status {0} which we ignore", response.StatusCode));
                                }

                                return false;// we need further processing this state
                            }

                            this.EnqueueErrorDisconnect(StatusCode.DisconnectByServer);
                            return true;
                        }

                        this.HandleError(state, request, webEx);
                    }
                    break;
                }   
                //case ConnectionStateValue.Disconnected:
                //case ConnectionStateValue.Disconnecting:
                //case ConnectionStateValue.AcknowledgingDisconnect:
                //case ConnectionStateValue.Zombie:
                default:
                    // we do nothing here, because peer is already NOT connected and should be cleaned up
                    break;
            }
            return true;
        }

        private void LogWebException(RequestStateBase state, WebException webEx, HttpWebResponse response)
        {
            if (this.peerConnectionState != ConnectionStateValue.Disconnecting || this.peerConnectionState != ConnectionStateValue.Disconnected)
            {
                if (!state.Restarting)
                {
                    if (this.debugOut >= DebugLevel.ERROR)
                    {
                        if (response != null)
                        {
                            var subCode = GetDisconnectReason(response, this);

                            this.Listener.DebugReturn(
                                DebugLevel.ERROR,
                                String.Format(
                                    "Request {0} for pid={1} cid={2} failed with exception {3}, msg: {4}, status code: {5}, reason: {6}",
                                    state.Id,
                                    this.httpPeerId,
                                    this.challengId,
                                    webEx.Status,
                                    webEx.Message,
                                    subCode,
                                    response.StatusDescription));
                        }
                        else
                        {
                            this.Listener.DebugReturn(
                                DebugLevel.ERROR,
                                String.Format(
                                    "Request {0} for pid={1} cid={2} failed with exception {3}, msg: {4}",
                                    state.Id,
                                    this.httpPeerId,
                                    this.challengId,
                                    webEx.Status,
                                    webEx.Message));
                        }
                    }
                }
            }
        }

        private static bool IsExceptionGross(WebExceptionStatus webExceptionStatus)
        {
            return webExceptionStatus == WebExceptionStatus.ConnectFailure;
        }

        private void HandleError(RequestStateBase state, HttpWebRequest request, WebException webEx)
        {
#if DEBUG_LOG_REQ_RESP
                Console.WriteLine("HandleError: pid:{0}, cid:{1}, stateId:{2}, msg:{3}", this.httpPeerId, this.challengId, state.Id, webEx.Message);
#endif

            if (IsExceptionGross(webEx.Status))
            {
                Interlocked.Increment(ref this.grossErrorCount);
            }

            if (this.grossErrorCount >= MaxGrossErrors)
            {
                if (this.debugOut >= DebugLevel.ALL)
                {
                    this.Listener.DebugReturn(DebugLevel.ALL, "limit of gross errors reached. Connection closed");
                }

                this.EnqueueErrorDisconnect(StatusCode.ExceptionOnReceive);
                return;
            }

#if DEBUG_LOG_REQ_RESP
            Console.WriteLine("Rerequesting: pid:{0}, cid:{1}, stateId:{2}", this.httpPeerId, this.challengId, state.Id);
#endif
            this.RerequestState(state, this.urlParameters, request.RequestUri.ToString());
        }

        private static int GetDisconnectReason(HttpWebResponse response, HttpPeerBase peer)
        {
            var statusCode = -1;
            if (response.ContentLength >= 4)
            {
                try
                {
                    using (var streamResponse = response.GetResponseStream())
                    {
                        if (streamResponse == null)
                        {
                            peer.Listener.DebugReturn(DebugLevel.ERROR, "GetStatusCodeFromResponse: response.GetResponseStream() is null.");

                            throw new Exception("response.GetResponseStream() is null");
                        }

                        var binReader = new BinaryReader(streamResponse);
                        statusCode = binReader.ReadByte() << 24;
                        statusCode |= binReader.ReadByte() << 16;
                        statusCode |= binReader.ReadByte() << 8;
                        statusCode |= binReader.ReadByte();
                    }
                }
                catch (Exception e)
                {
                    peer.Listener.DebugReturn(DebugLevel.ERROR, String.Format("Exception '{0}' happened during response status reading", e));
                }
            }

            return statusCode;
        }

        #endregion
    }
}
