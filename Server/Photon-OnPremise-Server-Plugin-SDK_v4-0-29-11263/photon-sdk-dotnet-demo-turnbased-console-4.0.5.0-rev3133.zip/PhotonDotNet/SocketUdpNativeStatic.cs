﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Exit Games GmbH">
//   Protocol & Photon Client Lib - Copyright (C) 2010 Exit Games GmbH
// </copyright>
// <author>developer@photonengine.com</author>
// --------------------------------------------------------------------------------------------------------------------

namespace ExitGames.Client.Photon
{
    using System;
    using System.Security;
    using System.Threading;
    using System.Runtime.InteropServices;

    public class SocketUdpNativeStatic : IPhotonSocket
    {

#if !NATIVE_SOCKETS

        public SocketUdpNativeStatic(PeerBase peerBase) : base(peerBase)
        {
        }

        public override bool Disconnect()
        {
            throw new NotImplementedException("This class was compiled in an assembly WITH c# sockets. Another dll must be used for native sockets.");
        }

        public override PhotonSocketError Send(byte[] data, int length)
        {
            throw new NotImplementedException("This class was compiled in an assembly WITH c# sockets. Another dll must be used for native sockets.");
        }

        public override PhotonSocketError Receive(out byte[] data)
        {
            throw new NotImplementedException("This class was compiled in an assembly WITH c# sockets. Another dll must be used for native sockets.");
        }

#else

        [DllImport("__Internal")]
        internal static extern IntPtr egconnect([MarshalAs(UnmanagedType.LPStr)] string address);

        [DllImport("__Internal")]
        internal static extern byte eggetState(IntPtr pConnectionHandler);

        [DllImport("__Internal")]
        internal static extern void egdisconnect(IntPtr pConnectionHandler);

        [DllImport("__Internal")]
        internal static extern int egservice(IntPtr pConnectionHandler);

        [DllImport("__Internal")]
        internal static extern int egsend(IntPtr pConnectionHandler, byte[] arr, int size);

        [DllImport("__Internal")]
        internal static extern int egread(IntPtr pConnectionHandler, byte[] arr, ref int size);

        private IntPtr pConnectionHandler = IntPtr.Zero;

        internal static readonly object syncer = new object();

        // Native socket states - according to EnetConnect.h state definitions
        enum NativeSocketState : byte
        {
            Disconnected = 0,
            Connecting = 1,
            Connected = 2,
            ConnectionError = 3,
            SendError = 4,
            ReceiveError = 5,
            Disconnecting = 6
        }

        public SocketUdpNativeStatic(PeerBase npeer): base(npeer)
        {
            if (this.ReportDebugOfLevel(DebugLevel.ALL))
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "SocketUdpNative: UDP, Static Native Lib (Unity iOS Style).");
            }

            this.Protocol = ConnectionProtocol.Udp;
            this.PollReceive = false;
        }

        public override bool Connect()
        {
            bool baseOk = base.Connect();
            if (!baseOk)
            {
                return false;
            }

            this.State = PhotonSocketState.Connecting;

            Thread dns = new Thread(this.DnsAndConnect);
            dns.IsBackground = true;
            dns.Start();

            return true;
        }

        public override bool Disconnect()
        {
            if (this.ReportDebugOfLevel(DebugLevel.INFO))
            {
                this.EnqueueDebugReturn(DebugLevel.INFO, "SocketUdpNative.Disconnect()");
            }

            this.State = PhotonSocketState.Disconnecting;

            lock (syncer)
            {
                if (this.pConnectionHandler != IntPtr.Zero)
                {
                    try
                    {
                        egdisconnect(pConnectionHandler);
                        pConnectionHandler = IntPtr.Zero;
                    }
                    catch (Exception ex)
                    {
                        this.EnqueueDebugReturn(DebugLevel.INFO, "Exception in Disconnect(): " + ex);
                    }
                }
            }

            this.State = PhotonSocketState.Disconnected;
            return true;
        }

        /// <summary>used by PhotonPeer*</summary>
        public override PhotonSocketError Send(byte[] data, int length)
        {
            lock (syncer)
            {
                if (pConnectionHandler != IntPtr.Zero)
                {
                    egsend(pConnectionHandler, data, length);
                    return PhotonSocketError.Success; // TODO: check success by accessing the state
                }
            }

            return PhotonSocketError.Success;
        }

        public override PhotonSocketError Receive(out byte[] data)
        {
            data = null;
            return PhotonSocketError.NoData;
        }

        internal void DnsAndConnect()
        {
            try
            {
                lock (syncer)
                {
                    //Debug.Log("DnsAndConnect: " + pConnectionHandler + " ServerAddress: " + this.ServerAddress);

                    pConnectionHandler = egconnect(this.ServerAddress + ":" + this.ServerPort);
                    int state = egservice(pConnectionHandler);  // need to call egService once to make it connect and switch from connecting to connected state

                    this.State = PhotonSocketState.Connected; // TODO: access real low-level state
                }
            }
            catch (SecurityException se)
            {
                if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() to '" + this.ServerAddress + "' failed: " + se.ToString());
                }

                this.HandleException(StatusCode.SecurityExceptionOnConnect);
                return;
            }
            catch (Exception se)
            {
                if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() to '" + this.ServerAddress + "' failed: " + se.ToString());
                }

                this.HandleException(StatusCode.ExceptionOnConnect);
                return;
            }

            Thread run = new Thread(new ThreadStart(ReceiveLoop));
            run.IsBackground = true;
            run.Start();
        }

        public void ReceiveLoop()
        {
            while (this.State == PhotonSocketState.Connecting || this.State == PhotonSocketState.Connected)
            {
                try
                {
                    int bytesInBufferAfterRead = 0;
                    byte[] bytesRead = null;

                    lock (syncer)
                    {
                        if (pConnectionHandler == IntPtr.Zero)
                        {
                            throw new Exception("Pointer to unmanaged socket is Zero. Can't read.");
                        }

                        // check if native socket is still ok and connected
                        byte state = eggetState(pConnectionHandler);
                        if (state != (byte) NativeSocketState.Connected && state != (byte) NativeSocketState.Connecting)
                        {
                            if (state == (byte) NativeSocketState.ConnectionError || state == (byte) NativeSocketState.ReceiveError || state == (byte) NativeSocketState.SendError)
                            {
                                throw new Exception("Native socket has receive error or is disconnected: " + state);
                            }
                            if (state == (byte) NativeSocketState.Disconnected || state == (byte) NativeSocketState.Disconnecting)
                            {
                                EnqueueDebugReturn(DebugLevel.ERROR, "Disconnecting cause native socket's state during read is: " + state);
                                this.State = PhotonSocketState.Disconnecting;
                            }
                        }

                        int bytesAvailable = egservice(pConnectionHandler);  // returns byte-count of next datagram. or 0 if none available
                        if (bytesAvailable != 0)
                        {
                            //Debug.Log("ReceiveLoop: " + pConnectionHandler + " res: " + serviceResult);
                            bytesRead = new byte[bytesAvailable];
                            bytesInBufferAfterRead = egread(pConnectionHandler, bytesRead, ref bytesAvailable); // returns byte-count of next datagram. or 0 if none available
                            //Debug.Log("ReceiveLoop: " + pConnectionHandler + " res: " + serviceResult + " read: " + read + " bytes: " + SupportClass.ByteArrayToString(bytes));
                        }
                    }

                    if (bytesRead != null)
                    {
                        this.HandleReceivedDatagram(bytesRead, bytesRead.Length, false);
                    }

                    if (bytesInBufferAfterRead > 0)
                    {
                        continue; // read next immediately if available
                    }

                    Thread.Sleep(15);
                }
                catch (ObjectDisposedException ode)
                {
                    if (this.State != PhotonSocketState.Disconnecting && this.State != PhotonSocketState.Disconnected)
                    {
                        if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                        {
                            this.EnqueueDebugReturn(DebugLevel.ERROR, "Receive issue (ObjectDisposedException). State: " + this.State + " Exception: " + ode);
                        }

                        this.HandleException(StatusCode.ExceptionOnReceive);
                        break;
                    }
                }
                catch (System.Exception e)
                {
                    if (this.State != PhotonSocketState.Disconnecting && this.State != PhotonSocketState.Disconnected)
                    {
                        if (this.ReportDebugOfLevel(DebugLevel.ERROR))
                        {
                            this.EnqueueDebugReturn(DebugLevel.ERROR, "Receive issue. State: " + this.State + ". Server: '" + this.ServerAddress + "' Exception: " + e);
                        }

                        this.HandleException(StatusCode.ExceptionOnReceive);
                        break;
                    }
                }

            } //while !obsolete receive


            // when exiting the receive-loop, disconnect
            this.Disconnect();
        }
#endif
    }
}