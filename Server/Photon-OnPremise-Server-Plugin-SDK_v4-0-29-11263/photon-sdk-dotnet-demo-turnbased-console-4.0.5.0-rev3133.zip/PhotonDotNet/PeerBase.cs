// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PeerBase.cs" company="Exit Games GmbH">
//   Exit Games GmbH, 2011
// </copyright>
// <summary>
//   Base class for internally used protocol-dependent classes (to be derived from this).
// </summary>
// <author>developer@photonengine.com</author>
// --------------------------------------------------------------------------------------------------------------------

using System.Linq;

namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Threading;
    using global::Photon.SocketServer.Security;

    internal static class PhotonCodes
    {
        /// <summary>Param code. Used in internal op: InitEncryption.</summary>
        internal static byte ClientKey = 1;
        /// <summary>Encryption-Mode code. Used in internal op: InitEncryption.</summary>
        internal static byte ModeKey = 2;
        /// <summary>Param code. Used in internal op: InitEncryption.</summary>
        internal static byte ServerKey = 1;
        /// <summary>Code of internal op: InitEncryption.</summary>
        internal static byte InitEncryption = 0;
        /// <summary>TODO: Code of internal op: Ping (used in PUN binary websockets).</summary>
        internal static byte Ping = 1;
        /// <summary>Result code for any (internal) operation.</summary>
        public const byte Ok = 0;
    }

    public abstract class PeerBase
    {
        public const string ClientVersion = "4.0.5.0";
        internal protected Type SocketImplementation = null;
        internal IPhotonSocket rt;

        public int ByteCountLastOperation;
        public int ByteCountCurrentDispatch;
        internal NCommand CommandInCurrentDispatch;

        public long TrafficStatsEnabledTime
        {
            get
            {
                return (this.trafficStatsStopwatch != null) ? this.trafficStatsStopwatch.ElapsedMilliseconds : 0;
            }
        }

        internal int TrafficPackageHeaderSize; // EnetPeer will set this value, so trafficstats can use it. TCP has 0 bytes per package extra
        public TrafficStats TrafficStatsIncoming;
        public TrafficStats TrafficStatsOutgoing;
        public TrafficStatsGameLevel TrafficStatsGameLevel;
        private Stopwatch trafficStatsStopwatch;
        private bool trafficStatsEnabled = false;

        /// <summary>
        /// Enables or disables collection of statistics.
        /// Setting this to true, also starts the stopwatch to measure the timespan the stats are collected.
        /// </summary>
        public bool TrafficStatsEnabled
        {
            get
            {
                return this.trafficStatsEnabled;
            }

            set
            {
                this.trafficStatsEnabled = value;
                if (value)
                {
                    if (this.trafficStatsStopwatch == null)
                    {
                        this.InitializeTrafficStats();
                    }

                    this.trafficStatsStopwatch.Start();
                }
                else if (this.trafficStatsStopwatch != null)
                {
                    this.trafficStatsStopwatch.Stop();
                }
            }
        }

        public string ServerAddress { get; internal set; }

        // only used for HTTP (ignored by UDP / TCP connections)
        internal string HttpUrlParameters { get; set; }

        internal ConnectionProtocol usedProtocol;

        internal bool crcEnabled = false;

        internal int packetLossByCrc;

        internal int packetLossByChallenge;

        internal IPhotonPeerListener Listener { get; set; }

        internal DebugLevel debugOut = DebugLevel.ERROR; // see property

        internal delegate void MyAction();

        internal readonly Queue<MyAction> ActionQueue = new Queue<MyAction>();


        /// This ID is assigned by the Realtime Server upon connection.
        /// The application does not have to care about this, but it is useful in debugging.
        internal short peerID = -1;

        /// <summary>
        /// This is the (low level) connection state of the peer. It's internal and based on eNet's states.
        /// </summary>
        /// <remarks>Applications can read the "high level" state as PhotonPeer.PeerState, which uses a different enum.</remarks>
        internal ConnectionStateValue peerConnectionState;

        /// <summary>
        /// The serverTimeOffset is serverTimestamp - localTime. Used to approximate the serverTimestamp with help of localTime
        /// </summary>
        internal int serverTimeOffset;
        internal bool serverTimeOffsetIsAvailable;

        internal int roundTripTime;
        internal int roundTripTimeVariance;
        internal int lastRoundTripTime;
        internal int lowestRoundTripTime;
        internal int lastRoundTripTimeVariance;
        internal int highestRoundTripTimeVariance;
        internal int timestampOfLastReceive;
        internal int packetThrottleInterval;

        internal static short peerCount; // number of peers
        internal long bytesOut; // counts all bytes going out (include header)
        internal long bytesIn; // counts all bytes coming in (include header)

        internal int commandBufferSize = 100;
        internal int warningSize = 100;
        internal int sentCountAllowance = 5; // maximum number of times the command will be resent, before the connection is regarded as lost
        internal int DisconnectTimeout = 10000; // milliseconds before an individual command must be ACKd - after this it triggers a timeout-disconnect
        internal int timePingInterval = 1000;

        internal byte ChannelCount = 2;
        internal int limitOfUnreliableCommands = 0;
        public byte QuickResendAttempts { get; set; }

        internal DiffieHellmanCryptoProvider CryptoProvider;

        private readonly Random lagRandomizer = new Random();
        internal readonly LinkedList<SimulationItem> NetSimListOutgoing = new LinkedList<SimulationItem>();
        internal readonly LinkedList<SimulationItem> NetSimListIncoming = new LinkedList<SimulationItem>();
        private readonly NetworkSimulationSet networkSimulationSettings = new NetworkSimulationSet();

        /// <summary>
        /// Gets the currently used settings for the built-in network simulation.
        /// Please check the description of NetworkSimulationSet for more details.
        /// </summary>
        public NetworkSimulationSet NetworkSimulationSettings
        {
            get { return this.networkSimulationSettings; }
        }


        // Command Log Stuff

        /// <summary>Size of CommandLog. Default is 0, no logging.</summary>
        internal int CommandLogSize = 0;

        /// <summary>Log of sent reliable commands and incoming ACKs.</summary>
        internal Queue<CmdLogItem> CommandLog;

        /// <summary>Log of incoming reliable commands, used to track which commands from the server this client got. Part of the PhotonPeer.CommandLogToString() result.</summary>
        internal Queue<CmdLogItem> InReliableLog;

        /// <summary>Reduce CommandLog to CommandLogSize. Oldest entries get discarded.</summary>
        internal void CommandLogResize()
        {
            if (this.CommandLogSize <= 0)
            {
                this.CommandLog = null;
                this.InReliableLog = null;
                return;
            }

            if (this.CommandLog == null || this.InReliableLog == null)
            {
                this.CommandLogInit();
            }

            while (this.CommandLog.Count > 0 && this.CommandLog.Count > this.CommandLogSize)
            {
                this.CommandLog.Dequeue();
            }
            while (this.InReliableLog.Count > 0 && this.InReliableLog.Count > this.CommandLogSize)
            {
                this.InReliableLog.Dequeue();
            }
        }

        /// <summary>Initializes the CommandLog and InReliableLog according to CommandLogSize. A value of 0 will set both logs to 0.</summary>
        internal void CommandLogInit()
        {
            if (this.CommandLogSize <= 0)
            {
                this.CommandLog = null;
                this.InReliableLog = null;
                return;
            }

            if (this.CommandLog == null || this.InReliableLog == null)
            {
                this.CommandLog = new Queue<CmdLogItem>(this.CommandLogSize);
                this.InReliableLog = new Queue<CmdLogItem>(this.CommandLogSize);
            }
            else
            {
                this.CommandLog.Clear();
                this.InReliableLog.Clear();
            }
        }

        /// <summary>Converts the CommandLog into a readable table-like string with summary.</summary>
        public string CommandLogToString()
        {
            StringBuilder sb = new StringBuilder();
            int resends = (this.usedProtocol != ConnectionProtocol.Udp) ? 0 : ((EnetPeer)this).reliableCommandsRepeated;
            sb.AppendFormat("PeerId: {0} Now: {1} Server: {2} State: {3} Total Resends: {4} Received {5}ms ago.\n", this.PeerID, this.timeInt, this.ServerAddress, this.peerConnectionState, resends, (SupportClass.GetTickCount() - this.timestampOfLastReceive));

            if (this.CommandLog == null)
            {
                return sb.ToString();
            }

            foreach (CmdLogItem item in this.CommandLog)
            {
                sb.AppendLine(item.ToString());
            }

            sb.AppendLine("Received Reliable Log: ");
            foreach (CmdLogItem item in this.InReliableLog)
            {
                sb.AppendLine(item.ToString());
            }

            return sb.ToString();
        }


        /// <summary>
        /// Count of all bytes going out (including headers)
        /// </summary>
        internal long BytesOut
        {
            get { return this.bytesOut; }
        }

        /// <summary>
        /// Count of all bytes coming in (including headers)
        /// </summary>
        internal long BytesIn
        {
            get { return this.bytesIn; }
        }


        internal abstract int QueuedIncomingCommandsCount { get; }
        internal abstract int QueuedOutgoingCommandsCount { get; }

        public virtual string PeerID
        {
            get { return ((ushort)this.peerID).ToString(); }
        }

        //11+32  = Byte) MagicNumber = 0xFD, (Short) InvocationId, ?(Short) Length, (byte) MsgType, byte[2] Protocol = �1.2�, 1 , byte[3]) Clientlib = �1.5.5�, 7, byte[32] AppID (last is 0x00)
        internal byte[] INIT_BYTES = new byte[9 + 32]; //8 bytes of header and 32+1 byte for applicationName (32 bytes string or 0-terminated if less)


        internal protected byte[] TcpConnectionPrefix { get; set; }

        /// <summary>
        /// This is the replacement for the const values used in eNet like: PS_DISCONNECTED, PS_CONNECTED, etc.
        /// </summary>
        public enum ConnectionStateValue : byte
        {
            /// <summary>No connection is available. Use connect.</summary>
            Disconnected = 0,

            /// <summary>Establishing a connection already. The app should wait for a status callback.</summary>
            Connecting = 1,

            ///// <summary>Establishing connection.</summary>
            //AcknowledgingConnect = 2,

            /// <summary>
            /// The low level connection with Photon is established. On connect, the library will automatically
            /// send an Init package to select the application it connects to (see also PhotonPeer.Connect()).
            /// When the Init is done, IPhotonPeerListener.OnStatusChanged() is called with connect.
            /// </summary>
            /// <remarks>Please note that calling operations is only possible after the OnStatusChanged() with StatusCode.Connect.</remarks>
            Connected = 3,

            /// <summary>Connection going to be ended. Wait for status callback.</summary>
            Disconnecting = 4,

            /// <summary>Acknowledging a disconnect from Photon. Wait for status callback.</summary>
            AcknowledgingDisconnect = 5,

            /// <summary>Connection not properly disconnected.</summary>
            Zombie = 6
        }

        internal enum EgMessageType : byte
        {
            Init = 0,
            InitResponse = 1,
            Operation = 2,
            OperationResponse = 3,
            Event = 4,
            InternalOperationRequest = 6,
            InternalOperationResponse = 7,
            Message = 8,
            RawMessage = 9,
        }

        // (byte) magic, (short) invoc, (short) length, (byte) protocol delimit = 1, (short) protocol, (byte) lib-version delimit = 6, (3 bytes) lib-version, (byte) app-name delimit = 7, (32 bytes) app-name
        // internal readonly byte[] ConstInitBytes = new byte[] {0xF1, 0, 0, 0, 45, 0, 1, 5, 1, 6, 1, 0, 7};
        internal void InitOnce()
        {
            this.networkSimulationSettings.peerBase = this;

            // TODO: get rid of this
            INIT_BYTES[0] = (byte)0xF3;
            INIT_BYTES[1] = (byte)0; //(byte) MsgType = "Init" = 0
            INIT_BYTES[2] = (byte)1; //(2 byte) Protocol
            INIT_BYTES[3] = (byte)6;
            INIT_BYTES[4] = (byte)1; //(byte) ClientLib delimiter = 1
            INIT_BYTES[5] = (byte)4; //(3 byte) CLientLib version
            INIT_BYTES[6] = (byte)0;
            INIT_BYTES[7] = (byte)5;
            INIT_BYTES[8] = (byte)7; //(byte) AppID delimiter = 7
            //32 x (byte) "AppID". Should match an application name in server config
        }

        internal int timeBase;
        internal int timeInt;

        internal int timeoutInt;
        internal int timeLastAckReceive; //last time some ACK was received
        internal int timeLastSendAck;   //last time some ACK got sent
        /// <summary>Set to timeInt, whenever SendOutgoingCommands actually checks outgoing queues to send them. Must be connected.</summary>
        internal int timeLastSendOutgoing;

        //variables for packetloss, roundtriptimes, variance and more
        internal const int ENET_PEER_PACKET_LOSS_SCALE = (1 << 16);
        internal const int ENET_PEER_DEFAULT_ROUND_TRIP_TIME = 300;
        internal const int ENET_PEER_PACKET_THROTTLE_INTERVAL = 5000;

        /// <summary>Connect to server and send Init (which inlcudes the appId).</summary>
        internal abstract bool Connect(string serverAddress, string appID);
#if SDK_V4
        internal abstract bool Connect(string serverAddress, string appID, object customData);
#endif
        private string GetHttpKeyValueString(Dictionary<string, string> dic)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var p in dic)
            {
                sb.Append(p.Key).Append("=").Append(p.Value).Append("&");
            }
            return sb.ToString();
        }
#if SDK_V4
        internal byte[] PrepareConnectData(string serverAddress, string appID, object custom)
        {
            byte[] result = null;

            var query = new Dictionary<string, string>();

            query["init"] = null;
            query["app"] = appID;
            query["clientversion"] = ClientVersion;
            query["protocol"] = Protocol.protocolType; //GpBinaryV16, GpBinaryV17 or json

            byte[] customData = null;

            int totalLen = 0;
            if (custom != null)
            {
                customData = Protocol.Serialize(custom);
                totalLen += customData.Length;
            }


            var httpHeader =
                string.Format(
                    "POST /?{0} HTTP/1.1\r\n"
                    + "Host: {1}\r\n"
                    + "Content-Length: {2}\r\n"
                    + "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1;"
                    + " .NET CLR 1.1.4322; .NET CLR 2.0.50727)\r\n\r\n",
                    GetHttpKeyValueString(query), serverAddress, totalLen);

            result = new byte[httpHeader.Length + totalLen];
            if (customData != null)
            {
                Buffer.BlockCopy(customData, 0, result, httpHeader.Length, customData.Length);
            }
            Buffer.BlockCopy(Encoding.UTF8.GetBytes(httpHeader), 0, result, 0, httpHeader.Length);

            return result;
        }
#endif

        internal abstract void Disconnect();

        internal abstract void StopConnection();

        internal abstract void FetchServerTimestamp();

        internal bool EnqueueOperation(Dictionary<byte, object> parameters, byte opCode, bool sendReliable, byte channelId, bool encrypted)
        {
            return EnqueueOperation(parameters, opCode, sendReliable, channelId, encrypted, EgMessageType.Operation);
        }

        internal abstract bool EnqueueOperation(Dictionary<byte, object> parameters, byte opCode, bool sendReliable, byte channelId, bool encrypted, EgMessageType messageType);


#if SDK_V4
        internal virtual bool EnqueueMessage(object message, bool sendReliable, byte channelId, bool encrypt)
        {
            throw new NotImplementedException();
        }

        internal virtual bool EnqueueRawMessage(byte[] data, bool sendReliable, byte channelId, bool encrypt)
        {
            throw new NotImplementedException();
        }
#endif

        /// <summary>
        /// Checks the incoming queue and Dispatches received data if possible.
        /// </summary>
        /// <returns>If a Dispatch happened or not, which shows if more Dispatches might be needed.</returns>
        internal abstract bool DispatchIncomingCommands();

        /// <summary>
        /// Checks outgoing queues for commands to send and puts them on their way.
        /// This creates one package per go in UDP.
        /// </summary>
        /// <returns>If commands are not sent, cause they didn't fit into the package that's sent.</returns>
        internal abstract bool SendOutgoingCommands();

        internal virtual bool SendAcksOnly()
        {
            return false;
        }

        /// <summary> Returns the UDP Payload starting with Magic Number for binary protocol </summary>
        internal byte[] SerializeMessageToMessage(object message, bool encrypt, byte[] messageHeader, bool writeLength = true)
        {
            byte[] fullMessageBytes;

            lock (this.SerializeMemStream)
            {
                // re-set the mem stream for next message and op (in message)
                this.SerializeMemStream.Position = 0;
                this.SerializeMemStream.SetLength(0);

                // write (prelimiary) message header (might be changed later on, due to encryption, etc)
                if (!encrypt)
                {
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                }

                // write bytes of op to memstream
                Protocol.SerializeMessage(this.SerializeMemStream, message);

                // if we encrypt, the message header was left out, as we encrypt only the operation bytes
                if (encrypt)
                {
                    byte[] opBytes = this.SerializeMemStream.ToArray();
                    opBytes = this.CryptoProvider.Encrypt(opBytes);

                    this.SerializeMemStream.Position = 0;
                    this.SerializeMemStream.SetLength(0);
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                    this.SerializeMemStream.Write(opBytes, 0, opBytes.Length);
                }

                fullMessageBytes = this.SerializeMemStream.ToArray();
            }

            // now update the message header according to type
            fullMessageBytes[messageHeader.Length - 1] = (byte)EgMessageType.Message;

            if (encrypt)
            {
                fullMessageBytes[messageHeader.Length - 1] = (byte)(fullMessageBytes[messageHeader.Length - 1] | 0x80);
            }

            if (writeLength)
            {
                // update length in tcp header. it's at position 1 (to 4)
                int offsetForLength = 1;
                Protocol.Serialize((int)fullMessageBytes.Length, fullMessageBytes, ref offsetForLength);
            }

            return fullMessageBytes;
        }


        /// <summary> Returns the UDP Payload starting with Magic Number for binary protocol </summary>
        internal byte[] SerializeRawMessageToMessage(byte[] data, bool encrypt, byte[] messageHeader, bool writeLength = true)
        {
            byte[] fullMessageBytes;

            lock (this.SerializeMemStream)
            {
                // re-set the mem stream for next message and op (in message)
                this.SerializeMemStream.Position = 0;
                this.SerializeMemStream.SetLength(0);

                // write (prelimiary) message header (might be changed later on, due to encryption, etc)
                if (!encrypt)
                {
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                }


                SerializeMemStream.Write(data, 0, data.Length);

                // if we encrypt, the message header was left out, as we encrypt only the operation bytes
                if (encrypt)
                {
                    byte[] opBytes = this.SerializeMemStream.ToArray();
                    opBytes = this.CryptoProvider.Encrypt(opBytes);

                    this.SerializeMemStream.Position = 0;
                    this.SerializeMemStream.SetLength(0);
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                    this.SerializeMemStream.Write(opBytes, 0, opBytes.Length);
                }

                fullMessageBytes = this.SerializeMemStream.ToArray();
            }

            // now update the message header according to type
            fullMessageBytes[messageHeader.Length - 1] = (byte)EgMessageType.RawMessage;

            if (encrypt)
            {
                fullMessageBytes[messageHeader.Length - 1] = (byte)(fullMessageBytes[messageHeader.Length - 1] | 0x80);
            }

            if (writeLength)
            {
                // update length in tcp header. it's at position 1 (to 4)
                int offsetForLength = 1;
                Protocol.Serialize((int)fullMessageBytes.Length, fullMessageBytes, ref offsetForLength);
            }

            return fullMessageBytes;
        }


        internal abstract byte[] SerializeOperationToMessage(byte opCode, Dictionary<byte, object> parameters, EgMessageType messageType, bool encrypt);

        internal abstract void ReceiveIncomingCommands(byte[] inBuff, int dataLength);

        internal void InitCallback()
        {
            if (this.peerConnectionState == ConnectionStateValue.Connecting)
            {
                // enet's connected state is set on verifyConnect (already done). tcp's state is set on init-response (here)
                this.peerConnectionState = ConnectionStateValue.Connected;
            }

            this.ApplicationIsInitialized = true;
            this.FetchServerTimestamp();
            this.Listener.OnStatusChanged(StatusCode.Connect); // updates the developer/application that connect is done
        }

        internal bool ApplicationIsInitialized;
        internal bool isEncryptionAvailable;

        internal static int outgoingStreamBufferSize = 1200;
        internal int outgoingCommandsInStream = 0;

        internal bool IsSendingOnlyAcks { get; set; }

        /// <summary> Maximum Transfer Unit to be used for UDP+TCP</summary>
        internal int mtu = 1200;

        /// <summary> (default=2) Rhttp: minimum number of open connections </summary>
        internal int rhttpMinConnections = 2;
        /// <summary> (default=6) Rhttp: maximum number of open connections, should be &gt; rhttpMinConnections </summary>
        internal int rhttpMaxConnections = 6;

        protected MemoryStream SerializeMemStream = new MemoryStream();

        /// <summary>
        /// Internally uses an operation to exchange encryption keys with the server.
        /// </summary>
        /// <returns>If the op could be sent.</returns>
        internal bool ExchangeKeysForEncryption()
        {
            isEncryptionAvailable = false;
            this.CryptoProvider = new DiffieHellmanCryptoProvider();

            Dictionary<byte, object> parameters = new Dictionary<byte, object>(1);
            parameters[PhotonCodes.ClientKey] = this.CryptoProvider.PublicKey;

            return this.EnqueueOperation(parameters, PhotonCodes.InitEncryption, true, 0, false, EgMessageType.InternalOperationRequest);
        }

        internal void DeriveSharedKey(OperationResponse operationResponse)
        {
            if (operationResponse.ReturnCode != PhotonCodes.Ok)
            {
                this.EnqueueDebugReturn(DebugLevel.ERROR, "Establishing encryption keys failed. " + operationResponse.ToStringFull());
                this.EnqueueStatusCallback(StatusCode.EncryptionFailedToEstablish);
                return;
            }

            byte[] serverPublicKey = (byte[])operationResponse[PhotonCodes.ServerKey];
            if (serverPublicKey == null || serverPublicKey.Length == 0)
            {
                this.EnqueueDebugReturn(DebugLevel.ERROR, "Establishing encryption keys failed. Server's public key is null or empty. " + operationResponse.ToStringFull());
                this.EnqueueStatusCallback(StatusCode.EncryptionFailedToEstablish);
                return;
            }

            this.CryptoProvider.DeriveSharedKey(serverPublicKey);
            this.isEncryptionAvailable = true;
            this.EnqueueStatusCallback(StatusCode.EncryptionEstablished);
        }

        internal void EnqueueActionForDispatch(MyAction action)
        {
            lock (this.ActionQueue)
            {
                this.ActionQueue.Enqueue(action);
            }
        }

        internal void EnqueueDebugReturn(DebugLevel level, string debugReturn)
        {
            lock (this.ActionQueue)
            {
                this.ActionQueue.Enqueue(delegate { this.Listener.DebugReturn(level, debugReturn); });
            }
        }

        internal void EnqueueStatusCallback(StatusCode statusValue)
        {
            lock (this.ActionQueue)
            {
                this.ActionQueue.Enqueue(delegate { this.Listener.OnStatusChanged(statusValue); });
            }
        }

        internal virtual void InitPeerBase()
        {
            this.TrafficStatsIncoming = new TrafficStats(this.TrafficPackageHeaderSize);
            this.TrafficStatsOutgoing = new TrafficStats(this.TrafficPackageHeaderSize);
            this.TrafficStatsGameLevel = new TrafficStatsGameLevel();
            this.ByteCountLastOperation = 0;
            this.ByteCountCurrentDispatch = 0;
            this.bytesIn = 0;
            this.bytesOut = 0;
            this.packetLossByCrc = 0;
            this.packetLossByChallenge = 0;
            this.networkSimulationSettings.LostPackagesIn = 0;
            this.networkSimulationSettings.LostPackagesOut = 0;
            lock (this.NetSimListOutgoing)
            {
                this.NetSimListOutgoing.Clear();
            }
            lock (this.NetSimListIncoming)
            {
                this.NetSimListIncoming.Clear();
            }

            this.peerConnectionState = ConnectionStateValue.Disconnected;
            this.timeBase = SupportClass.GetTickCount();
            this.isEncryptionAvailable = false;
            this.ApplicationIsInitialized = false;

            this.roundTripTime = ENET_PEER_DEFAULT_ROUND_TRIP_TIME;
            this.roundTripTimeVariance = 0;
            this.packetThrottleInterval = ENET_PEER_PACKET_THROTTLE_INTERVAL;

            this.serverTimeOffsetIsAvailable = false;
            this.serverTimeOffset = 0;
        }

        internal virtual bool DeserializeMessageAndCallback(byte[] inBuff)
        {
            // peer.Listener.DebugReturn("DeserializeMessageAndCallback()");
            // TODO: pick a fitting constant
            if (inBuff.Length < 2)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Incoming UDP data too short! " + inBuff.Length);
                }
                return false;
            }

            // check if header is OK and known or throw error
            if (inBuff[0] != 0xF3 && inBuff[0] != 0xFD)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ALL, "No regular operation UDP message: " + inBuff[0]);
                }
                return false;
            }

            // read message type from header-buffer (without the encryption-bit) and the encryption-bit
            byte msgType = (byte)(inBuff[1] & 0x7F);
            bool isEncrypted = (inBuff[1] & 0x80) > 0;

            // deserialize returned data
            MemoryStream stream = null;
            if (msgType != (byte)EgMessageType.InitResponse)
            {
                try
                {
                    if (isEncrypted)
                    {
                        inBuff = this.CryptoProvider.Decrypt(inBuff, 2, inBuff.Length - 2); // TODO: pick a fitting constant
                        stream = new MemoryStream(inBuff);
                    }
                    else
                    {
                        stream = new MemoryStream(inBuff);
                        stream.Seek(2, SeekOrigin.Begin); // TODO: pick a fitting constant
                    }
                }
                catch (Exception ex)
                {
                    if (this.debugOut >= DebugLevel.ERROR)
                    {
                        this.Listener.DebugReturn(DebugLevel.ERROR, ex.ToString());
                    }

                    SupportClass.WriteStackTrace(ex);

                    return false;
                }
            }

            int timeBeforeCallback = 0;

            switch (msgType)
            {
                case (byte)EgMessageType.OperationResponse:
                    OperationResponse opRes = Protocol.DeserializeOperationResponse(stream);

                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsGameLevel.CountResult(this.ByteCountCurrentDispatch);  // this.ByteCountCurrentDispatch was set before DeserializeMessageAndCallback() call
                        timeBeforeCallback = SupportClass.GetTickCount();
                    }

                    this.Listener.OnOperationResponse(opRes);

                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsGameLevel.TimeForResponseCallback(opRes.OperationCode, SupportClass.GetTickCount() - timeBeforeCallback);
                    }
                    break;

                case (byte)EgMessageType.Event:
                    EventData ev = Protocol.DeserializeEventData(stream);

                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsGameLevel.CountEvent(this.ByteCountCurrentDispatch);
                        timeBeforeCallback = SupportClass.GetTickCount();
                    }

                    this.Listener.OnEvent(ev);

                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsGameLevel.TimeForEventCallback(ev.Code, SupportClass.GetTickCount() - timeBeforeCallback);
                    }
                    break;

                case (byte)EgMessageType.InitResponse:
                    this.InitCallback();
                    break;

                case (byte)EgMessageType.InternalOperationResponse:
                    opRes = Protocol.DeserializeOperationResponse(stream);

                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsGameLevel.CountResult(this.ByteCountCurrentDispatch);
                        timeBeforeCallback = SupportClass.GetTickCount();
                    }

                    if (opRes.OperationCode == PhotonCodes.InitEncryption)
                    {
                        this.DeriveSharedKey(opRes);
                    }
                    else if (opRes.OperationCode == PhotonCodes.Ping)
                    {
                        #if !NoSocket
                        // TODO: use ping!
                        TPeer peer = this as TPeer;
                        if (peer != null) peer.ReadPingResult(opRes);
                        else this.EnqueueDebugReturn(DebugLevel.ERROR, "Ping response not used. "+opRes.ToStringFull());
                        #endif
                    }
                    else
                    {
                        this.EnqueueDebugReturn(DebugLevel.ERROR, "Received unknown internal operation. " + opRes.ToStringFull());
                    }

                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsGameLevel.TimeForResponseCallback(opRes.OperationCode, SupportClass.GetTickCount() - timeBeforeCallback);
                    }
                    break;

#if SDK_V4
                case (byte)EgMessageType.Message:
                    {
                        var message = Protocol.DeserializeMessage(stream);
                        if (this.TrafficStatsEnabled)
                        {
                            this.TrafficStatsGameLevel.CountEvent(this.ByteCountCurrentDispatch);
                            timeBeforeCallback = SupportClass.GetTickCount();
                        }

                        this.Listener.OnMessage(message);

                        if (this.TrafficStatsEnabled)
                        {
                            this.TrafficStatsGameLevel.TimeForMessageCallback(SupportClass.GetTickCount() - timeBeforeCallback);
                        }

                    }
                    break;
                case (byte)EgMessageType.RawMessage:
                    {
                        if (this.TrafficStatsEnabled)
                        {
                            this.TrafficStatsGameLevel.CountEvent(this.ByteCountCurrentDispatch);
                            timeBeforeCallback = SupportClass.GetTickCount();
                        }
                        byte[] data = new byte[inBuff.Length - 2];
                        Buffer.BlockCopy(inBuff, 2, data, 0, inBuff.Length - 2);

                        this.Listener.OnMessage(data);

                        if (this.TrafficStatsEnabled)
                        {
                            this.TrafficStatsGameLevel.TimeForRawMessageCallback(SupportClass.GetTickCount() - timeBeforeCallback);
                        }
                    }
                    break;
#endif//SDK_V4
                default:
                    this.EnqueueDebugReturn(DebugLevel.ERROR, "unexpected msgType " + msgType);
                    break;
            }

            return true;
        }

        internal void SendNetworkSimulated(MyAction sendAction)
        {
            if (!NetworkSimulationSettings.IsSimulationEnabled)
            {
                sendAction();
                return;
            }

            if (this.usedProtocol == ConnectionProtocol.Udp && NetworkSimulationSettings.OutgoingLossPercentage > 0 && this.lagRandomizer.Next(101) < NetworkSimulationSettings.OutgoingLossPercentage)
            {
                // this package is lost due to OutgoingLossPercentage
                this.networkSimulationSettings.LostPackagesOut++;
                return;
            }

            int jitter = (this.networkSimulationSettings.OutgoingJitter <= 0) ? 0 : (this.lagRandomizer.Next(this.networkSimulationSettings.OutgoingJitter * 2) - this.networkSimulationSettings.OutgoingJitter);
            int delay = this.networkSimulationSettings.OutgoingLag + jitter;
            int timeToExecute = SupportClass.GetTickCount() + delay;
            SimulationItem simItem = new SimulationItem() { ActionToExecute = sendAction, TimeToExecute = timeToExecute, Delay = delay };

            lock (this.NetSimListOutgoing)
            {
                if (this.NetSimListOutgoing.Count == 0 || this.usedProtocol == ConnectionProtocol.Tcp)
                {
                    this.NetSimListOutgoing.AddLast(simItem);
                }
                else
                {
                    // the order of UDP packages can be mixed up by jitter and changing lag.
                    var node = this.NetSimListOutgoing.First;
                    while (node != null && node.Value.TimeToExecute < timeToExecute)
                    {
                        node = node.Next;
                    }

                    if (node == null)
                    {
                        this.NetSimListOutgoing.AddLast(simItem);
                    }
                    else
                    {
                        this.NetSimListOutgoing.AddBefore(node, simItem);
                    }
                }
            }
        }

        internal void ReceiveNetworkSimulated(MyAction receiveAction)
        {
            if (!this.networkSimulationSettings.IsSimulationEnabled)
            {
                receiveAction();
                return;
            }

            if (this.usedProtocol == ConnectionProtocol.Udp && this.networkSimulationSettings.IncomingLossPercentage > 0 && this.lagRandomizer.Next(101) < this.networkSimulationSettings.IncomingLossPercentage)
            {
                // this package is lost due to IncomingLossPercentage
                this.networkSimulationSettings.LostPackagesIn++;
                return;
            }

            int jitter = (this.networkSimulationSettings.IncomingJitter <= 0) ? 0 : (this.lagRandomizer.Next(this.networkSimulationSettings.IncomingJitter * 2) - this.networkSimulationSettings.IncomingJitter);
            int delay = this.networkSimulationSettings.IncomingLag + jitter;
            int timeToExecute = SupportClass.GetTickCount() + delay;
            SimulationItem simItem = new SimulationItem() { ActionToExecute = receiveAction, TimeToExecute = timeToExecute, Delay = delay };

            lock (this.NetSimListIncoming)
            {
                if (this.NetSimListIncoming.Count == 0 || this.usedProtocol == ConnectionProtocol.Tcp)
                {
                    this.NetSimListIncoming.AddLast(simItem);
                }
                else
                {
                    // the order of UDP packages can be mixed up by jitter and changing lag.
                    var node = this.NetSimListIncoming.First;
                    while (node != null && node.Value.TimeToExecute < timeToExecute)
                    {
                        node = node.Next;
                    }

                    if (node == null)
                    {
                        this.NetSimListIncoming.AddLast(simItem);
                    }
                    else
                    {
                        this.NetSimListIncoming.AddBefore(node, simItem);
                    }
                }
            }
        }

        /// <summary>
        /// Core of the Network Simulation, which is available in Debug builds.
        /// Called by a timer in intervals.
        /// </summary>
        protected internal void NetworkSimRun()
        {
            while (true)
            {
                bool enabled = false;
                lock (this.networkSimulationSettings.NetSimManualResetEvent)
                {
                    enabled = this.networkSimulationSettings.IsSimulationEnabled;
                }

                if (!enabled)
                {
                    this.networkSimulationSettings.NetSimManualResetEvent.WaitOne();
                    continue;
                }

                lock (this.NetSimListIncoming)
                {
                    SimulationItem item = null;
                    while (this.NetSimListIncoming.First != null)
                    {
                        item = this.NetSimListIncoming.First.Value;
                        if (item.stopw.ElapsedMilliseconds < item.Delay)
                        {
                            break;
                        }

                        item.ActionToExecute();
                        this.NetSimListIncoming.RemoveFirst();
                    }
                }

                lock (this.NetSimListOutgoing)
                {
                    SimulationItem item = null;
                    while (this.NetSimListOutgoing.First != null)
                    {
                        item = this.NetSimListOutgoing.First.Value;
                        if (item.stopw.ElapsedMilliseconds < item.Delay)
                        {
                            break;
                        }

                        item.ActionToExecute();
                        this.NetSimListOutgoing.RemoveFirst();
                    }
                }
#if !NETFX_CORE
                Thread.Sleep(0);
#endif
            }
        }

        internal void UpdateRoundTripTimeAndVariance(int lastRoundtripTime)
        {
            if (lastRoundtripTime < 0)
            {
                return;
            }

            roundTripTimeVariance -= roundTripTimeVariance / 4;
            if (lastRoundtripTime >= roundTripTime)
            {
                roundTripTime += (lastRoundtripTime - roundTripTime) / 8;
                roundTripTimeVariance += (lastRoundtripTime - roundTripTime) / 4;
            }
            else
            {
                roundTripTime += (lastRoundtripTime - roundTripTime) / 8;
                roundTripTimeVariance -= (lastRoundtripTime - roundTripTime) / 4;
            }

            if (roundTripTime < lowestRoundTripTime)
            {
                lowestRoundTripTime = roundTripTime;
            }

            if (roundTripTimeVariance > highestRoundTripTimeVariance)
            {
                highestRoundTripTimeVariance = roundTripTimeVariance;
            }
        }

        internal void InitializeTrafficStats()
        {
            this.TrafficStatsIncoming = new TrafficStats(this.TrafficPackageHeaderSize);
            this.TrafficStatsOutgoing = new TrafficStats(this.TrafficPackageHeaderSize);
            this.TrafficStatsGameLevel = new TrafficStatsGameLevel();
            this.trafficStatsStopwatch = new Stopwatch();
        }

    }

    #region Command Log Classes

    // what to log
    // Received ACKs        - Now, Channel, SqNr, Rtt/V,  SentTime, Diff
    // Send/Resent Reliable - Now, Channel, SqNr, Rtt/V,  Timeout, Resend#

    internal class CmdLogItem
    {
        public int TimeInt;
        public int Channel;
        public int SequenceNumber;
        public int Rtt;
        public int Variance;

        public CmdLogItem()
        {
        }

        public CmdLogItem(NCommand command, int timeInt, int rtt, int variance)
        {
            this.Channel = command.commandChannelID;
            this.SequenceNumber = command.reliableSequenceNumber;
            this.TimeInt = timeInt;
            this.Rtt = rtt;
            this.Variance = variance;
        }

        public override string ToString()
        {
            return string.Format("NOW: {0,5}  CH: {1,3} SQ: {2,4} RTT: {3,4} VAR: {4,3}", this.TimeInt, this.Channel, this.SequenceNumber, this.Rtt, this.Variance);
        }
    }

    internal class CmdLogReceivedReliable : CmdLogItem
    {
        public int TimeSinceLastSend;
        public int TimeSinceLastSendAck;

        public CmdLogReceivedReliable(NCommand command, int timeInt, int rtt, int variance, int timeSinceLastSend, int timeSinceLastSendAck) : base(command, timeInt, rtt, variance)
        {
            this.TimeSinceLastSend = timeSinceLastSend;
            this.TimeSinceLastSendAck = timeSinceLastSendAck;
        }

        public override string ToString()
        {
            return string.Format("Read reliable. {0}  TimeSinceLastSend: {1} TimeSinceLastSendAcks: {2}", base.ToString(), this.TimeSinceLastSend, this.TimeSinceLastSendAck);
        }
    }


    internal class CmdLogReceivedAck : CmdLogItem
    {
        public int ReceivedSentTime;

        public CmdLogReceivedAck(NCommand command, int timeInt, int rtt, int variance)
        {
            this.TimeInt = timeInt;
            this.Channel = command.commandChannelID;
            this.SequenceNumber = command.ackReceivedReliableSequenceNumber;
            this.Rtt = rtt;
            this.Variance = variance;
            this.ReceivedSentTime = command.ackReceivedSentTime;
        }

        public override string ToString()
        {
            return string.Format("ACK  NOW: {0,5}  CH: {1,3} SQ: {2,4} RTT: {3,4} VAR: {4,3}  Sent: {5,5} Diff: {6,4}", this.TimeInt, this.Channel, this.SequenceNumber, this.Rtt, this.Variance, this.ReceivedSentTime, (this.TimeInt - this.ReceivedSentTime));
        }
    }

    internal class CmdLogSentReliable : CmdLogItem
    {
        public int Resend;
        public int RoundtripTimeout;
        public int Timeout;
        public bool TriggeredTimeout;

        public CmdLogSentReliable(NCommand command, int timeInt, int rtt, int variance, bool triggeredTimeout = false)
        {
            this.TimeInt = timeInt;
            this.Channel = command.commandChannelID;
            this.SequenceNumber = command.reliableSequenceNumber;
            this.Rtt = rtt;
            this.Variance = variance;
            this.Resend = command.commandSentCount;
            this.RoundtripTimeout = command.roundTripTimeout;
            this.Timeout = command.timeoutTime;
            this.TriggeredTimeout = triggeredTimeout;
        }

        public override string ToString()
        {
            return string.Format("SND  NOW: {0,5}  CH: {1,3} SQ: {2,4} RTT: {3,4} VAR: {4,3}  Resend#: {5,2} ResendIn: {7} Timeout: {6,5} {8}", this.TimeInt, this.Channel, this.SequenceNumber, this.Rtt, this.Variance, this.Resend, this.Timeout, this.RoundtripTimeout, (this.TriggeredTimeout ? "< TIMEOUT" : ""));
        }
    }

    #endregion

}

