// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EnetPeer.cs" company="Exit Games GmbH">
//   Protocol & Photon Client Lib - Copyright (C) 2010 Exit Games GmbH
// </copyright>
// <summary>
//   Implementation of a enet compatible peer.
// </summary>
// <author>developer@photonengine.com</author>
// --------------------------------------------------------------------------------------------------------------------

namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections.Generic;

    internal class EnetPeer : PeerBase
    {
        #region Fields & Properties

        private const int CRC_LENGTH = 4; // byte-count for CRC

        internal override int QueuedIncomingCommandsCount
        {
            get
            {
                int x = 0;
                lock (this.channels)
                {
                    foreach (EnetChannel c in this.channels.Values)
                    {
                        x += c.incomingReliableCommandsList.Count;
                        x += c.incomingUnreliableCommandsList.Count;
                    }
                }

                return x;
            }
        }

        internal override int QueuedOutgoingCommandsCount
        {
            get
            {
                int x = 0;
                lock (this.channels)
                {
                    foreach (EnetChannel c in this.channels.Values)
                    {
                        x += c.outgoingReliableCommandsList.Count;
                        x += c.outgoingUnreliableCommandsList.Count;
                    }
                }

                return x;
            }
        }

        /// <summary>Will contain channel 0xFF and any other.</summary>
        private Dictionary<byte, EnetChannel> channels = new Dictionary<byte, EnetChannel>();

        /// <summary>One list for all channels keeps sent commands (for re-sending).</summary>
        private List<NCommand> sentReliableCommands = new List<NCommand>(); // todo: Could be a dictionary instead?

        /// <summary>One list for all channels keeps acknowledgements.</summary>
        private Queue<NCommand> outgoingAcknowledgementsList = new Queue<NCommand>();

        internal readonly int windowSize = 4 * 32;      // check value! so far used in server only
        //internal int[] unsequencedWindow;
        //internal int outgoingUnsequencedGroupNumber; //assigned for each outgoing (created) unsequenced command
        //internal int incomingUnsequencedGroupNumber; //assigned for each outgoing (created) unsequenced command

        private byte udpCommandCount;  // replaces the list of Host.commands; simply counts the commands which went into the same UDP package
        private byte[] udpBuffer;      // replaces Host.buffers; collects the commands until the udp-packet is sent
        private int udpBufferIndex;    // replaces Host.buffers; last written byte in buffer / size of buffer
        // internal int commandSize = 12;

        // headers for UDP packet - taken from "Header"
        internal int challenge;

        // variables for packetloss, roundtriptimes, variance and more
        internal int reliableCommandsRepeated;
        internal int reliableCommandsSent;      // number of reliable-packages sent
        //internal int packetLossEpoch;
        //internal int packetLossVariance;
        //internal int packetThrottleEpoch;
        internal int serverSentTime;    // timestamp the server sent in last udp package (enet header)

        internal static readonly byte[] udpHeader0xF3 = { 0xF3, 2 };   //2 bytes binary protocol header

        internal static readonly byte[] messageHeader = udpHeader0xF3;

        private byte[] initData = null;
        #endregion

        //------------------------------------------------------------------------------------------------------------------

        internal EnetPeer()
        {
            peerCount++;

            this.InitOnce();
            this.TrafficPackageHeaderSize = NCommand.HEADER_UDP_PACK_LENGTH;
        }

        internal EnetPeer(IPhotonPeerListener listener) : this()
        {
            // the check that the listener is non-null is done in PhotonPeer (where this is created)
            this.Listener = listener;
        }

        private EnetChannel[] channelArray = new EnetChannel[0];

        internal override void InitPeerBase()
        {
            base.InitPeerBase();

            this.peerID = unchecked((short)0xFFFF);
            this.challenge = SupportClass.ThreadSafeRandom.Next();
            this.udpBuffer = new byte[this.mtu];

            this.reliableCommandsSent = 0;
            this.reliableCommandsRepeated = 0;

            lock (this.channels)
            {
                this.channels = new Dictionary<byte, EnetChannel>();
            }

            lock (this.channels)
            {
                this.channels[0xFF] = new EnetChannel(0xFF, this.commandBufferSize);
                for (byte i = 0; i < this.ChannelCount; i++)
                {
                    this.channels[i] = new EnetChannel(i, this.commandBufferSize);
                }

                this.channelArray = new EnetChannel[this.ChannelCount + 1];
                int c = 0;
                foreach (EnetChannel channel in this.channels.Values)
                {
                    this.channelArray[c++] = channel;
                }
            }

            lock (this.sentReliableCommands)
            {
                this.sentReliableCommands = new List<NCommand>(this.commandBufferSize);
            }

            lock (this.outgoingAcknowledgementsList)
            {
                this.outgoingAcknowledgementsList = new Queue<NCommand>(this.commandBufferSize);
            }

            this.CommandLogInit();
        }

#if SDK_V4
        internal override bool Connect(string ipport, string appID, object custom)
        {
            if (peerConnectionState != ConnectionStateValue.Disconnected)
            {
                this.Listener.DebugReturn(DebugLevel.WARNING, "Connect() can't be called if peer is not Disconnected. Not connecting. peerConnectionState: " + peerConnectionState);
                return false;
            }

            if (debugOut >= DebugLevel.ALL)
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "Connect()");
            }

            ServerAddress = ipport;
            this.InitPeerBase();

            // the RealtimeServer can run multiple applications (by name/applicationName) - the default is called "LoadBalancing");
            if (appID == null)
            {
                appID = "LoadBalancing";
            }

#if NoSocket
            if (SocketImplementation != null)
            {
                if (SocketImplementation == typeof (SocketUdpNativeStatic))
                {
                    rt = (IPhotonSocket) new SocketUdpNativeStatic(this);
                }
                else if (SocketImplementation == typeof (SocketUdpNativeDynamic))
                {
                    rt = (IPhotonSocket) new SocketUdpNativeDynamic(this);
                }
                else
                {
                    rt = (IPhotonSocket)Activator.CreateInstance(SocketImplementation, this);
                }
            }
#elif  (NETFX_CORE || WINDOWS_PHONE)
            this.rt = new SocketUdpNetFxCore(this);
#else
            this.rt = new SocketUdp(this);
#endif

            if (this.rt == null)
            {
                this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() failed, because SocketImplementation or socket was null. Set PhotonPeer.SocketImplementation before Connect().");
                return false;
            }

            //the connection itself is created and started in the thread
            if (rt.Connect())
            {
                if (this.TrafficStatsEnabled)
                {
                    this.TrafficStatsOutgoing.ControlCommandBytes += NCommand.CmdSizeConnect;
                    this.TrafficStatsOutgoing.ControlCommandCount += 1;
                }

                this.initData = PrepareConnectData(rt.ServerAddress, appID, custom);
                peerConnectionState = ConnectionStateValue.Connecting;
                QueueOutgoingReliableCommand(new NCommand(this, NCommand.CT_CONNECT, null, 0xFF));
                return true;
            }

            return false;
        }
#endif//SDK_V4

        internal override bool Connect(string ipport, string appID)
        {
            if (peerConnectionState != ConnectionStateValue.Disconnected)
            {
                this.Listener.DebugReturn(DebugLevel.WARNING, "Connect() can't be called if peer is not Disconnected. Not connecting. peerConnectionState: " + peerConnectionState);
                return false;
            }

            if (debugOut >= DebugLevel.ALL)
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "Connect()");
            }

            ServerAddress = ipport;
            this.InitPeerBase();

            // the RealtimeServer can run multiple applications (by name/applicationName) - the default is called "LoadBalancing");
            if (appID == null)
            {
                appID = "LoadBalancing";
            }
            for (int i = 0; i < 32; i++)
            {
                this.INIT_BYTES[i + 9] = (i < appID.Length) ? (byte)appID[i] : (byte)0;
            }

            this.initData = INIT_BYTES;

#if NoSocket
            if (SocketImplementation != null)
            {
                if (SocketImplementation == typeof (SocketUdpNativeStatic))
                {
                    rt = (IPhotonSocket) new SocketUdpNativeStatic(this);
                }
                else if (SocketImplementation == typeof (SocketUdpNativeDynamic))
                {
                    rt = (IPhotonSocket) new SocketUdpNativeDynamic(this);
                }
                else
                {
                    rt = (IPhotonSocket)Activator.CreateInstance(SocketImplementation, this);
                }
            }
#elif  (NETFX_CORE || WINDOWS_PHONE)
            this.rt = new SocketUdpNetFxCore(this);
#else
            this.rt = new SocketUdp(this);
#endif

            if (this.rt == null)
            {
                this.Listener.DebugReturn(DebugLevel.ERROR, "Connect() failed, because SocketImplementation or socket was null. Set PhotonPeer.SocketImplementation before Connect().");
                return false;
            }

            //the connection itself is created and started in the thread
            if (rt.Connect())
            {
                if (this.TrafficStatsEnabled)
                {
                    this.TrafficStatsOutgoing.ControlCommandBytes += NCommand.CmdSizeConnect;
                    this.TrafficStatsOutgoing.ControlCommandCount += 1;
                }

                peerConnectionState = ConnectionStateValue.Connecting;
                QueueOutgoingReliableCommand(new NCommand(this, NCommand.CT_CONNECT, null, 0xFF));
                return true;
            }

            return false;
        }

        internal override void Disconnect()
        {
            if (peerConnectionState == ConnectionStateValue.Disconnected || peerConnectionState == ConnectionStateValue.Disconnecting)
            {
                return;
            }

            // reset/empty queues
            if (this.outgoingAcknowledgementsList != null)
            {
                lock (this.outgoingAcknowledgementsList)
                {
                    this.outgoingAcknowledgementsList.Clear();
                }
            }

            if (this.sentReliableCommands != null)
            {
                lock (this.sentReliableCommands)
                {
                    this.sentReliableCommands.Clear();
                }
            }

            lock (this.channels)
            {
                foreach (EnetChannel c in this.channels.Values)
                {
                    c.clearAll();
                }
            }
            bool oldSettings = this.NetworkSimulationSettings.IsSimulationEnabled;
            this.NetworkSimulationSettings.IsSimulationEnabled = false;
            // note: connected peers send a reliable disconnect command. any other state sends as unsequenced
            NCommand disconnectCommand = new NCommand(this, NCommand.CT_DISCONNECT, null, 0xFF);
            this.QueueOutgoingReliableCommand(disconnectCommand);//TODO: if not connected, this is unsequenced and not reliable
            this.SendOutgoingCommands(); // send immediately (the lock (this.peer.SendOutgoingLockObject) must be done in PhotonPeer)

            if (this.TrafficStatsEnabled)
            {
                this.TrafficStatsOutgoing.CountControlCommand(disconnectCommand.Size);
            }

            // destroy self by stopping the connection thread
            this.rt.Disconnect();
            this.NetworkSimulationSettings.IsSimulationEnabled = oldSettings;
            peerConnectionState = ConnectionStateValue.Disconnected;
            this.Listener.OnStatusChanged(StatusCode.Disconnect);
        }

        internal override void StopConnection()
        {
            if (this.rt != null)
            {
                this.rt.Disconnect();
            }
            peerConnectionState = ConnectionStateValue.Disconnected;

            if (this.Listener != null)
            {
                this.Listener.OnStatusChanged(StatusCode.Disconnect);
            }
        }

        internal override void FetchServerTimestamp()
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.INFO)
                {
                    this.EnqueueDebugReturn(DebugLevel.INFO, "FetchServerTimestamp() was skipped, as the client is not connected. Current ConnectionState: " + this.peerConnectionState);
                }

                return;
            }

            this.CreateAndEnqueueCommand(NCommand.CT_EG_SERVERTIME, new byte[0], 0xFF);
        }

        private Queue<int> commandsToRemove = new Queue<int>();


        /// <summary>
        /// Checks the incoming queue and Dispatches received data if possible.
        /// </summary>
        /// <returns>If a Dispatch happened or not, which shows if more Dispatches might be needed.</returns>
        internal override bool DispatchIncomingCommands()
        {
            // TODO: re-enable this code, if we want/need to support PollReceive
            //if (this.rt.PollReceive)
            //{
            //    throw new NotImplementedException("DispatchIncomingCommands() can't poll datagrams yet.");
            //}

            // dispatch action queue keeping the lock minimal (this is done intentionally)
            MyAction action;
            while (true)
            {
                lock (this.ActionQueue)
                {
                    if (this.ActionQueue.Count <= 0) { break; }
                    action = this.ActionQueue.Dequeue();
                }

                action();
            }

            // dispatch commands - going through each channel
            NCommand command = null;

            lock (this.channels)
            {
                for (int index = 0; index < this.channelArray.Length; index++)
                {
                    EnetChannel channel = this.channelArray[index];

                    // check unreliable first
                    if (channel.incomingUnreliableCommandsList.Count > 0)
                    {
                        int lowestAvailableUnreliableCommandNumber = int.MaxValue;
                        foreach (int sequenceNumber in channel.incomingUnreliableCommandsList.Keys)
                        {
                            NCommand cmd = channel.incomingUnreliableCommandsList[sequenceNumber];

                            // discard outdated commands (if unreliable OR reliable sequence is past "this" unreliable command)
                            if (sequenceNumber < channel.incomingUnreliableSequenceNumber || cmd.reliableSequenceNumber < channel.incomingReliableSequenceNumber)
                            {
                                this.commandsToRemove.Enqueue(sequenceNumber);
                                continue;
                            }

                            // truncate to limit of unreliable commands we simply assume here that the list is (more or less) ordered
                            if (this.limitOfUnreliableCommands > 0 && channel.incomingUnreliableCommandsList.Count > this.limitOfUnreliableCommands)
                            {
                                this.commandsToRemove.Enqueue(sequenceNumber);
                                continue;
                            }

                            // we checked if command is outdated or should be ignored by limit. now check if reliable sequence has to catch up
                            if (sequenceNumber < lowestAvailableUnreliableCommandNumber)
                            {
                                if (cmd.reliableSequenceNumber > channel.incomingReliableSequenceNumber)
                                {
                                    continue;
                                }

                                lowestAvailableUnreliableCommandNumber = sequenceNumber;
                            }
                        }

                        // now commands are actually removed from the incomingUnreliableCommandsList
                        while (this.commandsToRemove.Count > 0)
                        {
                            channel.incomingUnreliableCommandsList.Remove(this.commandsToRemove.Dequeue());
                        }

                        if (lowestAvailableUnreliableCommandNumber < int.MaxValue)
                        {
                            command = channel.incomingUnreliableCommandsList[lowestAvailableUnreliableCommandNumber];
                        }

                        if (command != null)
                        {
                            channel.incomingUnreliableCommandsList.Remove(command.unreliableSequenceNumber);
                            channel.incomingUnreliableSequenceNumber = command.unreliableSequenceNumber;
                            break;
                        }
                    }

                    // now check reliable if no unreliable command is to be Dispatched
                    if (command == null && channel.incomingReliableCommandsList.Count > 0)
                    {
                        channel.incomingReliableCommandsList.TryGetValue(channel.incomingReliableSequenceNumber + 1, out command);

                        // if no command was found in incoming-reliable queue of this channel, check next channel
                        if (command == null)
                        {
                            continue; // next channel!
                        }

                        if (command.commandType != NCommand.CT_SENDFRAGMENT)
                        {
                            // set new incoming reliable sequence number and remove this command (Dispatched below)
                            channel.incomingReliableSequenceNumber = command.reliableSequenceNumber;

                            // updates last Dispatched reliableSequenceNumber
                            channel.incomingReliableCommandsList.Remove(command.reliableSequenceNumber);
                            break;
                        }
                        // fragments must be complete and get their payload combined into one
                        if (command.fragmentsRemaining > 0)
                        {
                            command = null;
                        }
                        else
                        {
                            NCommand fragment;
                            byte[] completePayload = new byte[command.totalLength];
                            int fragmentSequenceNumber = command.startSequenceNumber;

                            while (fragmentSequenceNumber < command.startSequenceNumber + command.fragmentCount)
                            {
                                if (channel.ContainsReliableSequenceNumber(fragmentSequenceNumber))
                                {
                                    // plausibility checks for fragments are done when they are read from the packages

                                    fragment = channel.FetchReliableSequenceNumber(fragmentSequenceNumber);
                                    Buffer.BlockCopy(fragment.Payload, 0, completePayload, fragment.fragmentOffset, fragment.Payload.Length);
                                    channel.incomingReliableCommandsList.Remove(fragment.reliableSequenceNumber);
                                }
                                else
                                {
                                    throw new Exception("command.fragmentsRemaining was 0, but not all fragments are found to be combined!");
                                }

                                fragmentSequenceNumber++;
                            }

                            if (this.debugOut >= DebugLevel.ALL)
                            {
                                this.Listener.DebugReturn(DebugLevel.ALL, "assembled fragmented payload from " + command.fragmentCount + " parts. Dispatching now.");
                            }

                            command.Payload = completePayload;
                            command.Size = NCommand.CmdSizeReliableHeader*command.fragmentCount + command.totalLength;
                            channel.incomingReliableSequenceNumber = command.reliableSequenceNumber + command.fragmentCount - 1;

                            // updates last Dispatched reliableSequenceNumber
                        }

                        break; // when we're here, a command was found. don't continue search in another channel
                    }
                }
            } // lock (this.channels)

            // finally: Dispatch command (as OP return or EV)
            if (command != null && command.Payload != null)
            {
                this.ByteCountCurrentDispatch = command.Size;
#if DEBUG
                this.CommandInCurrentDispatch = command;
#endif
                // either calls eventAction() OR OnStatusChanged() - return: success);
                if (this.DeserializeMessageAndCallback(command.Payload))
                {
#if DEBUG
                    this.CommandInCurrentDispatch = null;
#endif
                    return true;
                }
#if DEBUG
                this.CommandInCurrentDispatch = null;
#endif
            }

            return false;
        }

        /// <summary>
        /// gathers acks until udp-packet is full and sends it!
        /// </summary>
        internal override bool SendAcksOnly()
        {
            if (this.peerConnectionState == ConnectionStateValue.Disconnected)
            {
                return false;
            }

            if (this.rt == null || !this.rt.Connected)
            {
                return false;
            }

            lock (this.udpBuffer)
            {
                // init
                int remainingCommands = 0;
                this.udpBufferIndex = NCommand.HEADER_UDP_PACK_LENGTH;

                if (this.crcEnabled)
                {
                    this.udpBufferIndex += CRC_LENGTH;
                }
                this.udpCommandCount = 0;

                this.timeInt = SupportClass.GetTickCount() - this.timeBase;

                // put ACKs into package
                lock (this.outgoingAcknowledgementsList)
                {
                    if (this.outgoingAcknowledgementsList.Count > 0)
                    {
                        remainingCommands = this.SerializeToBuffer(this.outgoingAcknowledgementsList);
                        this.timeLastSendAck = this.timeInt;
                    }
                }

                // check for timeouts/repeats (need to send again or timeout)
                if (this.timeInt > this.timeoutInt && this.sentReliableCommands.Count > 0)
                {
                    lock (this.sentReliableCommands)
                    {
                        // check sent reliable commands and re-send them if nessessary

                        foreach (NCommand command in this.sentReliableCommands)
                        {
                            // check if the command has to be resent
                            if (command != null && command.roundTripTimeout != 0 && this.timeInt - command.commandSentTime > command.roundTripTimeout)
                            {
                                command.commandSentCount = 1;
                                    // mark as sent once (a higher number has potential to fail quickly when we resume sending)
                                command.roundTripTimeout = 0;
                                    // set maximum timeout timespan (re-set in SendOutgoingCommands, when we actully re-send the command)
                                command.timeoutTime = int.MaxValue;
                                command.commandSentTime = this.timeInt;
                            }
                        }
                    } // lock(sent reliable commands)
                }

                // we send neither reliable nor unreliable commands

                // if nothing made it into the package, skip sending it
                if (this.udpCommandCount <= 0)
                {
                    return false;
                }

                if (this.TrafficStatsEnabled)
                {
                    this.TrafficStatsOutgoing.TotalPacketCount++;
                    this.TrafficStatsOutgoing.TotalCommandsInPackets += this.udpCommandCount;
                }

                // we counted the length in udpBufferIndex, so we can use that to send
                this.SendData(this.udpBuffer, this.udpBufferIndex);

                return remainingCommands > 0;
            }
        }

        /// <summary>
        /// gathers commands from all (out)queues until udp-packet is full and sends it!
        /// </summary>
        internal override bool SendOutgoingCommands()
        {
            if (this.peerConnectionState == ConnectionStateValue.Disconnected)
            {
                return false;
            }

            if (!this.rt.Connected)
            {
                return false;
            }

            lock (this.udpBuffer)
            {
                // init
                int remainingCommands = 0;
                this.udpBufferIndex = NCommand.HEADER_UDP_PACK_LENGTH;
                if (crcEnabled)
                {
                    this.udpBufferIndex += CRC_LENGTH;
                }
                this.udpCommandCount = 0;

                this.timeInt = SupportClass.GetTickCount() - this.timeBase;
                this.timeLastSendOutgoing = this.timeInt;

                // put ACKs into package
                lock (this.outgoingAcknowledgementsList)
                {
                    if (this.outgoingAcknowledgementsList.Count > 0)
                    {
                        remainingCommands = this.SerializeToBuffer(this.outgoingAcknowledgementsList);
                        this.timeLastSendAck = this.timeInt;
                    }
                }

                // check for timeouts/repeats (need to send again or timeout)
                if (!this.IsSendingOnlyAcks && this.timeInt > this.timeoutInt && this.sentReliableCommands.Count > 0)
                {
                    lock (this.sentReliableCommands)
                    {
                        // check sent reliable commands and gather those that need resending
                        Queue<NCommand> commandsToResend = new Queue<NCommand>();
                        foreach (NCommand command in this.sentReliableCommands)
                        {
                            // check if the command has to be resent
                            if (command != null && this.timeInt - command.commandSentTime > command.roundTripTimeout)
                            {
                                // check if command is TOO old and disconnect peer
                                // TODO: fix! "timeInt > command.timeoutTime" will produce wrong results on overflows every about 42.5 days!
                                if (command.commandSentCount > this.sentCountAllowance || this.timeInt > command.timeoutTime)
                                {
                                    if (this.debugOut >= DebugLevel.WARNING)
                                    {
                                        this.Listener.DebugReturn(DebugLevel.WARNING, "Timeout-disconnect! Command: " + command + " now: " + this.timeInt + " challenge: " + Convert.ToString(this.challenge, 16));
                                    }

                                    if (this.CommandLog != null)
                                    {
                                        this.CommandLog.Enqueue(new CmdLogSentReliable(command, this.timeInt, this.roundTripTime, this.roundTripTimeVariance, true));
                                        this.CommandLogResize();
                                    }

                                    // this command was repeated too often or is already too old to repeat. this causes a (client) timeout
                                    this.peerConnectionState = ConnectionStateValue.Zombie;
                                    this.Listener.OnStatusChanged(StatusCode.TimeoutDisconnect);
                                    this.Disconnect();
                                    return false;
                                }

                                commandsToResend.Enqueue(command); // the command can be resend but we don't want to modify the list in the foreach
                            }
                        }

                        // re-send anything worth re-sending (put them in outgoing queue)
                        while (commandsToResend.Count > 0)
                        {
                            NCommand command = commandsToResend.Dequeue();

                            // re-send command and remove it from sent-queue
                            this.QueueOutgoingReliableCommand(command);
                            this.sentReliableCommands.Remove(command);

                            // count the resends and provide debug out
                            this.reliableCommandsRepeated++;
                            if (this.debugOut >= DebugLevel.INFO)
                            {
                                this.Listener.DebugReturn(DebugLevel.INFO, string.Format("Resending: {0}. times out after: {1} sent: {3} now: {2} rtt/var: {4}/{5} last recv: {6}", command, command.roundTripTimeout, this.timeInt, command.commandSentTime, this.roundTripTime, this.roundTripTimeVariance, (SupportClass.GetTickCount() - this.timestampOfLastReceive)));
                            }
                        }
                    } // lock (this.sentReliableCommands)
                }

                // ping should only be sent in intervals when no reliable command is in transit (sent, repeating or in out queues)
                if (!this.IsSendingOnlyAcks
                    && this.peerConnectionState == ConnectionStateValue.Connected
                    && this.timePingInterval > 0
                    && this.sentReliableCommands.Count == 0
                    && (this.timeInt - this.timeLastAckReceive) > this.timePingInterval
                    && !this.AreReliableCommandsInTransit()
                    && this.udpBufferIndex + NCommand.CmdSizePing < this.udpBuffer.Length)
                {
                    // this.Listener.DebugReturn("add PING");
                    NCommand command = new NCommand(this, NCommand.CT_PING, null, 0xFF);
                    this.QueueOutgoingReliableCommand(command);
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsOutgoing.CountControlCommand(command.Size);
                    }
                }

                // after repeats and pings were checked, serialize the queues (per channel)
                if (!this.IsSendingOnlyAcks)
                {
                    lock (this.channels)
                    {
                        for (int index = 0; index < this.channelArray.Length; index++)
                        {
                            EnetChannel channel = this.channelArray[index];

                            // reliable commands (if any. else: check ping interval)
                            remainingCommands += this.SerializeToBuffer(channel.outgoingReliableCommandsList);

                            // unreliable
                            remainingCommands += this.SerializeToBuffer(channel.outgoingUnreliableCommandsList);
                        }
                    }
                }

                // if nothing made it into the package, skip sending it
                if (this.udpCommandCount <= 0)
                {
                    return false;
                }

                if (this.TrafficStatsEnabled)
                {
                    this.TrafficStatsOutgoing.TotalPacketCount++;
                    this.TrafficStatsOutgoing.TotalCommandsInPackets += this.udpCommandCount;
                }

                // we counted the length in udpBufferIndex, so we can use that to send
                this.SendData(this.udpBuffer, this.udpBufferIndex);

                return remainingCommands > 0;
            }
        }

        /// <summary>
        /// Checks if any channel has a outgoing reliable command.
        /// </summary>
        /// <returns>True if any channel has a outgoing reliable command. False otherwise.</returns>
        private bool AreReliableCommandsInTransit()
        {
            lock (this.channels)
            {
                foreach (EnetChannel channel in this.channels.Values)
                {
                    // reliable commands (if any. else: check ping interval)
                    if (channel.outgoingReliableCommandsList.Count > 0)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Checks connected state and channel before operation is serialized and enqueued for sending.
        /// </summary>
        /// <param name="parameters">operation parameters</param>
        /// <param name="opCode">code of operation</param>
        /// <param name="sendReliable">send as reliable command</param>
        /// <param name="channelId">channel (sequence) for command</param>
        /// <param name="encrypt">encrypt or not</param>
        /// <param name="messageType">usually EgMessageType.Operation</param>
        /// <returns>if operation could be enqueued</returns>
        internal override bool EnqueueOperation(Dictionary<byte, object> parameters, byte opCode, bool sendReliable, byte channelId, bool encrypt, EgMessageType messageType)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: " + opCode + " Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            if (channelId >= this.ChannelCount)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Selected channel (" + channelId + ")>= channelCount (" + this.ChannelCount + ").");
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            byte[] opBytes = this.SerializeOperationToMessage(opCode, parameters, messageType, encrypt);
            // serialiseOperation() increments the invocID by 1 after the assigning one to this op
            return this.CreateAndEnqueueCommand((sendReliable) ? NCommand.CT_SENDRELIABLE : NCommand.CT_SENDUNRELIABLE, opBytes, channelId);
            // send() does takes account of the now "too high" invocID or returns -1
        }

#if SDK_V4
        internal override bool EnqueueMessage(object message, bool sendReliable, byte channelId, bool encrypt)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send message! Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            if (channelId >= this.ChannelCount)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Selected channel (" + channelId + ")>= channelCount (" + this.ChannelCount + ").");
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            byte[] opBytes = this.SerializeMessageToMessage(message, encrypt, messageHeader, false);
            // serialiseOperation() increments the invocID by 1 after the assigning one to this op
            return this.CreateAndEnqueueCommand((sendReliable) ? NCommand.CT_SENDRELIABLE : NCommand.CT_SENDUNRELIABLE, opBytes, channelId);
            // send() does takes account of the now "too high" invocID or returns -1
        }

        internal override bool EnqueueRawMessage(byte[] message, bool sendReliable, byte channelId, bool encrypt)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send message! Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            if (channelId >= this.ChannelCount)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Selected channel (" + channelId + ")>= channelCount (" + this.ChannelCount + ").");
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            byte[] opBytes = this.SerializeRawMessageToMessage(message, encrypt, messageHeader, false);
            // serialiseOperation() increments the invocID by 1 after the assigning one to this op
            return this.CreateAndEnqueueCommand((sendReliable) ? NCommand.CT_SENDRELIABLE : NCommand.CT_SENDUNRELIABLE, opBytes, channelId);
            // send() does takes account of the now "too high" invocID or returns -1
        }
#endif//SDK_V4

        /// <summary>reliable-udp-level function to send some byte[] to the server via un/reliable command</summary>
        /// <remarks>only called when a custom operation should be send</remarks>
        /// <param name="commandType">(enet) command type</param>
        /// <param name="payload">data to carry (operation)</param>
        /// <param name="channelNumber">channel in which to send</param>
        /// <returns>the invocation ID for this operation (the payload)</returns>
        internal bool CreateAndEnqueueCommand(byte commandType, byte[] payload, byte channelNumber)
        {
            if (payload == null)
            {
                return false;
            }

            var channel = this.channels[channelNumber];
            this.ByteCountLastOperation = 0;

            // check if fragmentation is needed
            // NOTE: this check is simple and "for any command". actually, a reliable command has less bytes has a few more bytes before fragmenting
            var fragmentLength = this.mtu - NCommand.HEADER_UDP_PACK_LENGTH - NCommand.CmdSizeMaxHeader;

            if (payload.Length > fragmentLength)
            {
                // create fragments
                int fragmentCount = (payload.Length + fragmentLength - 1) / fragmentLength;
                int startSequenceNumber = channel.outgoingReliableSequenceNumber + 1;
                int fragmentNumber;
                int fragmentOffset;

                for (fragmentNumber = 0, fragmentOffset = 0;
                     fragmentOffset < payload.Length;
                     ++fragmentNumber, fragmentOffset += fragmentLength)
                {
                    if (payload.Length - fragmentOffset < fragmentLength)
                    {
                        fragmentLength = payload.Length - fragmentOffset;
                    }

                    byte[] tmpPayload = new byte[fragmentLength];
                    Buffer.BlockCopy(payload, fragmentOffset, tmpPayload, 0, fragmentLength);

                    NCommand command = new NCommand(this, NCommand.CT_SENDFRAGMENT, tmpPayload, channel.ChannelNumber);
                    command.fragmentNumber = fragmentNumber;
                    command.startSequenceNumber = startSequenceNumber;
                    command.fragmentCount = fragmentCount;
                    command.totalLength = payload.Length;
                    command.fragmentOffset = fragmentOffset;

                    this.QueueOutgoingReliableCommand(command);
                    this.ByteCountLastOperation += command.Size;
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsOutgoing.CountFragmentOpCommand(command.Size);
                        this.TrafficStatsGameLevel.CountOperation(command.Size);
                    }
                }
            }
            else
            {
                // create a single, regular command (no need to fragment)
                NCommand command = new NCommand(this, commandType, payload, channel.ChannelNumber);

                if (command.commandFlags == NCommand.FV_RELIABLE)
                {
                    this.QueueOutgoingReliableCommand(command);
                    this.ByteCountLastOperation = command.Size;
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsOutgoing.CountReliableOpCommand(command.Size);
                        this.TrafficStatsGameLevel.CountOperation(command.Size);
                    }
                }
                else
                {
                    this.QueueOutgoingUnreliableCommand(command);
                    this.ByteCountLastOperation = command.Size;
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsOutgoing.CountUnreliableOpCommand(command.Size);
                        this.TrafficStatsGameLevel.CountOperation(command.Size);
                    }
                }
            }

            return true;
        }

        /// <summary> Returns the UDP Payload starting with Magic Number for binary protocol </summary>
        internal override byte[] SerializeOperationToMessage(byte opc, Dictionary<byte, object> parameters, EgMessageType messageType, bool encrypt)
        {
            byte[] fullMessageBytes;

            lock (this.SerializeMemStream)
            {
                // re-set the mem stream for next message and op (in message)
                this.SerializeMemStream.Position = 0;
                this.SerializeMemStream.SetLength(0);

                // write (prelimiary) message header (might be changed later on, due to encryption, etc)
                if (!encrypt)
                {
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                }

                // write bytes of op to memstream
                Protocol.SerializeOperationRequest(this.SerializeMemStream, opc, parameters, false);

                // if we encrypt, the message header was left out, as we encrypt only the operation bytes
                if (encrypt)
                {
                    byte[] opBytes = this.SerializeMemStream.ToArray();
                    opBytes = this.CryptoProvider.Encrypt(opBytes);

                    this.SerializeMemStream.Position = 0;
                    this.SerializeMemStream.SetLength(0);
                    this.SerializeMemStream.Write(messageHeader, 0, messageHeader.Length);
                    this.SerializeMemStream.Write(opBytes, 0, opBytes.Length);
                }

                fullMessageBytes = this.SerializeMemStream.ToArray();
            }

            // now update the message header according to type
            if (messageType != EgMessageType.Operation)
            {
                fullMessageBytes[messageHeader.Length - 1] = (byte)messageType;
            }

            if (encrypt)
            {
                fullMessageBytes[messageHeader.Length - 1] = (byte)(fullMessageBytes[messageHeader.Length - 1] | 0x80);
            }

            return fullMessageBytes;
        }

        // ------------------------------------------------------------------------------------------------------------------

        internal int SerializeToBuffer(Queue<NCommand> commandList)
        {
            while (commandList.Count > 0)
            {
                NCommand command = commandList.Peek(); // TODO: check if NULL is even possible here
                if (command == null)
                {
                    commandList.Dequeue();
                    continue;
                }

                // check if serialized command fits into current UPD-package
                if (this.udpBufferIndex + command.Size > this.udpBuffer.Length)
                {
                    if (this.debugOut >= DebugLevel.INFO)
                    {
                        this.Listener.DebugReturn(DebugLevel.INFO, "UDP package is full. Commands in Package: " + this.udpCommandCount + ". Commands left in queue: " + commandList.Count);
                    }

                    break;
                }

                // copy serialized command to udpBuffer (outgoing) and adjust indexes/counts
                Buffer.BlockCopy(command.Serialize(), 0, this.udpBuffer, this.udpBufferIndex, command.Size);
                this.udpBufferIndex += command.Size;
                this.udpCommandCount++;

                // if needed, queue this command in the sentReliableQueue
                if ((command.commandFlags & NCommand.FLAG_RELIABLE) > 0)
                {
                    this.QueueSentCommand(command);
                    if (this.CommandLog != null)
                    {
                        this.CommandLog.Enqueue(new CmdLogSentReliable(command, this.timeInt, this.roundTripTime, this.roundTripTimeVariance));
                        this.CommandLogResize();
                    }
                }

                // this command is now in the UDP package. remove it from the out queue
                commandList.Dequeue();
            }

            return commandList.Count;
        }

        internal void SendData(byte[] data, int length)
        {
            try
            {
                int offset = 0; // the peerID's offset is 0
                Protocol.Serialize(this.peerID, data, ref offset);
                data[2] = (this.crcEnabled) ? (byte)0xCC : (byte)0x0; // flags => 0x0 "nothing special" and 0xCC "using CRC"
                data[3] = this.udpCommandCount; // command count
                offset = 4;     // the time's offset is 4. challenge is following this directly (offset is then 8)
                Protocol.Serialize(this.timeInt, data, ref offset);
                Protocol.Serialize(this.challenge, data, ref offset);

                if (this.crcEnabled)
                {
                    Protocol.Serialize(0, data, ref offset);    // set CRC bytes to 0 in recycled buffer
                    uint crcValue = SupportClass.CalculateCrc(data, length);

                    offset = offset - CRC_LENGTH; // rewind 4 bytes to re-write the CRC
                    Protocol.Serialize((int)crcValue, data, ref offset); // the place behind the challenge is the CRC (optional)
                }

                this.bytesOut += length;

                // actual sending
                #if DEBUG
                if (NetworkSimulationSettings.IsSimulationEnabled)
                {
                    byte[] dataCopy = new byte[length];
                    Buffer.BlockCopy(data, 0, dataCopy, 0, length);
                    this.SendNetworkSimulated(delegate { this.rt.Send(dataCopy, length); });
                }
                else
                {
                    this.rt.Send(data, length);
                }
                #else
                this.rt.Send(data, length);
                #endif
            }
            catch (System.Exception ex)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, ex.ToString());
                }

                SupportClass.WriteStackTrace(ex);
            }
        }

        internal void QueueSentCommand(NCommand command)
        {
            // set sentTime and count
            command.commandSentTime = timeInt;
            command.commandSentCount++;

            if (command.roundTripTimeout == 0)
            {
                // initialize the roundTripTimeOut (on the first sending of this command)
                command.roundTripTimeout = roundTripTime + (4 * roundTripTimeVariance);
                command.timeoutTime = timeInt + this.DisconnectTimeout;
            }
            else
            {
                if (command.commandSentCount <= this.QuickResendAttempts + 1)
                {
                    // first X repeats are as quick as the initial
                }
                else
                {
                    // this command has already been sent before. double time roundtrip timeout
                    command.roundTripTimeout *= 2;
                }
            }

            lock (this.sentReliableCommands)
            {
                // if this is the first Command waiting for an ACK, set the timoutInt according to the roundtripTimeout of this command
                if (this.sentReliableCommands.Count == 0)
                {
                    int resendTime = command.commandSentTime + command.roundTripTimeout;
                    if (resendTime < this.timeoutInt)
                    {
                        this.timeoutInt = resendTime;
                    }
                }

                this.reliableCommandsSent++;
                this.sentReliableCommands.Add(command);
            }

            // check queue length and warn if it gets too long
            if (this.sentReliableCommands.Count >= warningSize && this.sentReliableCommands.Count % warningSize == 0)
            {
                this.Listener.OnStatusChanged(StatusCode.QueueSentWarning);
            }
        }

        internal void QueueOutgoingReliableCommand(NCommand command)
        {
            EnetChannel channel = this.channels[command.commandChannelID];
            lock (channel)
            {
                Queue<NCommand> outgoingReliableCommands = channel.outgoingReliableCommandsList;

                // check queue length and warn if it gets too long
                if (outgoingReliableCommands.Count >= warningSize && outgoingReliableCommands.Count % warningSize == 0)
                {
                    this.Listener.OnStatusChanged(StatusCode.QueueOutgoingReliableWarning);
                }

                // assign new (channel-) sequenceNumber only if not re-sent (re-sends use "old" sequenceNumber)
                if (command.reliableSequenceNumber == 0)
                {
                    command.reliableSequenceNumber = ++channel.outgoingReliableSequenceNumber;
                }

                outgoingReliableCommands.Enqueue(command);
            }
        }


        internal void QueueOutgoingUnreliableCommand(NCommand command)
        {
            Queue<NCommand> outgoingUnreliableCommands = this.channels[command.commandChannelID].outgoingUnreliableCommandsList;

            // check queue length and warn if it gets too long
            if (outgoingUnreliableCommands.Count >= warningSize && outgoingUnreliableCommands.Count % warningSize == 0)
            {
                this.Listener.OnStatusChanged(StatusCode.QueueOutgoingUnreliableWarning);
            }

            // unreliable commands use the most recent reliable sequencenumber (helps the server dismiss older commands and stall newer ones)
            // they don't increase the outgoingReliableSequenceNumber but the channel's outgoingUnreliableSequenceNumber
            var channel = this.channels[command.commandChannelID];
            command.reliableSequenceNumber = channel.outgoingReliableSequenceNumber;
            command.unreliableSequenceNumber = ++channel.outgoingUnreliableSequenceNumber;

            outgoingUnreliableCommands.Enqueue(command);
        }


        internal void QueueOutgoingAcknowledgement(NCommand command)
        {
            lock (this.outgoingAcknowledgementsList)
            {
                // check queue length and warn if it gets too long
                if (this.outgoingAcknowledgementsList.Count >= warningSize && this.outgoingAcknowledgementsList.Count % warningSize == 0)
                {
                    this.Listener.OnStatusChanged(StatusCode.QueueOutgoingAcksWarning);
                }

                this.outgoingAcknowledgementsList.Enqueue(command);
            }
        }

        // ------------------------------------------------------------------------------------------------------------------

        //------------------------------------------------------------------------------------------------------------------

        /// <summary>reads incoming udp-packages to create and queue incoming commands*</summary>
        internal override void ReceiveIncomingCommands(byte[] inBuff, int dataLength)
        {
            this.timestampOfLastReceive = SupportClass.GetTickCount();

            // this.Listener.DebugReturn("receiveIncomingCommands() inBuff.Length:" + inBuff.Length););

            try
            {
                // read enet-packet-header
                int readingOffset = 0;

                short peerID;
                Protocol.Deserialize(out peerID, inBuff, ref readingOffset);
                byte flags = inBuff[readingOffset++];
                byte commandCount = inBuff[readingOffset++];
                Protocol.Deserialize(out this.serverSentTime, inBuff, ref readingOffset);
                int inChallenge;
                Protocol.Deserialize(out inChallenge, inBuff, ref readingOffset);

                // the flags value defines if server sends a CRC. read and check, if it was sent
                if (flags == 0xCC)
                {
                    int crc;
                    Protocol.Deserialize(out crc, inBuff, ref readingOffset);
                    this.bytesIn += CRC_LENGTH;

                    // we have to "blank" the incoming crc value and calculate our own
                    readingOffset -= CRC_LENGTH;
                    Protocol.Serialize(0, inBuff, ref readingOffset);

                    uint localCrc = SupportClass.CalculateCrc(inBuff, dataLength);
                    if ((uint)crc != localCrc)
                    {
                        this.packetLossByCrc++;
                        if (peerConnectionState != ConnectionStateValue.Disconnected && debugOut >= DebugLevel.INFO)
                        {
                            this.EnqueueDebugReturn(DebugLevel.INFO, string.Format("Ignored package due to wrong CRC. Incoming:  {0:X} Local: {1:X}", (uint) crc, localCrc));
                        }
                        return;
                    }
                }

                this.bytesIn += NCommand.HEADER_UDP_PACK_LENGTH;
                if (this.TrafficStatsEnabled)
                {
                    this.TrafficStatsIncoming.TotalPacketCount++;
                    this.TrafficStatsIncoming.TotalCommandsInPackets += commandCount;
                }

                // TODO: add ERROR for max commands/packet
                if (commandCount > commandBufferSize || commandCount <= 0)
                {
                    this.EnqueueDebugReturn(DebugLevel.ERROR, "too many/few incoming commands in package: " + commandCount + " > " + commandBufferSize);
                }

                if (inChallenge != this.challenge)
                {
                    this.packetLossByChallenge++;
                    if (peerConnectionState != ConnectionStateValue.Disconnected && debugOut >= DebugLevel.ALL)
                    {
                        this.EnqueueDebugReturn(DebugLevel.ALL, "Info: Ignoring received package due to wrong challenge. Challenge in-package!=local:" + inChallenge + "!=" + this.challenge + " Commands in it: " + commandCount);
                    }

                    return;
                }

                this.timeInt = SupportClass.GetTickCount() - this.timeBase;

                // read command-by-command and prepare to execute it
                for (int i = 0; i < commandCount; i++)
                {
                    NCommand readCommand = new NCommand(this, inBuff, ref readingOffset);
                    if (readCommand.commandType != NCommand.CT_ACK)
                    {
                        this.EnqueueActionForDispatch(delegate { this.ExecuteCommand(readCommand); });
                    }
                    else
                    {
                        this.TrafficStatsIncoming.TimestampOfLastAck = SupportClass.GetTickCount();
                        this.ExecuteCommand(readCommand);
                    }

                    if ((readCommand.commandFlags & NCommand.FLAG_RELIABLE) > 0)
                    {
                        if (this.InReliableLog != null)
                        {
                            this.InReliableLog.Enqueue(new CmdLogReceivedReliable(readCommand, this.timeInt, this.roundTripTime, this.roundTripTimeVariance, this.timeInt - this.timeLastSendOutgoing, this.timeInt - this.timeLastSendAck));
                            this.CommandLogResize();
                        }

                        NCommand ackForCommand = NCommand.CreateAck(this, readCommand, this.serverSentTime);
                        this.QueueOutgoingAcknowledgement(ackForCommand);
                        if (this.TrafficStatsEnabled)
                        {
                            this.TrafficStatsIncoming.TimestampOfLastReliableCommand = SupportClass.GetTickCount();
                            this.TrafficStatsOutgoing.CountControlCommand(ackForCommand.Size);
                        }
                    }
                }
                // this.Listener.DebugReturn("IN : s:"+outgoingAcknowledgementsRingStart+" e: "+outgoingAcknowledgementsRingEnd+" "+commandListToString(outgoingAcknowledgementsRing));
            }
            catch (System.Exception ex)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.EnqueueDebugReturn(DebugLevel.ERROR, string.Format("Exception while reading commands from incoming data: {0}", ex));
                }

                SupportClass.WriteStackTrace(ex);
            }
        }

        internal bool ExecuteCommand(NCommand command)
        {
            // this.Listener.DebugReturn("executeCommand() " + command.ToString());
            bool success = true;

            switch (command.commandType)
            {
                case NCommand.CT_CONNECT:
                case NCommand.CT_PING:
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsIncoming.CountControlCommand(command.Size);
                    }
                    break;

                case NCommand.CT_DISCONNECT:
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsIncoming.CountControlCommand(command.Size);
                    }

                    // reserved byte is used for disconnect reason:
                    // CLR DisconnectClient() = 1, Timeout disconnect = 2, Connection limit reached = 3
                    StatusCode reason = StatusCode.DisconnectByServer;
                    if (command.reservedByte == 1)
                    {
                        reason = StatusCode.DisconnectByServerLogic;
                    }
                    else if (command.reservedByte == 3)
                    {
                        reason = StatusCode.DisconnectByServerUserLimit;
                    }

                    if (debugOut >= DebugLevel.INFO)
                    {
                        this.Listener.DebugReturn(DebugLevel.INFO, "Server " + this.ServerAddress + " sent disconnect. PeerId: " + (ushort)peerID + " RTT/Variance:" + roundTripTime + "/" + roundTripTimeVariance + " reason byte: " + command.reservedByte);
                    }

                    this.peerConnectionState = ConnectionStateValue.Disconnecting;
                    this.Listener.OnStatusChanged(reason);

                    // destroy self by stopping the connection thread (in the game logic thread)
                    this.rt.Disconnect();
                    peerConnectionState = ConnectionStateValue.Disconnected;
                    this.Listener.OnStatusChanged(StatusCode.Disconnect);

                    break;

                case NCommand.CT_ACK:
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsIncoming.CountControlCommand(command.Size);
                    }

                    // NOTE: incoming ACKs are executed immediately, unlike any other command type. this makes sure RTT and server time are calculated correctly
                    // this.Listener.DebugReturn("   CT_ACK");
                    this.timeLastAckReceive = timeInt; //set last receive time

                    // calculate the roundtrip time (between sending the reliable command until this ack was received)
                    lastRoundTripTime = timeInt - command.ackReceivedSentTime; //this value is only available for ACKs

                    // this.EnqueueDebugReturn(DebugLevel.INFO, "roundTripTime: " + roundTripTime + "\tlastRoundTripTime: " + lastRoundTripTime + "\tTime since received: " + (SupportClass.GetTickCount() - timeBase - timeInt) + " reliableCommandsRepeated: " + reliableCommandsRepeated);
                    NCommand removedCommand = this.RemoveSentReliableCommand(command.ackReceivedReliableSequenceNumber, command.commandChannelID);

                    if (this.CommandLog != null)
                    {
                        this.CommandLog.Enqueue(new CmdLogReceivedAck(command, this.timeInt, this.roundTripTime, this.roundTripTimeVariance));
                        this.CommandLogResize();
                    }

                    if (removedCommand != null)
                    {
                        if (removedCommand.commandType == NCommand.CT_EG_SERVERTIME)
                        {
                            if (lastRoundTripTime <= roundTripTime)
                            {
                                serverTimeOffset = this.serverSentTime + (lastRoundTripTime >> 1) - SupportClass.GetTickCount();
                                serverTimeOffsetIsAvailable = true;
                            }
                            else
                            {
                                this.FetchServerTimestamp();
                            }
                        }
                        else
                        {
                            // CT_EG_SERVERTIME is excluded from RTT calculation. any other command will cause an update:
                            this.UpdateRoundTripTimeAndVariance(lastRoundTripTime);

                            if (removedCommand.commandType == NCommand.CT_DISCONNECT && peerConnectionState == ConnectionStateValue.Disconnecting)
                            {
                                if (debugOut >= DebugLevel.INFO)
                                {
                                    this.EnqueueDebugReturn(DebugLevel.INFO, "Received disconnect ACK by server");
                                }

                                // going to destroy self by stopping the connection thread
                                this.EnqueueActionForDispatch(delegate { this.rt.Disconnect(); });
                            }
                            else if (removedCommand.commandType == NCommand.CT_CONNECT)
                            {
                                roundTripTime = lastRoundTripTime;
                            }
                        }
                    }
                    break;

                case NCommand.CT_SENDRELIABLE:
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsIncoming.CountReliableOpCommand(command.Size);
                    }

                    // this.Listener.DebugReturn("   CT_SENDRELIABLE");
                    if (peerConnectionState == ConnectionStateValue.Connected)
                    {
                        success = this.QueueIncomingCommand(command);
                    }
                    break;

                case NCommand.CT_SENDUNRELIABLE:
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsIncoming.CountUnreliableOpCommand(command.Size);
                    }

                    // this.Listener.DebugReturn("   CT_SENDUNRELIABLE");
                    if (peerConnectionState == ConnectionStateValue.Connected)
                    {
                        success = this.QueueIncomingCommand(command);
                    }
                    break;

                case NCommand.CT_SENDFRAGMENT:
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsIncoming.CountFragmentOpCommand(command.Size);
                    }

                    // this.Listener.DebugReturn("   CT_SENDFRAGMENT");
                    if (peerConnectionState == ConnectionStateValue.Connected)
                    {
                        if (command.fragmentNumber > command.fragmentCount ||
                            command.fragmentOffset >= command.totalLength ||
                            command.fragmentOffset + command.Payload.Length > command.totalLength)
                        {
                            if (this.debugOut >= DebugLevel.ERROR)
                            {
                                this.Listener.DebugReturn(DebugLevel.ERROR, "Received fragment has bad size: " + command);
                            }
                            break;
                        }

                        success = this.QueueIncomingCommand(command);    // returns false if command is not saved (e.g. cause it's already received)
                        // if the command is saved (cause it's new), find initial fragment and reduce count of fragments we're waiting for
                        if (success)
                        {
                            var channel = this.channels[command.commandChannelID];

                            if (command.reliableSequenceNumber == command.startSequenceNumber)
                            {
                                // this is the first fragment of a series: check if we have all fragments
                                command.fragmentsRemaining--;
                                int fragmentSequenceNumber = command.startSequenceNumber + 1;
                                while (command.fragmentsRemaining > 0 && fragmentSequenceNumber < command.startSequenceNumber + command.fragmentCount)
                                {
                                    if (channel.ContainsReliableSequenceNumber(fragmentSequenceNumber++))
                                    {
                                        command.fragmentsRemaining--;
                                    }
                                }
                            }
                            else if (channel.ContainsReliableSequenceNumber(command.startSequenceNumber))
                            {
                                // this incoming command is not the first of a fragment-series, but we have that one, so reduce fragmentsRemaining
                                NCommand startCmd = channel.FetchReliableSequenceNumber(command.startSequenceNumber);
                                startCmd.fragmentsRemaining--;
                            }
                        }
                    }

                    break;

                case NCommand.CT_VERIFYCONNECT:
                    if (this.TrafficStatsEnabled)
                    {
                        this.TrafficStatsIncoming.CountControlCommand(command.Size);
                    }

                    // do not connect again if connected or disconnecting or something else!!
                    if (peerConnectionState == ConnectionStateValue.Connecting)
                    {
                        // this verifies the connect from client (by server); the Protocol-layer now expects an init!
                        // the connection must be initialised
                        command = new NCommand(this, NCommand.CT_SENDRELIABLE, this.initData, 0);
                        this.QueueOutgoingReliableCommand(command);
                        if (this.TrafficStatsEnabled)
                        {
                            this.TrafficStatsOutgoing.CountControlCommand(command.Size);
                        }

                        // enet-peer is connected. Enet need this state now, to send init. TCP is connected when init is done.
                        peerConnectionState = ConnectionStateValue.Connected;

                        // "connect" callback (for the app) is done when the init-response is received
                    }

                    break;
            }

            return success; // this is set to false, if queueIncomingCommand() failed (cause queue is full or so)
        }

        /// <summary>queues incoming commands in the correct order as either unreliable, reliable or unsequenced. return value determines if the command is queued / done.</summary>
        internal bool QueueIncomingCommand(NCommand command)
        {
            // NOTE: changed "channel exists" test to use the dictionary tryGetValue (instead of checking the number first)
            EnetChannel channel;
            this.channels.TryGetValue(command.commandChannelID, out channel);

            if (channel == null)
            {
                if (debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Received command for non-existing channel: " + command.commandChannelID);
                }

                return false;
            }

            if (debugOut >= DebugLevel.ALL)
            {
                this.Listener.DebugReturn(DebugLevel.ALL, "queueIncomingCommand() " + command + " channel seq# r/u: " + channel.incomingReliableSequenceNumber + "/" + channel.incomingUnreliableSequenceNumber);
            }

            // this section handles reliable commands
            if (command.commandFlags == NCommand.FV_RELIABLE)
            {
                if (command.reliableSequenceNumber <= channel.incomingReliableSequenceNumber)
                {
                    if (debugOut >= DebugLevel.INFO)
                    {
                        this.Listener.DebugReturn(DebugLevel.INFO, "incoming command " + command + " is old (not saving it). Dispatched incomingReliableSequenceNumber: " + channel.incomingReliableSequenceNumber);
                    }

                    return false;
                }

                // see if an incoming command was received before (key in list) and don't save
                if (channel.ContainsReliableSequenceNumber(command.reliableSequenceNumber))
                {
                    if (debugOut >= DebugLevel.INFO)
                    {
                        this.Listener.DebugReturn(DebugLevel.INFO, "Info: command was received before! Old/New: " + channel.FetchReliableSequenceNumber(command.reliableSequenceNumber) + "/" + command + " inReliableSeq#: " + channel.incomingReliableSequenceNumber);
                    }

                    return false;
                }

                // check queue length and warn if it gets too long
                if (channel.incomingReliableCommandsList.Count >= this.warningSize && channel.incomingReliableCommandsList.Count % this.warningSize == 0)
                {
                    this.Listener.OnStatusChanged(StatusCode.QueueIncomingReliableWarning);
                }

                // insert command to list and sort it, right away
                channel.incomingReliableCommandsList.Add(command.reliableSequenceNumber, command);

                // saving the reliable command is done - quit now);
                return true;
            }


            // the lower passage only handles unreliable and unsequenced commands - it does not save reliable ones again
            if (command.commandFlags == NCommand.FV_UNRELIABLE)
            {
                if (command.reliableSequenceNumber < channel.incomingReliableSequenceNumber)
                {
                    // incoming command has a reliableSequenceNumber < Dispatched reliableSequenceNumber: it's old and won't be saved
                    if (debugOut >= DebugLevel.INFO)
                    {
                        this.Listener.DebugReturn(DebugLevel.INFO, "incoming reliable-seq# < Dispatched-rel-seq#. not saved.");
                    }

                    // "free packet" if reliableSequenceNumber is more "advanced" (in channel)
                    return true;
                }

                if (command.unreliableSequenceNumber <= channel.incomingUnreliableSequenceNumber)
                {
                    // incoming command has unreliableSequenceNumber <= Dispatched incomingUnreliableSequenceNumber: don't save it
                    if (debugOut >= DebugLevel.INFO)
                    {
                        this.Listener.DebugReturn(DebugLevel.INFO, "incoming unreliable-seq# < Dispatched-unrel-seq#. not saved.");
                    }

                    // "free packet" if UNreliableSequenceNumber is more "advanced" (in channel)
                    return true;
                }

                if (channel.ContainsUnreliableSequenceNumber(command.unreliableSequenceNumber))
                {
                    if (debugOut >= DebugLevel.INFO)
                    {
                        this.Listener.DebugReturn(DebugLevel.INFO, "command was received before! Old/New: " + channel.incomingUnreliableCommandsList[command.unreliableSequenceNumber] + "/" + command);
                    }

                    return false;
                }

                // check queue length and warn if it gets too long
                if (channel.incomingUnreliableCommandsList.Count >= this.warningSize && channel.incomingUnreliableCommandsList.Count % warningSize == 0)
                {
                    this.Listener.OnStatusChanged(StatusCode.QueueIncomingUnreliableWarning);
                }

                // save the unreliable command and return "success"
                channel.incomingUnreliableCommandsList.Add(command.unreliableSequenceNumber, command);

                return true;
            }

            // not supported by our enet
            // if (command.commandFlags == NCommand.FV_UNRELIBALE_UNSEQUENCED)
            // {
            //    //int i = 0; //unsequenced commands are just put to the front so they don't mess up ordering
            //    //savedCommand = true; //saving this is done below in any case
            //    //implement it's own queue or add unsequenced somehow to the unreliable queue!
            // }

            return false;
        }

        /// <summary>removes commands which are acknowledged*</summary>
        internal NCommand RemoveSentReliableCommand(int ackReceivedReliableSequenceNumber, int ackReceivedChannel)
        {
            NCommand found = null;

            lock (this.sentReliableCommands)
            {
                foreach (NCommand result in this.sentReliableCommands)
                {
                    if (result != null && result.reliableSequenceNumber == ackReceivedReliableSequenceNumber && result.commandChannelID == ackReceivedChannel)
                    {
                        found = result;
                        break;
                    }
                }

                if (found != null)
                {
                    // remove command from list
                    this.sentReliableCommands.Remove(found);

                    // reset timer / timeout if there are commands remaining (next command is likely to timeout next)
                    if (this.sentReliableCommands.Count > 0)
                    {
                        this.timeoutInt = this.timeInt + 25; //this.sentReliableCommands[0].commandSentTime + this.sentReliableCommands[0].roundTripTimeout;
                    }
                }
                else
                {
                    // no command found for this ACK (no need to worry, this can happen)
                    if (debugOut >= DebugLevel.ALL && peerConnectionState != ConnectionStateValue.Connected && peerConnectionState != ConnectionStateValue.Disconnecting)
                    {
                        this.EnqueueDebugReturn(DebugLevel.ALL, string.Format("No sent command for ACK (Ch: {0} Sq#: {1}). PeerState: {2}.", ackReceivedReliableSequenceNumber, ackReceivedChannel, peerConnectionState));
                    }
                }
            }

            return found;
        }

        internal String CommandListToString(NCommand[] list)
        {
            if (this.debugOut < DebugLevel.ALL)
            {
                return string.Empty;
            }

            System.Text.StringBuilder tmp = new System.Text.StringBuilder();
            for (int i = 0; i < list.Length; i++)
            {
                tmp.Append(i + "=");
                tmp.Append(list[i]);
                tmp.Append(" # ");
            }

            return tmp.ToString();
        }
    }
}