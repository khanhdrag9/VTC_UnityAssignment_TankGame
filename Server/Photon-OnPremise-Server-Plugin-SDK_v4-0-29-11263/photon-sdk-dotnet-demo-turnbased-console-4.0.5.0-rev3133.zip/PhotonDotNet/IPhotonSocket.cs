using System;
using System.Net;

#if !NoSocket && !NETFX_CORE
using System.Net.Sockets;
#endif

namespace ExitGames.Client.Photon
{
    public enum PhotonSocketState
    {
        Disconnected,
        Connecting,
        Connected,
        Disconnecting
    }

    public enum PhotonDisconnectCause
    {
        SecurityExceptionOnConnect,
        ExceptionOnConnect,
        Exception,
        ReadException,
        WriteException
    }

    public enum PhotonSocketError
    {
        Success, Skipped, NoData, Exception
    }

    public abstract class IPhotonSocket
    {
        internal PeerBase peerBase;

        protected IPhotonPeerListener Listener { get { return this.peerBase.Listener; } }

        public ConnectionProtocol Protocol { get; protected set; }

        public bool PollReceive;

        public PhotonSocketState State { get; protected set; }

        public string ServerAddress { get; protected set; }

        public int ServerPort { get; protected set; }

        public bool Connected { get { return this.State == PhotonSocketState.Connected; } }

        public int MTU { get { return this.peerBase.mtu; } }


        public IPhotonSocket(PeerBase peerBase)
        {
            if (peerBase == null)
            {
                throw new Exception("Can't init without peer");
            }

            this.peerBase = peerBase;
        }

        public virtual bool Connect()
        {
            if (this.State != PhotonSocketState.Disconnected)
            {
                if (this.peerBase.debugOut >= DebugLevel.ERROR)
                {
                    this.peerBase.Listener.DebugReturn(DebugLevel.ERROR, "Connect() failed: connection in State: " + this.State);
                }

                return false;
            }

            if (this.peerBase == null || this.Protocol != this.peerBase.usedProtocol)
            {
                return false;
            }

            string host;
            ushort hostPort;
            if (!this.TryParseAddress(this.peerBase.ServerAddress, out host, out hostPort))
            {
                if (this.peerBase.debugOut >= DebugLevel.ERROR)
                {
                    this.peerBase.Listener.DebugReturn(DebugLevel.ERROR, "Failed parsing address: " + this.peerBase.ServerAddress);
                }
                return false;
            }

            this.ServerAddress = host;
            this.ServerPort = hostPort;

            return true;
        }

        public abstract bool Disconnect();

        public abstract PhotonSocketError Send(byte[] data, int length);

        public abstract PhotonSocketError Receive(out byte[] data);

        public void HandleReceivedDatagram(byte[] inBuffer, int length, bool willBeReused)
        {
#if DEBUG
            // receive through network simulator or directly (if turned off)
            if (this.peerBase.NetworkSimulationSettings.IsSimulationEnabled)
            {
                if (willBeReused)
                {
                    byte[] inBufferCopy = new byte[length];
                    Buffer.BlockCopy(inBuffer, 0, inBufferCopy, 0, length);
                    this.peerBase.ReceiveNetworkSimulated(delegate { this.peerBase.ReceiveIncomingCommands(inBufferCopy, length); });
                }
                else
                {
                    this.peerBase.ReceiveNetworkSimulated(delegate { this.peerBase.ReceiveIncomingCommands(inBuffer, length); });
                }
            }
            else
            {
                this.peerBase.ReceiveIncomingCommands(inBuffer, length);
            }
#else
            // Release build always receives directly
            this.peerBase.ReceiveIncomingCommands(inBuffer, length);
#endif
        }

        public bool ReportDebugOfLevel(DebugLevel levelOfMessage)
        {
            return this.peerBase.debugOut >= levelOfMessage;
        }

        public void EnqueueDebugReturn(DebugLevel debugLevel, string message)
        {
            this.peerBase.EnqueueDebugReturn(debugLevel, message);
        }

        internal protected void HandleException(StatusCode statusCode)
        {
            this.State = PhotonSocketState.Disconnecting;
            this.peerBase.EnqueueStatusCallback(statusCode);
            this.peerBase.EnqueueActionForDispatch(delegate { this.peerBase.Disconnect(); });
        }

        /// <summary>
        /// Separates the given address into address (host name or IP) and port. Port must be included after colon!
        /// </summary>
        /// <remarks>
        /// This method expects any address to include a port. The final ':' in addressAndPort has to separate it.
        /// IPv6 addresses have multiple colons and <b>must use brackets</b> to separate address from port.
        /// 
        /// Examples:
        ///     ns.exitgames.com:5058
        ///     http://[2001:db8:1f70::999:de8:7648:6e8]:100/
        ///     [2001:db8:1f70::999:de8:7648:6e8]:100
        /// See:
        ///     http://serverfault.com/questions/205793/how-can-one-distinguish-the-host-and-the-port-in-an-ipv6-url
        /// </remarks>
        internal protected bool TryParseAddress(string addressAndPort, out string address, out ushort port)
        {
            address = string.Empty;
            port = 0;

            if (string.IsNullOrEmpty(addressAndPort))
            {
                return false;
            }

            int idx = addressAndPort.LastIndexOf(':');
            if (idx <= 0)
            {
                return false;
            }
            // if there is another ':', this is a IPv6 address and (in our definition) must have brackets
            if (addressAndPort.IndexOf(':') != idx && (!addressAndPort.Contains("[") || !addressAndPort.Contains("]")))
            {
                return false;
            }

            address = addressAndPort.Substring(0, idx);
            string portString = addressAndPort.Substring(idx + 1);

            bool gotPort = ushort.TryParse(portString, out port);
            return gotPort;
        }


#if !(NETFX_CORE || WINDOWS_PHONE)
        internal protected static IPAddress GetIpAddress(string serverIp)
        {
            IPAddress ipAddress = null;
            if (IPAddress.TryParse(serverIp, out ipAddress))
            {
                return ipAddress;
            }

            IPHostEntry hostEntry = Dns.GetHostEntry(serverIp);
            IPAddress[] addresses = hostEntry.AddressList;

#if NoSocket
            return addresses[0];
#else
            foreach (IPAddress ipA in addresses)
            {
                if (ipA.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ipA;
                }
            }

            foreach (IPAddress ipA in addresses)
            {
                if (ipA.AddressFamily == AddressFamily.InterNetworkV6)
                {
                    return ipA;
                }
            }

            return null;
#endif
        }
#endif
    }
}