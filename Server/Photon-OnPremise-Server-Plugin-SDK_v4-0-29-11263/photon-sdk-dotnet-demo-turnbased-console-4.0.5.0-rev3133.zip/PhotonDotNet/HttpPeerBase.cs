﻿//#define DEBUG_LOG_REQ_RESP
// --------------------------------------------------------------------------------------------------------------------
// <copyright file="HttpBase.cs" company="Exit Games GmbH">
//   Exit Games GmbH, 2011
// </copyright>
// <summary>
//   Class to handle Http based connections to a Photon server.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Threading;

#if RHTTP

namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;

    /// <summary>
    /// Class to handle Http based connections to a Photon server.
    /// Requests are done asynchronous and not queued at all.
    ///
    /// All responses are put into the game's thread-context and 
    /// all results and state changes are done within calls of
    /// Service() or DispatchIncomingCommands().
    /// </summary>
    internal abstract class HttpPeerBase : PeerBase
    {
#if DEBUG_LOG_REQ_RESP
        private static readonly DateTime Started = DateTime.Now;
#endif

        private static readonly byte[] PingData = { 0xF0, 0, 0, 0, 0 };

        protected string httpPeerId;

        protected readonly int challengId;

        protected string urlParameters;

        protected long lastPingTimeStamp;

        private readonly List<byte[]> incomingList = new List<byte[]>();

        private int lastSendAck;

        private bool sendAck;

        private readonly InvocationCache invocationCache = new InvocationCache();

        internal const int TcpHeaderLen = 7; // 0xfb, 0, 0, 0, 0, 0, 0

        private static readonly Random Rnd = new Random();

        protected readonly LinkedList<RequestStateBase> requestCache = new LinkedList<RequestStateBase>();

        private int stateIdBase = -1; // -1 to skip init request

        protected MemoryStream outgoingStream;

        private const int RerequestCountBeforeDiconnect = 30;

        protected int grossErrorCount = 0;

        protected const int MaxGrossErrors = 3;

        public delegate int GetLocalMsTimestampDelegate();

        internal GetLocalMsTimestampDelegate GetLocalMsTimestamp = () => Environment.TickCount;

        internal enum MessageType
        {
            Connect, 
            Disconnect, 
            Normal, 
        };

        internal static readonly byte[] MessageHeader = { 0xFB, 0, 0, 0, 0, 0, 0, 0xF3, 2 }; // just a message header (no length, etc)

        internal HttpPeerBase()
        {
            peerCount++;
            this.challengId = Rnd.Next();
            this.InitOnce();
        }

        internal HttpPeerBase(IPhotonPeerListener listener)
            : this()
        {
            // the check that the listener is non-null is done in PhotonPeer (where this is created)
            this.Listener = listener;
        }

        #region Properties

        internal int CurrentRequestCount
        {
            get
            {
                return this.requestCache.Count;
            }
        }

        internal int TotalRequestCount
        {
            get
            {
                return this.stateIdBase;
            }
        }

        /// <summary>
        /// The *pid* for this peer, which is assigned by the server on connect (init).
        /// Initially this is Guid.Empty.
        /// </summary>
        public override string PeerID
        {
            get
            {
                return this.httpPeerId;
            }
        }

        internal override int QueuedIncomingCommandsCount
        {
            get
            {
                return 0;
            }
        }

        internal override int QueuedOutgoingCommandsCount
        {
            get
            {
                return 0;
            }
        }

        internal string HttpPeerId
        {
            get
            {
                return this.httpPeerId;
            }
        }

        internal int ChallengId
        {
            get
            {
                return this.challengId;
            }
        }

        internal bool UseGet { get; set; }

        internal string UrlParameters 
        {
            get
            {
                return this.urlParameters;
            }
        }
        #endregion


        internal abstract class RequestStateBase
        {
            #region Fields

            public int Id = 0;
            /// how many times we have rererequested this request already
            public int Rerequested = 0;

            public bool Restarting = false;
            public MessageType Type;
            private Stopwatch watch;

            protected readonly HttpPeerBase peer;
            #endregion

            #region Constructors and Destructors

            protected RequestStateBase(HttpPeerBase peer)
            {
                this.peer = peer;
                this.watch = new Stopwatch();
                this.watch.Start();
            }

            protected RequestStateBase(byte[] data, MessageType type, int id, HttpPeerBase peer)
                : this(peer)
            {
                this.OutgoingData = data;
                this.Type = type;
                this.Id = id;
            }

            #endregion

            #region Public Properties

            public bool Aborted { get; set; }

            public int ElapsedTime
            {
                get
                {
                    return (int)this.watch.ElapsedMilliseconds;
                }
            }

            public bool IsDisconnect
            {
                get
                {
                    return this.Type == MessageType.Disconnect;
                }
            }

            public byte[] OutgoingData { get; set; }
            public LinkedListNode<RequestStateBase> ListNode { get; set; }

            #endregion

            #region Public Methods and Operators

            public abstract void CancelTimeout();
            public abstract void Abort();
            public abstract void StartRequest(bool useGet, string url);

            public virtual void Cleanup()
            {
                this.OutgoingData = null;
            }

            public void ResetWatch()
            {
                this.watch = new Stopwatch();
                this.watch.Start();
            }

            #endregion

        }

        /// <summary>
        /// The initial request uses "?init" as UrlParameters and the binary data is the app-id (binary in up to 32 bytes).
        /// Init returns a GUID for use in following requests as UrlParameters "?pid=GUID".
        /// </summary>
        /// <param name="data"></param>
        /// <param name="urlParameter">The url paramters to append to the server adress uri.</param>
        internal void Request(byte[] data, string urlParameter)
        {
            this.Request(data, urlParameter, MessageType.Normal);
        }

        protected abstract RequestStateBase CreateRequestState(byte[] data, MessageType type, int id);
        /// <param name="data"></param>
        /// <param name="urlParameter">The url paramters to append to the server adress uri.</param>
        /// <param name="type">identifies request type. CONNECT for connection, NORMAL for regualar requests
        /// and DISCONNECT for disconnection. If a disconnect is answered, change status to disconnected.</param>
        internal void Request(byte[] data, string urlParameter, MessageType type)
        {
            // Create a new HttpWebRequest object.
            var id = Interlocked.Increment(ref this.stateIdBase);

            this.AddAckId(ref urlParameter);

            var state = this.CreateRequestState(data, type, id);

#if !Unity
            lock (this.requestCache)
#endif
                state.ListNode = this.requestCache.AddLast(state);

            Request(state, urlParameter);
        }

        private void Request(RequestStateBase state, string urlParamter)
        {
            if (this.UseGet)
            {
                urlParamter += string.Format("&seq={0}&data={1}", state.Id, Convert.ToBase64String(state.OutgoingData, Base64FormattingOptions.None));
            }
            else
            {
                urlParamter += string.Format("&seq={0}", state.Id);
            }

            if (state.Type == MessageType.Disconnect)
            {
                urlParamter += "&dis";
            }

            state.StartRequest(this.UseGet, this.ServerAddress + urlParamter + this.HttpUrlParameters);

#if DEBUG_LOG_REQ_RESP
            Console.WriteLine("Request: pid:{0}, cid:{1}, stateId:{2}", this.httpPeerId, this.challengId, state.Id);
            Console.WriteLine("{0} REQ: reqid={1} bytes={2} (curr#req={3})", 
                (int)DateTime.Now.Subtract(Started).TotalMilliseconds, state.Id, state.OutgoingData == null ? "EMPTY" : state.OutgoingData.Length.ToString(), requestCache.Count);
//#endif
#else
            if (this.debugOut >= DebugLevel.ALL)
            {
                if (state.Id == 0)
                {
                    this.Listener.DebugReturn(DebugLevel.ALL, string.Format("REQ: INIT= {0}", urlParamter));
                }
                else
                {
                    this.Listener.DebugReturn(
                        DebugLevel.ALL,
                        string.Format(
                            "REQ: reqid={0} bytes={1} (curr#req={2})",
                            state.Id,
                            state.OutgoingData == null ? "EMPTY" : state.OutgoingData.Length.ToString(),
                            requestCache.Count));
                }
            }
#endif
        }

        private void AddAckId(ref string urlParamter)
        {
            if (this.sendAck)
            {
                this.sendAck = false;
                urlParamter += "&ack=" + this.lastSendAck;
                if (this.debugOut >= DebugLevel.ALL)
                {
                    this.Listener.DebugReturn(
                        DebugLevel.ALL, 
                        string.Format("ack sent for id {0}, pid={1}, cid={2}", this.lastSendAck, this.httpPeerId, this.challengId));
                }
            }
        }

        protected static bool GotIgnoreStatus(int code)
        {
            return code == 404;
        }

        internal void RerequestState(RequestStateBase state, string url, string requestUrl)
        {
            if (state.Rerequested < RerequestCountBeforeDiconnect)
            {
                ++state.Rerequested;
                state.Restarting = false;
#if DEBUG_LOG_REQ_RESP
                Console.WriteLine("ReRequest: pid:{0}, cid:{1}, stateId:{2}", this.httpPeerId, this.challengId, state.Id);
#endif
                if (this.debugOut >= DebugLevel.ALL)
                {
                    this.Listener.DebugReturn(DebugLevel.ALL, string.Format("rerequest for state {0} from exception handler", state.Id));
                }

                Request(state, url);
            }
            else
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.EnqueueDebugReturn(DebugLevel.ERROR, "Exception Url: " + requestUrl);
                }

                this.EnqueueErrorDisconnect(StatusCode.Exception);
            }
        }

        protected void CheckAckCondition()
        {
            if (requestCache.Count == 0)
            {
                return;
            }

            if (stateIdBase - this.rhttpMaxConnections - lastSendAck > 5)
            {
                int minRequestId = System.Linq.Enumerable.Min(requestCache, state => { return state.Id; });

                if (minRequestId != int.MaxValue && (minRequestId - this.lastSendAck > 5))
                {
                    this.lastSendAck = minRequestId - 2;
                    sendAck = true;
                }
            }
        }

        protected void CancelRequests()
        {
#if !Unity
            lock (this.requestCache)
            {
#endif
                foreach (var request in this.requestCache)
                {
                    request.Abort();
                    request.CancelTimeout();
                }

                this.requestCache.Clear();
#if !Unity
            }
#endif
        }

        protected void Reset()
        {
            this.lastSendAck = 0;
            this.stateIdBase = -1;
            this.sendAck = false;
            this.invocationCache.Reset();
            this.httpPeerId = string.Empty;
            this.CancelRequests();
        }

        internal override void Disconnect()
        {
            if (this.peerConnectionState != ConnectionStateValue.Disconnected && this.peerConnectionState != ConnectionStateValue.Disconnecting)
            {
                this.peerConnectionState = ConnectionStateValue.Disconnecting;
                this.CancelRequests();
                this.Request(null, this.urlParameters, MessageType.Disconnect);
                this.Disconnected();
            }
        }

        /// <summary>
        /// Called internally when some error (or timeout) causes a disconnect. this takes care state is set and callbacks are done (once)
        /// </summary>
        protected void EnqueueErrorDisconnect(StatusCode statusCode)
        {
            lock (this)
            {
                // disconnect is done only once per connection (even if multiple http requests are still "open")
                // to enforce this, we set the state to disconnecting and only do disconnect/error callbacks when (still) connected or connecting
                if (this.peerConnectionState != ConnectionStateValue.Connected && this.peerConnectionState != ConnectionStateValue.Connecting)
                {
                    // TODO: maybe log further exceptions and disconnect reasons?!
                    return;
                }

                this.peerConnectionState = ConnectionStateValue.Disconnecting;
            }

            if (this.debugOut >= DebugLevel.INFO)
            {
                this.Listener.DebugReturn(DebugLevel.INFO, string.Format("pid={0} cid={1} is disconnecting", this.httpPeerId, this.challengId));
            }

            this.EnqueueStatusCallback(statusCode);
            this.EnqueueActionForDispatch(this.Disconnected);
        }

        internal void Disconnected()
        {
            this.InitPeerBase(); // init to get all queues cleaned and sets state Disconnected

            if (this.debugOut >= DebugLevel.INFO)
            {
                this.Listener.DebugReturn(DebugLevel.INFO, string.Format("pid={0} cid={1} is disconnected", this.httpPeerId, this.challengId));
            }

            this.Listener.OnStatusChanged(StatusCode.Disconnect);
        }

        internal override void InitPeerBase()
        {
            this.peerConnectionState = ConnectionStateValue.Disconnected;
        }

        internal override void FetchServerTimestamp()
        {
            // in http, we don't do this
        }

        private bool DispatchIncomingActions()
        {
            // dispatch action queue
            lock (this.ActionQueue)
            {
                while (this.ActionQueue.Count > 0)
                {
                    MyAction action = this.ActionQueue.Dequeue();
                    action();
                }
            }

            // dispatch commands
            byte[] payload;
            lock (this.incomingList)
            {
                if (this.incomingList.Count <= 0)
                {
                    return false;
                }

                payload = this.incomingList[0];
                this.incomingList.RemoveAt(0);
            }

            this.ByteCountCurrentDispatch = payload.Length + 3;   // count in the EG-TCP-Header of 3 bytes
            if (payload.Length < 2)
            {
                this.Listener.DebugReturn(DebugLevel.WARNING, string.Format("message has length less then 2. data {0}", SupportClass.ByteArrayToString(payload)));
            }
            return this.DeserializeMessageAndCallback(payload);             // either calls eventAction() OR OnStatusChanged() - return: success
        }

        internal override bool DispatchIncomingCommands()
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                // this.Listener.DebugReturn(DebugLevel.ALL,
                // string.Format("Disconneting. Call to DispatchIncomingCommands. Actions {0}, state {1}",
                // ActionQueue.Count, peerConnectionState));
            }

            return this.DispatchIncomingActions();
        }

        private void SendPing()
        {
            // checking for max connection count done in SendOutgoingCommands()
            if (this.GetLocalMsTimestamp() - this.lastPingTimeStamp > this.timePingInterval)
            {
                this.lastPingTimeStamp = this.GetLocalMsTimestamp(); // prevents sending another ping immediately
                var offset = 1;
                Protocol.Serialize(SupportClass.GetTickCount(), PingData, ref offset);
                this.Request(PingData, this.urlParameters);
            }

            var count = this.rhttpMinConnections - this.requestCache.Count;
            if (count > 0)
            {
                for (var i = 0; i < count; ++i)
                {
                    this.Request((byte[])null, this.urlParameters);
                }
            }
        }

        internal override bool SendOutgoingCommands()
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                return false;
            }

            if (this.requestCache.Count >= this.rhttpMaxConnections)
            {
#if DEBUG_LOG_REQ_RESP
                Console.Write(".");
                //Console.WriteLine("no more connections allowed: dont do anything until responses are receives");
#endif
                // no more connections allowed: dont do anything until responses are receives
                return false;
            }

            if (this.outgoingStream.Length > 0)
            {
                this.Request(this.outgoingStream.ToArray(), this.urlParameters);

                this.outgoingStream.SetLength(0);
                this.outgoingStream.Position = 0;
            }

            this.SendPing();

            return false;
        }

        private static int ReadMessageHeader(BinaryReader br)
        {
            var msgLen = (br.ReadByte() << 24) | (br.ReadByte() << 16) | (br.ReadByte() << 8) | br.ReadByte();

            // TODO - reliability & channles should probably passed backed correctly, how does tcp do it?

            br.ReadByte(); // reliable
            br.ReadByte(); // channel

            return msgLen;
        }

        internal override void ReceiveIncomingCommands(byte[] inBuff, int reqid)
        {
            if (this.peerConnectionState == ConnectionStateValue.Connecting)
            {
                if (BitConverter.IsLittleEndian)
                {
                    Array.Reverse(inBuff, 4, 4);
                }

                this.httpPeerId = BitConverter.ToInt32(inBuff, 4).ToString();

                this.urlParameters = "?pid=" + this.httpPeerId + "&cid=" + this.challengId;

                this.peerConnectionState = ConnectionStateValue.Connected;
                this.EnqueueActionForDispatch(this.InitCallback);
                return;
            }

            this.timestampOfLastReceive = this.GetLocalMsTimestamp();

            // our TCP message header got removed before this method was called. add those bytes to the count
            this.bytesIn += inBuff.Length + TcpHeaderLen;

            Array.Reverse(inBuff, 0, 4);
            var br = new BinaryReader(new MemoryStream(inBuff));
            var responseId = br.ReadInt32();

#if DEBUG_LOG_REQ_RESP
            Console.WriteLine("Response: pid:{0}, cid:{1}, stateId:{2}", this.httpPeerId, this.challengId, reqid);
            Console.WriteLine("{0} RESP: respid={1} reqid={2} bytes={3} (curr#req={4})", (int)DateTime.Now.Subtract(Started).TotalMilliseconds, responseId, reqid, inBuff.Length, requestCache.Count - 1);
#else
            if (this.debugOut >= DebugLevel.ALL)
            {
                this.Listener.DebugReturn(
                    DebugLevel.ALL,
                    string.Format("RESP: respid={0} reqid={1} bytes={2} (curr#req={3})",
                    responseId, reqid, inBuff.Length, requestCache.Count - 1));
            }
#endif
            this.invocationCache.Invoke(responseId, () => this.ParseMessage(inBuff, br));
        }

        private void ParseMessage(byte[] inBuff, BinaryReader reader)
        {
            using (reader)
            using (var baseStream = reader.BaseStream)
            {
                while (baseStream.Position != baseStream.Length)
                {
                    var tag = reader.ReadByte();
                    switch (tag)
                    {
                        case 0xFB:
                            {
                                var dataLen = ReadMessageHeader(reader) - TcpHeaderLen;
                                if (dataLen == -1)
                                {
                                    if (this.debugOut >= DebugLevel.ERROR)
                                    {
                                        this.Listener.DebugReturn(
                                            DebugLevel.ERROR, 
                                            string.Format(
                                                "Invalid message header for pid={0} cid={1} and message {2}", 
                                                this.httpPeerId, 
                                                this.challengId, 
                                                SupportClass.ByteArrayToString(inBuff)));
                                    }

                                    return;
                                }

                                Debug.Assert(dataLen >= 2);
                                var msgBuf = reader.ReadBytes(dataLen);
                                if (dataLen < 2)
                                {
                                    this.Listener.DebugReturn(
                                        DebugLevel.WARNING, 
                                        string.Format("data len is to small. data {0}", SupportClass.ByteArrayToString(inBuff)));
                                }

                                lock (this.incomingList)
                                {
                                    this.incomingList.Add(msgBuf);
                                    if (this.incomingList.Count % this.warningSize == 0)
                                    {
                                        this.EnqueueStatusCallback(StatusCode.QueueIncomingReliableWarning);
                                    }
                                }
                            }
                            break;
                        case 0xF0:
                            this.ReadPingResponse(reader);
                            break;
                        default:
                            this.Listener.DebugReturn(DebugLevel.WARNING, "Unknow response from server");
                            break;
                    }
                }
            }
        }

        private void ReadPingResponse(BinaryReader reader)
        {
            var serverSentTime = (reader.ReadByte() << 24) | (reader.ReadByte() << 16) | (reader.ReadByte() << 8) | reader.ReadByte();
            var clientSentTime = (reader.ReadByte() << 24) | (reader.ReadByte() << 16) | (reader.ReadByte() << 8) | reader.ReadByte();

            this.lastRoundTripTime = SupportClass.GetTickCount() - clientSentTime;
            if (!this.serverTimeOffsetIsAvailable)
            {
                this.roundTripTime = this.lastRoundTripTime;
            }

            this.UpdateRoundTripTimeAndVariance(this.lastRoundTripTime);

            if (!this.serverTimeOffsetIsAvailable)
            {
                this.serverTimeOffset = serverSentTime + (this.lastRoundTripTime >> 1) - SupportClass.GetTickCount();
                this.serverTimeOffsetIsAvailable = true;
            }
        }

        internal void OnReceiveData(byte[] responseData, int stateId)
        {
            if (responseData.Length > 0) // responseData can not be null
            {
                this.ReceiveIncomingCommands(responseData, stateId);
            }
            else
            {
#if DEBUG_LOG_REQ_RESP
                Console.WriteLine("Response: pid:{0}, cid:{1}, stateId:{2}", this.httpPeerId, this.challengId, stateId);
                Console.WriteLine("{0} RESP: respid={1} reqid={2} bytes={3} (curr#req={4})", (int)DateTime.Now.Subtract(Started).TotalMilliseconds, "N/A", stateId, "EMPTY", requestCache.Count - 1);
//#endif
#else
                if (this.debugOut >= DebugLevel.ALL)
                {
                    this.Listener.DebugReturn(
                        DebugLevel.ALL,
                        string.Format("RESP: respid={0} reqid={1} bytes={2} (curr#req={3})",
                            "N/A", stateId, "EMPTY", requestCache.Count - 1));
                }
#endif
            }
            Interlocked.Exchange(ref this.grossErrorCount, 0);
        }


        internal override bool EnqueueOperation(
            Dictionary<byte, object> parameters, 
            byte opCode, 
            bool sendReliable, 
            byte channelId, 
            bool encrypted, 
            EgMessageType messageType)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: " + opCode + "! Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            var fullMessageBytes = this.SerializeOperationToMessage(opCode, parameters, messageType, encrypted);
            if (fullMessageBytes == null)
            {
                return false;
            }

            this.outgoingStream.Write(fullMessageBytes, 0, fullMessageBytes.Length);
            return true;
        }

#if SDK_V4
        internal override bool EnqueueMessage(object message, bool sendReliable, byte channelId, bool encrypted)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            var fullMessageBytes = this.SerializeMessageToMessage(message, encrypted, MessageHeader);
            if (fullMessageBytes == null)
            {
                return false;
            }

            this.outgoingStream.Write(fullMessageBytes, 0, fullMessageBytes.Length);
            return true;
        }

        internal override bool EnqueueRawMessage(byte[] data, bool sendReliable, byte channelId, bool encrypted)
        {
            if (this.peerConnectionState != ConnectionStateValue.Connected)
            {
                if (this.debugOut >= DebugLevel.ERROR)
                {
                    this.Listener.DebugReturn(DebugLevel.ERROR, "Cannot send op: Not connected. PeerState: " + this.peerConnectionState);
                }

                this.Listener.OnStatusChanged(StatusCode.SendError);
                return false;
            }

            var fullMessageBytes = this.SerializeRawMessageToMessage(data, encrypted, MessageHeader);
            if (fullMessageBytes == null)
            {
                return false;
            }

            this.outgoingStream.Write(fullMessageBytes, 0, fullMessageBytes.Length);
            return true;
        }

#endif // SDK_V4

        internal override byte[] SerializeOperationToMessage(byte opCode, Dictionary<byte, object> parameters, EgMessageType messageType, bool encrypt)
        {
            byte[] fullMessageBytes;

            lock (this.SerializeMemStream)
            {
                // re-set the mem stream for next message and op (in message)
                this.SerializeMemStream.Position = 0;
                this.SerializeMemStream.SetLength(0);

                // write (prelimiary) message header (might be changed later on, due to encryption, etc)
                if (!encrypt)
                {
                    this.SerializeMemStream.Write(MessageHeader, 0, MessageHeader.Length);
                }

                // write bytes of op to memstream
                Protocol.SerializeOperationRequest(this.SerializeMemStream, opCode, parameters, false);

                // if we encrypt, the message header was left out, as we encrypt only the operation bytes
                if (encrypt)
                {
                    var opBytes = this.SerializeMemStream.ToArray();
                    opBytes = this.CryptoProvider.Encrypt(opBytes);

                    this.SerializeMemStream.Position = 0;
                    this.SerializeMemStream.SetLength(0);
                    this.SerializeMemStream.Write(MessageHeader, 0, MessageHeader.Length);
                    this.SerializeMemStream.Write(opBytes, 0, opBytes.Length);
                }

                fullMessageBytes = this.SerializeMemStream.ToArray();
            }

            // now update the message header according to type
            if (messageType != EgMessageType.Operation)
            {
                fullMessageBytes[MessageHeader.Length - 1] = (byte)messageType;
            }

            if (encrypt)
            {
                fullMessageBytes[MessageHeader.Length - 1] = (byte)(fullMessageBytes[MessageHeader.Length - 1] | 0x80);
            }

            // update length in tcp header. it's at position 1 (to 4)
            var offsetForLength = 1;
            Protocol.Serialize(fullMessageBytes.Length, fullMessageBytes, ref offsetForLength);

            return fullMessageBytes;
        }

        internal override void StopConnection()
        {
        }

        internal void OnRequestHandled(RequestStateBase state)
        {
#if !Unity
            lock (this.requestCache)
            {
#endif
            this.CheckAckCondition();
                this.requestCache.Remove(state.ListNode);

                state.Cleanup();
#if !Unity
            }
#endif
        }
    }
}

#endif