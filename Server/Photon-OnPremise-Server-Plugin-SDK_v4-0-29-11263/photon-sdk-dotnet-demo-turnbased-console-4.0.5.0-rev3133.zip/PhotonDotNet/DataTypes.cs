﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DataTypes.cs" company="Exit Games GmbH">
//  Exit Games GmbH 2013
// </copyright>
// <summary>
//  Contains re-implementations of classes for platforms that don't include them.
//  Example: Hashtable is not in the API for Windows Store or Win 8 Phone.
// </summary>

namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

#if !SYSTEM_HASHTABLE
    /// <summary>
    /// This is a substitute for the Hashtable class, missing in: Win8RT and Windows Phone. It uses a Dictionary&lt;object,object&gt; as base.
    /// </summary>
    /// <remarks>
    /// Please be aware that this class might act differently than the Hashtable equivalent.
    /// As far as Photon is concerned, the substitution is sufficiently precise.
    /// </remarks>
    public class Hashtable : Dictionary<object, object>
    {
        public Hashtable()
        {
        }

        public Hashtable(int x) : base(x)
        {
        }

        new public object this[object key]
        {
            get
            {
                object ret = null;
                TryGetValue(key, out ret);
                return ret;
            }
            set
            {
                base[key] = value;
            }
        }

        private DictionaryEntryEnumerator enumerator;


        new public IEnumerator<DictionaryEntry> GetEnumerator()
        {
            return new DictionaryEntryEnumerator(((IDictionary)this).GetEnumerator());
        }

        public override String ToString()
        {
            List<String> temp = new List<string>();
            foreach (Object key in Keys)
            {
                if (key == null || this[key] == null)
                {
                    temp.Add(key + "=" + this[key]);
                }
                else
                {
                    temp.Add("(" + key.GetType() + ")" + key + "=(" + this[key].GetType() + ")" + this[key]);
                }
            }
            return String.Join(", ", temp.ToArray());
        }

        /// <summary>
        /// Creates a shallow copy of the Hashtable.
        /// </summary>
        /// <remarks>
        /// A shallow copy of a collection copies only the elements of the collection, whether they are
        /// reference types or value types, but it does not copy the objects that the references refer
        /// to. The references in the new collection point to the same objects that the references in
        /// the original collection point to.
        /// </remarks>
        /// <returns>Shallow copy of the Hashtable.</returns>
        public object Clone()
        {
            return new Dictionary<object, object>(this);
    }
    }

    public class DictionaryEntryEnumerator : IEnumerator<DictionaryEntry>
    {
        private IDictionaryEnumerator enumerator;

        public DictionaryEntryEnumerator(IDictionaryEnumerator original)
        {
            this.enumerator = original;
        }

        public bool MoveNext()
        {
            return this.enumerator.MoveNext();
        }

        public void Reset()
        {
            this.enumerator.Reset();
        }

        object IEnumerator.Current { get { return (DictionaryEntry)this.enumerator.Current; } }

        public DictionaryEntry Current { get { return (DictionaryEntry)this.enumerator.Current; } }
        public object Key { get { return this.enumerator.Key; } }
        public object Value { get { return this.enumerator.Value; } }
        public DictionaryEntry Entry { get { return this.enumerator.Entry; } }

        public void Dispose()
        {
            this.enumerator = null;
        }
    }
#endif
}
