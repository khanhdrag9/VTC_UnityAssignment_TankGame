﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IPhotonListener.cs" company="Exit Games GmbH">
//   Protocol & Photon Client Lib - Copyright (C) 2010 Exit Games GmbH
// </copyright>
// <summary>
//   This file keeps enums, structs and the PhotonListener interface.
// </summary>
// <author>developer@photonengine.com</author>
// --------------------------------------------------------------------------------------------------------------------
namespace ExitGames.Client.Photon
{
    using System;
    
    /// <summary>
    /// Enumeration of situations that change the peers internal status. 
    /// Used in calls to OnStatusChanged to inform your application of various situations that might happen.
    /// </summary>
    /// <remarks>
    /// Most of these codes are referenced somewhere else in the documentation when they are relevant to methods.
    /// </remarks>
    public enum StatusCode : int
    {
        /// <summary>the PhotonPeer is connected.<br/>See {@link PhotonListener#OnStatusChanged}*</summary>
        Connect = 1024,

        /// <summary>the PhotonPeer just disconnected.<br/>See {@link PhotonListener#OnStatusChanged}*</summary>
        Disconnect = 1025,

        /// <summary>the PhotonPeer encountered an exception and will disconnect, too.<br/>See {@link PhotonListener#OnStatusChanged}*</summary>
        Exception = 1026,

        /// <summary>the PhotonPeer encountered an exception while opening the incoming connection to the server. The server could be down / not running or the client has no network or a misconfigured DNS.<br/>See {@link PhotonListener#OnStatusChanged}*</summary>
        ExceptionOnConnect = 1023,

        /// <summary>Used on platforms that throw a security exception on connect. Unity3d does this, e.g., if a webplayer build could not fetch a policy-file from a remote server.</summary>
        SecurityExceptionOnConnect = 1022,

        /// <summary>PhotonPeer outgoing queue is filling up. send more often.</summary>
        QueueOutgoingReliableWarning = 1027,

        /// <summary>PhotonPeer outgoing queue is filling up. send more often.</summary>
        QueueOutgoingUnreliableWarning = 1029,

        /// <summary>Sending command failed. Either not connected, or the requested channel is bigger than the number of initialized channels.</summary>
        SendError = 1030,

        /// <summary>PhotonPeer outgoing queue is filling up. send more often.</summary>
        QueueOutgoingAcksWarning = 1031,

        /// <summary>PhotonPeer incoming queue is filling up. Dispatch more often.</summary>
        QueueIncomingReliableWarning = 1033,

        /// <summary>PhotonPeer incoming queue is filling up. Dispatch more often.</summary>
        QueueIncomingUnreliableWarning = 1035,

        /// <summary>PhotonPeer incoming queue is filling up. Dispatch more often.</summary>
        QueueSentWarning = 1037,

        /// <summary>Exception, if a server cannot be connected. Most likely, the server is not responding. Ask user to try again later.</summary>
        ExceptionOnReceive = 1039,
        
        /// <summary>Exception, if a server cannot be connected. Most likely, the server is not responding. Ask user to try again later.</summary>
        [Obsolete("Replaced by ExceptionOnReceive")]
        InternalReceiveException = 1039,

        /// <summary>Disconnection due to a timeout (client did no longer receive ACKs from server).</summary>
        TimeoutDisconnect = 1040,

        /// <summary>Disconnect by server due to timeout (received a disconnect command, cause server misses ACKs of client).</summary>
        DisconnectByServer = 1041,

        /// <summary>Disconnect by server due to concurrent user limit reached (received a disconnect command).</summary>
        DisconnectByServerUserLimit = 1042,

        /// <summary>Disconnect by server due to server's logic (received a disconnect command).</summary>
        DisconnectByServerLogic = 1043,

        /// <summary>Tcp Router Response. Only used when Photon is setup as TCP router! Routing is ok.</summary>
        [Obsolete("TCP routing was removed after becoming obsolete.")]
        TcpRouterResponseOk = 1044,

        /// <summary>Tcp Router Response. Only used when Photon is setup as TCP router! Routing node unknown. Check client connect values.</summary>
        [Obsolete("TCP routing was removed after becoming obsolete.")]
        TcpRouterResponseNodeIdUnknown = 1045,

        /// <summary>Tcp Router Response. Only used when Photon is setup as TCP router! Routing endpoint unknown.</summary>
        [Obsolete("TCP routing was removed after becoming obsolete.")]
        TcpRouterResponseEndpointUnknown = 1046,

        /// <summary>Tcp Router Response. Only used when Photon is setup as TCP router! Routing not setup yet. Connect again.</summary>
        [Obsolete("TCP routing was removed after becoming obsolete.")]
        TcpRouterResponseNodeNotReady = 1047,

        /// <summary>(1048) Value for OnStatusChanged()-call, when the encryption-setup for secure communication finished successfully.</summary>
        EncryptionEstablished = 1048,

        /// <summary>(1049) Value for OnStatusChanged()-call, when the encryption-setup failed for some reason. Check debug logs.</summary>
        EncryptionFailedToEstablish = 1049,
    }

    /// <summary>
    /// Callback interface for the Photon client side. Must be provided to a new PhotonPeer in its constructor.
    /// </summary>
    /// <remarks>
    /// These methods are used by your PhotonPeer instance to keep your app updated. Read each method's
    /// description and check out the samples to see how to use them.
    /// </remarks>
    public interface IPhotonPeerListener
    {
        /// <summary>
        /// Provides textual descriptions for various error conditions and noteworthy situations.
        /// In cases where the application needs to react, a call to OnStatusChanged is used.
        /// OnStatusChanged gives "feedback" to the game, DebugReturn provies human readable messages 
        /// on the background.
        /// </summary>
        /// <remarks>
        /// All debug output of the library will be reported through this method. Print it or put it in a 
        /// buffer to use it on-screen. Use PhotonPeer.DebugOut to select how verbose the output is.
        /// </remarks>
        /// <param name="level">DebugLevel (severity) of the message.</param>
        /// <param name="message">Debug text. Print to System.Console or screen.</param>
        void DebugReturn(DebugLevel level, string message);

        /// <summary>
        /// Callback method which gives you (async) responses for called operations.
        /// </summary>
        /// <remarks>
        /// Similar to method-calling, operations can have a result. 
        /// Because operation-calls are non-blocking and executed on the server, responses are provided 
        /// after a roundtrip as call to this method.
        /// 
        /// Example: Trying to create a room usually succeeds but can fail if the room's name is already
        /// in use (room names are their IDs).
        /// 
        /// This method is used as general callback for all operations. Each response corresponds to a certain 
        /// &quot;type&quot; of operation by its OperationCode (see: <see cref="Operations" />).
        /// <para></para>
        /// </remarks>
        /// <example>
        /// When you join a room, the server will assign a consecutive number to each client: the 
        /// &quot;actorNr&quot; or &quot;player number&quot;. This is sent back in the OperationResult's 
        /// Parameters as value of key <see cref="EventCode.ActorNr" />.<para></para>
        /// 
        /// Fetch your actorNr of a Join response like this:<para></para>
        /// <c>int actorNr = (int)operationResponse[(byte)OperationCode.ActorNr];</c>
        /// </example>
        /// <param name="operationResponse">The response to an operation\-call.</param>                                                          
        void OnOperationResponse(OperationResponse operationResponse);

        /// <summary>
        /// OnStatusChanged is called to let the game know when asyncronous actions finished or when errors happen.
        /// </summary>
        /// <remarks>
        /// Not all of the many StatusCode values will apply to your game. Example: If you don't use encryption, 
        /// the respective status changes are never made.
        /// 
        /// The values are all part of the StatusCode enumeration and described value-by-value.
        /// </remarks>
        /// <param name="statusCode">A code to identify the situation.</param>
        void OnStatusChanged(StatusCode statusCode);

        /// <summary>
        /// Called whenever an event from the Photon Server is dispatched.
        /// </summary>
        /// <remarks>
        /// Events are used for communication between clients and allow the server to update clients over time. 
        /// The creation of an event is often triggered by an operation (called by this client or an other). 
        /// 
        /// Each event carries its specific content in its Parameters. Your application knows which content to
        /// expect by checking the event's 'type', given by the event's Code.
        /// 
        /// Events can be defined and extended server-side. 
        /// 
        /// If you use the LoadBalancing application as base, several events like EvJoin and EvLeave are already defined.
        /// For these events and their Parameters, the library provides constants, so check the EventCode and ParameterCode 
        /// classes.
        /// 
        /// Photon also allows you to come up with custom events on the fly, purely client-side. To do so, use 
        /// OpRaiseEvent.<para></para>
        /// 
        /// Events are buffered on the client side and must be Dispatched. This way, OnEvent is always taking
        /// place in the same thread as a <see cref="PhotonPeer.DispatchIncomingCommands" /> call.
        /// </remarks>
        /// <param name="eventData">The event currently being dispatched.</param>
        void OnEvent(EventData eventData);

#if SDK_V4
        void OnMessage(object messages);
#endif//SDK_V4
    }
}
