// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NCommand.cs" company="Exit Games GmbH">
//   Exit Games GmbH, 2011
// </copyright>
// <summary>
//   Internal classes representing Enet Commands.
// </summary>
// <author>developer@photonengine.com</author>
// --------------------------------------------------------------------------------------------------------------------

namespace ExitGames.Client.Photon
{
    using System;

    /// <summary> Internal class for "commands" - the package in which operations are sent.</summary>
    internal class NCommand : IComparable<NCommand>
    {
        internal byte commandFlags;
        //types of flags
        internal const int FLAG_RELIABLE = 1;
        internal const int FLAG_UNSEQUENCED = 2;

        internal const byte FV_UNRELIABLE = 0; //FlagValue 0 = unreliable, sequenced
        internal const byte FV_RELIABLE = 1; //FlagValue 1 = reliable, sequenced
        internal const byte FV_UNRELIBALE_UNSEQUENCED = 2; //FlagValue 2 = unreliable, unsequenced
        //final static byte FV_RELIBALE_UNSEQUENCED   = 3;        //FlagValue 3 = reliable, sequenced

        internal byte commandType;
        //command types (gaps are unused commands
        internal const byte CT_NONE = 0;
        internal const byte CT_ACK = 1;
        internal const byte CT_CONNECT = 2;
        internal const byte CT_VERIFYCONNECT = 3;
        internal const byte CT_DISCONNECT = 4;
        internal const byte CT_PING = 5;
        internal const byte CT_SENDRELIABLE = 6;
        internal const byte CT_SENDUNRELIABLE = 7; //but ordered
        internal const byte CT_SENDFRAGMENT = 8; //fragment
        //9 bandwidth limit
        //10 throttle config
        //internal const byte CT_SENDUNSEQUENCED = 11; //not ordered at all
        internal const byte CT_EG_SERVERTIME = 12; //immediately acknowledged (ack sent without any other commands)

        //variables from CommandHeader
        internal byte commandChannelID;
        //byte command;             //replaced by commandType
        //int commandLength;        //not nessessary
        //protected byte flags;     //replaced by commandFlags
        //protected byte reserved;  //not needed (fixed value)
        internal int reliableSequenceNumber;
        internal int unreliableSequenceNumber;
        internal int unsequencedGroupNumber;
        internal byte reservedByte = 4; // in enet this is always 4. in photon, we use this to mark "disconnect causes". 2 = timeout.

        //variables for fragments (not used otherwise)
        internal int startSequenceNumber;
        internal int fragmentCount;
        internal int fragmentNumber;
        internal int totalLength;
        internal int fragmentOffset;
        internal int fragmentsRemaining;


        //variables from: OutgoingCommand
        internal byte[] Payload; //replaces "Packet"
        internal int commandSentTime; //last time the command was sent
        internal byte commandSentCount; //counts the number of retries (before calling it a loss)
        internal int roundTripTimeout;      // milliseconds until the command is resent
        internal int timeoutTime;  //timestamp after which the command triggers a timeout-disconnect

        //variables of various commands
        internal int ackReceivedReliableSequenceNumber; //for ACK commands
        internal int ackReceivedSentTime; //for ACK commands


        internal const int HEADER_UDP_PACK_LENGTH = 12; // enat package header. once in each package! multiple commands with individual headers follow.

        internal const int CmdSizeMinimum = 12; // minimal command is just a header and nothing else
        internal const int CmdSizeAck = 20; // absolute size including command-header
        internal const int CmdSizeConnect = 44; // absolute size including command-header
        internal const int CmdSizeVerifyConnect = 44;
        internal const int CmdSizeDisconnect = CmdSizeMinimum;
        internal const int CmdSizePing = CmdSizeMinimum;
        internal const int CmdSizeReliableHeader = 12;
        internal const int CmdSizeUnreliableHeader = 16;
        internal const int CmdSizeFragmentHeader = 32;  // fragment-command headers: 12 bytes "common" header + 20 bytes "special" fragment header.
        internal const int CmdSizeMaxHeader = 32 + 4;   // fragment-command header + 4 bytes CRC check.

        private byte[] completeCommand; // used in Serialize()
        internal int Size;


        /// <summary>this variant does only create outgoing commands and increments . incoming ones are created from a DataInputStream</summary>
        internal NCommand(EnetPeer peer, byte commandType, byte[] payload, byte channel)
        {
            this.commandType = commandType;
            this.commandFlags = FV_RELIABLE;
            this.commandChannelID = channel;
            this.Payload = payload;
            this.Size = CmdSizeMinimum;    // apply default size. below, most types set their correct size value!

            switch (this.commandType)
            {
                case CT_CONNECT:
                    this.Size = CmdSizeConnect;

                    // fake content of "connect" command (most data is unused)
                    this.Payload = new byte[32];
                    this.Payload[0] = (byte)0; // peerID (high)
                    this.Payload[1] = (byte)0; // peerID
                    int mtuOffset = 2;
                    Protocol.Serialize((short)peer.mtu, this.Payload, ref mtuOffset);
                    this.Payload[4] = (byte)0x00; // win size (high)
                    this.Payload[5] = (byte)0x00; // win size
                    this.Payload[6] = (byte)0x80; // win size
                    this.Payload[7] = (byte)0x00; // win size
                    this.Payload[11] = (byte)peer.ChannelCount; // channel count
                    this.Payload[15] = (byte)0x00; // in bandwidth
                    this.Payload[19] = (byte)0x00; // out band
                    this.Payload[22] = (byte)0x13; // Throttle interval (high)
                    this.Payload[23] = (byte)0x88; // T interv
                    this.Payload[27] = (byte)0x02; // T acc
                    this.Payload[31] = (byte)0x02; // T dec
                    break;

                case CT_DISCONNECT:
                    this.Size = CmdSizeDisconnect;

                    // connected peers send DISCONNECT as reliable. not connected peers just destroy themselves
                    if (peer.peerConnectionState != PeerBase.ConnectionStateValue.Connected)
                    {
                        this.commandFlags = (byte)FLAG_UNSEQUENCED;

                        if (peer.peerConnectionState == PeerBase.ConnectionStateValue.Zombie)
                        {
                            reservedByte = 2;
                        }
                    }
                    break;

                case CT_SENDRELIABLE:
                    this.Size = CmdSizeReliableHeader + payload.Length;
                    break;

                case CT_SENDUNRELIABLE:
                    this.Size = CmdSizeUnreliableHeader + payload.Length;
                    this.commandFlags = FV_UNRELIABLE;
                    break;

                case CT_SENDFRAGMENT:
                    this.Size = CmdSizeFragmentHeader + payload.Length;
                    break;

                case CT_ACK:
                    this.Size = CmdSizeAck;
                    this.commandFlags = FV_UNRELIABLE;
                    break;
            }
        } // NCommand

        internal static NCommand CreateAck(EnetPeer peer, NCommand commandToAck, int sentTime)
        {
            byte[] payload = new byte[8];
            int offset = 0;

            Protocol.Serialize((int)commandToAck.reliableSequenceNumber, payload, ref offset);
            Protocol.Serialize((int)sentTime, payload, ref offset);

            NCommand ack = new NCommand(peer, CT_ACK, payload, commandToAck.commandChannelID);
            ack.ackReceivedReliableSequenceNumber = (int)commandToAck.reliableSequenceNumber;
            ack.ackReceivedSentTime = sentTime;
            return ack;
        }

        /// <summary>reads the command values (commandHeader and command-values) from incoming bytestream and populates the incoming command*</summary>
        internal NCommand(EnetPeer peer, byte[] inBuff, ref int readingOffset)
        {
            // create/fill CommandHeader
            this.commandType = inBuff[readingOffset++];
            this.commandChannelID = inBuff[readingOffset++];
            this.commandFlags = inBuff[readingOffset++];
            this.reservedByte = inBuff[readingOffset++];    // reserved byte is used by EG as "disconnect reason" but has fixed value otherwise
            Protocol.Deserialize(out this.Size, inBuff, ref readingOffset);
            Protocol.Deserialize(out this.reliableSequenceNumber, inBuff, ref readingOffset);

            peer.bytesIn += this.Size; // the single UDP packet header is added in PhotonPeer.receiveIncomingCommands()

            // TODO: add check of commandLength versus MTU?

            // read the "body" of the command, depending on the type
            switch (this.commandType)
            {
                case CT_ACK:
                    Protocol.Deserialize(out this.ackReceivedReliableSequenceNumber, inBuff, ref readingOffset);
                    Protocol.Deserialize(out this.ackReceivedSentTime, inBuff, ref readingOffset);
                    break;

                case CT_SENDRELIABLE:
                    this.Payload = new byte[this.Size - CmdSizeReliableHeader];
                    break;

                case CT_SENDUNRELIABLE:
                    Protocol.Deserialize(out this.unreliableSequenceNumber, inBuff, ref readingOffset);
                    this.Payload = new byte[this.Size - CmdSizeUnreliableHeader];
                    break;

                case CT_SENDFRAGMENT:
                    Protocol.Deserialize(out this.startSequenceNumber, inBuff, ref readingOffset);
                    Protocol.Deserialize(out this.fragmentCount, inBuff, ref readingOffset);
                    Protocol.Deserialize(out this.fragmentNumber, inBuff, ref readingOffset);
                    Protocol.Deserialize(out this.totalLength, inBuff, ref readingOffset);
                    Protocol.Deserialize(out this.fragmentOffset, inBuff, ref readingOffset);
                    this.Payload = new byte[this.Size - CmdSizeFragmentHeader];
                    this.fragmentsRemaining = this.fragmentCount; // only updated in start command for this fragment-sequence
                    break;

                case CT_VERIFYCONNECT:
                    short outgoingPeerID;
                    Protocol.Deserialize(out outgoingPeerID, inBuff, ref readingOffset);
                    // skip the rest of the values
                    readingOffset += 30;

                    //short returnedMtu = Protocol.deserializeShort(buffer);    // TODO check returned MTU (might be more than sent)
                    //mtu = buffer.getShort();
                    //windowSize = buffer.getInt();
                    //channelCount = buffer.getInt();
                    //incomingBandwidth = buffer.getInt();
                    //outgoingBandwidth = buffer.getInt();
                    //packetThrottleInterval = buffer.getInt();
                    //packetThrottleAcceleration = buffer.getInt();
                    //packetThrottleDeceleration = buffer.getInt();
                    //byte[] verifyConn = new byte[30];           //read the (ignored) rest of the command


                    // don't change the peer ID once it was assigned to this peer
                    if (peer.peerID == unchecked((short)0xFFFF))
                    {
                        peer.peerID = outgoingPeerID; // set the outgoing peerID as defined by server/host
                    }

                    // next line was moved to executeCommand()
                    // peer.peerConnectionState = PhotonPeer.PS_CONNECTED;        //peer is connected
                    break;
            } // switch


            if (this.Payload != null)
            {
                Buffer.BlockCopy(inBuff, readingOffset, this.Payload, 0, this.Payload.Length);
                readingOffset += this.Payload.Length;
            }
        }

        internal byte[] Serialize()
        {
            // peer.Listener.DebugReturn("Serialize()");
            if (this.completeCommand != null)
            {
                return this.completeCommand;
            }

            int payloadLength = (this.Payload == null) ? 0 : this.Payload.Length;
            int headerLength = CmdSizeMinimum;
            if (this.commandType == CT_SENDUNRELIABLE)
            {
                headerLength = CmdSizeUnreliableHeader;
            }
            else if (this.commandType == CT_SENDFRAGMENT)
            {
                headerLength = CmdSizeFragmentHeader;
            }

            this.completeCommand = new byte[headerLength + payloadLength];

            // create/fill CommandHeader
            this.completeCommand[0] = (byte)this.commandType;
            this.completeCommand[1] = (byte)this.commandChannelID; // channelID
            this.completeCommand[2] = (byte)this.commandFlags;
            this.completeCommand[3] = (byte)this.reservedByte; // check comment at definition why this is a variable
            int offset = 4;
            Protocol.Serialize((int)this.completeCommand.Length, this.completeCommand, ref offset);
            Protocol.Serialize((int)this.reliableSequenceNumber, this.completeCommand, ref offset);

            if (this.commandType == CT_SENDUNRELIABLE)
            {
                offset = 12;
                Protocol.Serialize((int)this.unreliableSequenceNumber, this.completeCommand, ref offset);
            }
            else if (this.commandType == CT_SENDFRAGMENT)
            {
                offset = 12;
                Protocol.Serialize((int)this.startSequenceNumber, this.completeCommand, ref offset);
                Protocol.Serialize((int)this.fragmentCount, this.completeCommand, ref offset);
                Protocol.Serialize((int)this.fragmentNumber, this.completeCommand, ref offset);
                Protocol.Serialize((int)this.totalLength, this.completeCommand, ref offset);
                Protocol.Serialize((int)this.fragmentOffset, this.completeCommand, ref offset);
            }

            // copy command-bytes behind the (just created) command-header
            if (payloadLength > 0)
            {
                Buffer.BlockCopy(this.Payload, 0, this.completeCommand, headerLength, payloadLength);   // copy source to destination
            }

            this.Payload = null;
            return this.completeCommand;
        }

        public int CompareTo(NCommand other)
        {
            if ((this.commandFlags & FLAG_RELIABLE) != 0)
            {
                return this.reliableSequenceNumber - other.reliableSequenceNumber;
            }

            return this.unreliableSequenceNumber - other.unreliableSequenceNumber;
        }

        public override System.String ToString()
        {
            if (this.commandType == CT_ACK)
            {
                return String.Format("CMD({1} ack for c#:{0} s#/time {2}/{3})", commandChannelID, commandType, ackReceivedReliableSequenceNumber, ackReceivedSentTime);
            }

            return String.Format("CMD({1} c#:{0} r/u: {2}/{3} st/r#/rt:{4}/{5}/{6})", commandChannelID, commandType, reliableSequenceNumber, unreliableSequenceNumber, commandSentTime, commandSentCount, this.timeoutTime);
        }
    }
}