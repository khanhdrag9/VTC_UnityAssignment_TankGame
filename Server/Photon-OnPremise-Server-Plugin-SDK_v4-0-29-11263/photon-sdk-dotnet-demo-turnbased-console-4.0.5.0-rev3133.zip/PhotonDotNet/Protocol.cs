// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Protocol.cs" company="Exit Games GmbH">
//  Exit Games GmbH 2010
// </copyright>
// <summary>
//  Namespace for the Exitgames Protocol client library.
// </summary>


namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Diagnostics;


    #region Additional Definitions

    /// <summary>
    /// Container for an Operation request, which is a code and parameters.
    /// </summary>
    /// <remarks>
    /// On the lowest level, Photon only allows byte-typed keys for operation parameters.
    /// The values of each such parameter can be any serializable datatype: byte, int, hashtable and many more.
    /// </remarks>
    public class OperationRequest
    {
        /// <summary>Byte-typed code for an operation - the short identifier for the server's method to call.</summary>
        public byte OperationCode;
        /// <summary>The parameters of the operation - each identified by a byte-typed code in Photon.</summary>
        public Dictionary<byte, object> Parameters;
    }

    /// <summary>
    /// Contains the server's response for an operation called by this peer.
    /// The indexer of this class actually provides access to the Parameters Dictionary.
    /// </summary>
    /// <remarks>
    /// The OperationCode defines the type of operation called on Photon and in turn also the Parameters that
    /// are set in the request. Those are provided as Dictionary with byte-keys.
    /// There are pre-defined constants for various codes defined in the LoadBalancing application. 
    /// Check: OperationCode, ParameterCode, etc.
    /// <para></para>
    /// An operation's request is summarized by the ReturnCode: a short typed code for &quot;Ok&quot; or
    /// some different result. The code's meaning is specific per operation. An optional DebugMessage can be
    /// provided to simplify debugging.
    /// <para></para>
    /// Each call of an operation gets an ID, called the &quot;invocID&quot;. This can be matched to the IDs
    /// returned with any operation calls. This way, an application could track if a certain OpRaiseEvent
    /// call was successful.
    /// </remarks>
    public class OperationResponse
    {
        /// <summary>The code for the operation called initially (by this peer).</summary>
        /// <remarks>Use enums or constants to be able to handle those codes, like OperationCode does.</remarks>
        public byte OperationCode;
        /// <summary>A code that &quot;summarizes&quot; the operation's success or failure. Specific per operation. 0 usually means "ok".</summary>
        public short ReturnCode;
        /// <summary>An optional string sent by the server to provide readable feedback in error-cases. Might be null.</summary>
        public string DebugMessage;
        /// <summary>A Dictionary of values returned by an operation, using byte-typed keys per value.</summary>
        public Dictionary<byte, object> Parameters;

        /// <summary>
        /// Alternative access to the Parameters, which wraps up a TryGetValue() call on the Parameters Dictionary.
        /// </summary>
        /// <param name="parameterCode">The byte-code of a returned value.</param>
        /// <returns>The value returned by the server, or null if the key does not exist in Parameters.</returns>
        public object this[byte parameterCode]
        {
            get
            {
                object o;
                this.Parameters.TryGetValue(parameterCode, out o);
                return o;
            }

            set
            {
                this.Parameters[parameterCode] = value;
            }
        }

        /// <summary>ToString() override.</summary>
        /// <returns>Relatively short output of OpCode and returnCode.</returns>
        public override string ToString()
        {
            return String.Format("OperationResponse {0}: ReturnCode: {1}.", OperationCode, ReturnCode);
        }

        /// <summary>Extensive output of operation results.</summary>
        /// <returns>To be used in debug situations only, as it returns a string for each value.</returns>
        public string ToStringFull()
        {
            return String.Format(
                "OperationResponse {0}: ReturnCode: {1} ({3}). Parameters: {2}",
                OperationCode,
                ReturnCode,
                SupportClass.DictionaryToString(Parameters),
                DebugMessage);
        }
    }

    /// <summary>
    /// Contains all components of a Photon Event.
    /// Event Parameters, like OperationRequests and OperationResults, consist of a Dictionary with byte-typed keys per value.
    /// </summary>
    /// <remarks>
    /// The indexer of this class provides access to the Parameters Dictionary.
    /// 
    /// The operation RaiseEvent allows you to provide custom event content. Defined in LoadBalancing, this
    /// CustomContent will be made the value of key ParameterCode.CustomEventContent.
    /// </remarks>
    public class EventData
    {
        /// <summary>The event code identifies the type of event.</summary>
        public byte Code;

        /// <summary>The Parameters of an event is a Dictionary<byte, object>.</summary>
        public Dictionary<byte, object> Parameters;

        /// <summary>
        /// Alternative access to the Parameters.
        /// </summary>
        /// <param name="key">The key byte-code of a event value.</param>
        /// <returns>The Parameters value, or null if the key does not exist in Parameters.</returns>
        public object this[byte key]
        {
            get
            {
                object o;
                this.Parameters.TryGetValue(key, out o);
                return o;
            }

            set
            {
                this.Parameters[key] = value;
            }
        }

        /// <summary>ToString() override.</summary>
        /// <returns>Short output of "Event" and it's Code.</returns>
        public override string ToString()
        {
            return String.Format("Event {0}.", Code.ToString());
        }

        /// <summary>Extensive output of the event content.</summary>
        /// <returns>To be used in debug situations only, as it returns a string for each value.</returns>
        public string ToStringFull()
        {
            return String.Format("Event {0}: {1}", this.Code, SupportClass.DictionaryToString(this.Parameters));
        }
    }

    /// <summary>
    ///   The gp type.
    /// </summary>
    internal enum GpType : byte
    {
        /// <summary>
        ///   Unkown type.
        /// </summary>
        Unknown = 0,

        /// <summary>
        ///   An array of objects.
        /// </summary>
        /// <remarks>
        ///   This type is new in version 1.5.
        /// </remarks>
        Array = (byte)'y', // 0x79 (121)

        /// <summary>
        ///   A boolean Value.
        /// </summary>
        Boolean = (byte)'o', // 0x6F

        /// <summary>
        ///   A byte value.
        /// </summary>
        Byte = (byte)'b',

        /// <summary>
        ///   An array of bytes.
        /// </summary>
        ByteArray = (byte)'x',

        /// <summary>
        ///   An array of objects.
        /// </summary>
        ObjectArray = (byte)'z',

        /// <summary>
        ///   A 16-bit integer value.
        /// </summary>
        Short = (byte)'k',

        /// <summary>
        ///   A 32-bit floating-point value.
        /// </summary>
        /// <remarks>
        ///   This type is new in version 1.5.
        /// </remarks>
        Float = (byte)'f',

        /// <summary>
        ///   A dictionary
        /// </summary>
        /// <remarks>
        ///   This type is new in version 1.6.
        /// </remarks>
        Dictionary = (byte)'D', // 0x44 (68)

        /// <summary>
        ///   A 64-bit floating-point value.
        /// </summary>
        /// <remarks>
        ///   This type is new in version 1.5.
        /// </remarks>
        Double = (byte)'d',

        /// <summary>
        ///   A Hashtable.
        /// </summary>
        Hashtable = (byte)'h',  //0x68

        /// <summary>
        ///   A 32-bit integer value.
        /// </summary>
        Integer = (byte)'i', // 0x69 (105)

        /// <summary>
        ///   An array of 32-bit integer values.
        /// </summary>
        IntegerArray = (byte)'n',

        /// <summary>
        ///   A 64-bit integer value.
        /// </summary>
        Long = (byte)'l',

        /// <summary>
        ///   A string value.
        /// </summary>
        String = (byte)'s',

        /// <summary>
        ///   An array of string values.
        /// </summary>
        StringArray = (byte)'a',

        /// <summary>
        ///   A costum type
        /// </summary>
        Custom = (byte)'c',

        /// <summary>
        ///   Null value don't have types.
        /// </summary>
        Null = (byte)'*',

        EventData = (byte)'e',
        OperationRequest = (byte)'q',
        OperationResponse = (byte)'p',

        ////MethodCall = (byte)'m'
    }

    /// <summary>
    /// Type of serialization methods to add custom type support.
    /// Use PhotonPeer.ReisterType() to register new types with serialization and deserialization methods.
    /// </summary>
    /// <param name="customObject">The method will get objects passed that were registered with it in RegisterType().</param>
    /// <returns>Return a byte[] that resembles the object passed in. The framework will surround it with length and type info, so don't include it.</returns>
    public delegate byte[] SerializeMethod(object customObject);
    public delegate short SerializeStreamMethod(MemoryStream outStream, object customObject);

    /// <summary>
    /// Type of deserialization methods to add custom type support.
    /// Use PhotonPeer.RegisterType() to register new types with serialization and deserialization methods.
    /// </summary>
    /// <param name="serializedCustomObject">The framwork passes in the data it got by the associated SerializeMethod. The type code and length are stripped and applied before a DeserializeMethod is called.</param>
    /// <returns>Return a object of the type that was associated with this method through RegisterType().</returns>
    public delegate object DeserializeMethod(byte[] serializedCustomObject);
    public delegate object DeserializeStreamMethod(MemoryStream inStream, short length);

    internal class CustomType
    {
        public readonly byte Code;
        public readonly Type Type;
        public readonly SerializeMethod SerializeFunction;
        public readonly DeserializeMethod DeserializeFunction;
        public readonly SerializeStreamMethod SerializeStreamFunction;
        public readonly DeserializeStreamMethod DeserializeStreamFunction;

        public CustomType(Type type, byte code, SerializeMethod serializeFunction, DeserializeMethod deserializeFunction)
        {
            this.Type = type;
            this.Code = code;
            this.SerializeFunction = serializeFunction;
            this.DeserializeFunction = deserializeFunction;
        }

        public CustomType(Type type, byte code, SerializeStreamMethod serializeFunction, DeserializeStreamMethod deserializeFunction)
        {
            this.Type = type;
            this.Code = code;
            this.SerializeStreamFunction = serializeFunction;
            this.DeserializeStreamFunction = deserializeFunction;
        }
    }

    #endregion

    /// <summary>
    /// Provides tools for the Exit Games Protocol
    /// </summary>
    public class Protocol
    {
        public const string protocolType = "GpBinaryV16";

        #region CustomType Support

        internal static readonly Dictionary<Type, CustomType> TypeDict = new Dictionary<Type, CustomType>();
        internal static readonly Dictionary<byte, CustomType> CodeDict = new Dictionary<byte, CustomType>();

        internal static bool TryRegisterType(Type type, byte typeCode, SerializeMethod serializeFunction, DeserializeMethod deserializeFunction)
        {
            if (CodeDict.ContainsKey(typeCode) || TypeDict.ContainsKey(type))
            {
                return false;
            }

            var customType = new CustomType(type, typeCode, serializeFunction, deserializeFunction);
            CodeDict.Add(typeCode, customType);
            TypeDict.Add(type, customType);
            return true;
        }

        internal static bool TryRegisterType(Type type, byte typeCode, SerializeStreamMethod serializeFunction, DeserializeStreamMethod deserializeFunction)
        {
            if (CodeDict.ContainsKey(typeCode) || TypeDict.ContainsKey(type))
            {
                return false;
            }

            var customType = new CustomType(type, typeCode, serializeFunction, deserializeFunction);
            CodeDict.Add(typeCode, customType);
            TypeDict.Add(type, customType);
            return true;
        }

        private static bool SerializeCustom(MemoryStream dout, object serObject)
        {
            CustomType customType;
            if (TypeDict.TryGetValue(serObject.GetType(), out customType))
            {
                if (customType.SerializeStreamFunction == null)
                {
                    byte[] bytesOfCustomType = customType.SerializeFunction(serObject);

                    dout.WriteByte((byte) 'c');
                    dout.WriteByte(customType.Code);
                    SerializeShort(dout, (short) bytesOfCustomType.Length, false);
                    dout.Write(bytesOfCustomType, 0, bytesOfCustomType.Length);
                    return true;
                }
                else
                {
                    dout.WriteByte((byte)'c');
                    dout.WriteByte(customType.Code);

                    long posOfLengthInfo = dout.Position;
                    dout.Position = dout.Position + 2;

                    short serializedLength = customType.SerializeStreamFunction(dout, serObject);
                    long newPos = dout.Position;
                    dout.Position = posOfLengthInfo;
                    SerializeShort(dout, (short)serializedLength, false);
                    dout.Position = dout.Position + serializedLength;

                    if (dout.Position != newPos)
                    {
                        throw new Exception("Serialization failed. Stream position corrupted. Should be " + newPos + " is now: " + dout.Position + " serializedLength: " + serializedLength);
                    }
                    return true;
                }
            }

            return false;
        }

        private static object DeserializeCustom(MemoryStream din, byte customTypeCode)
        {
            short length = DeserializeShort(din);

            CustomType customType;
            if (CodeDict.TryGetValue(customTypeCode, out customType))
            {
                if (customType.DeserializeStreamFunction == null)
                {
                    byte[] bytes = new byte[length];
                    din.Read(bytes, 0, length);
                    return customType.DeserializeFunction(bytes);
                }
                else
                {
                    long pos = din.Position;
                    object result = customType.DeserializeStreamFunction(din, length);
                    int bytesRead = (int) (din.Position - pos);
                    if (bytesRead != length)
                    {
                        //UnityEngine.Debug.LogError("Custom Deserialization didn't use the bytes it should! Should read " + length + " did read: " + (bytesRead));
                        din.Position = pos + length;
                    }
                    return result;
                }
            }
            //else
            //{
            //    byte[] bytes = new byte[length];
            //    din.Read(bytes, 0, length);
            //    return bytes;
            //}

            return null;    // TODO: check how errors are provided?! could provide byte[] instead...?
        }


        #endregion

        #region Methods for de/serialization


        /// <summary>
        /// Serialize creates a byte-array from the given object and returns it.
        /// </summary>
        /// <param name="obj">The object to serialize</param>
        /// <returns>The serialized byte-array</returns>
        public static byte[] Serialize(object obj)
        {
            MemoryStream ms = new MemoryStream(64);
            Serialize(ms, obj, true);
            return ms.ToArray();
        }

        /// <summary>
        /// Deserialize returns an object reassembled from the given byte-array.
        /// </summary>
        /// <param name="serializedData">The byte-array to be Deserialized</param>
        /// <returns>The Deserialized object</returns>
        public static object Deserialize(byte[] serializedData)
        {
            MemoryStream memoryStream = new MemoryStream(serializedData);

            return Deserialize(memoryStream, (byte)memoryStream.ReadByte());
        }

        internal static object DeserializeMessage(MemoryStream stream)
        {
            return Deserialize(stream, (byte)stream.ReadByte());
        }

        internal static byte[] DeserializeRawMessage(MemoryStream stream)
        {
            return (byte[])Deserialize(stream, (byte)stream.ReadByte());
        }


        internal static void SerializeMessage(MemoryStream ms, object msg)
        {
            Serialize(ms, msg, true);
        }
        #endregion



        #region Type Identification



        private static Type GetTypeOfCode(byte typeCode)
        {
            switch (typeCode)
            {
                case (byte)'i':
                    return typeof(int);

                case (byte)'s':
                    return typeof(string);

                case (byte)'a':
                    return typeof(string[]);

                case (byte)'x':
                    return typeof(byte[]);

                case (byte)'n':
                    return typeof(int[]);

                case (byte)'h':
                    return typeof(Hashtable);

                case (byte)'D':
                    return typeof(IDictionary);

                case (byte)'o':
                    return typeof(bool);

                case (byte)'k':
                    return typeof(short);

                case (byte)'l':
                    return typeof(long);

                case (byte)'b':
                    return typeof(byte);

                case (byte)'f':
                    return typeof(float);

                case (byte)'d':
                    return typeof(double);

                case (byte)'y':
                    return typeof(Array);

                case (byte)'c':
                    return typeof(CustomType);

                case (byte)'z':
                    return typeof(object[]);

                case (byte)'e':
                    return typeof(EventData);

                case (byte)'q':
                    return typeof(OperationRequest);

                case (byte)'p':
                    return typeof(OperationResponse);

                case (byte)'*':
                case (byte)0:
                    return typeof(object);

                default:
                    Debug.WriteLine("missing type: " + typeCode);
                    throw new Exception("deserialize(): " + typeCode);
            }
        }

        private static GpType GetCodeOfType(Type type)
        {
#if NETFX_CORE
            if(type == typeof(Byte))
            {
                return GpType.Byte;
            }
            else if (type == typeof(String))
            {
                return GpType.String;
            }
            else if (type == typeof(Boolean))
            {
                return GpType.Boolean;
            }
            else if (type == typeof(Int16))
            {
                return GpType.Short;
            }
            else if (type == typeof(Int32))
            {
                return GpType.Integer;
            }
            else if (type == typeof(Int64))
            {
                return GpType.Long;
            }
            else if (type == typeof(Single))
            {
                return GpType.Float;
            }
            else if (type == typeof(Double))
            {
                return GpType.Double;
            }
#else
            TypeCode typeCode = Type.GetTypeCode(type);// this is not supported by Win8RT (api for store apps)

            switch (typeCode)
            {
                case TypeCode.Byte:
                    return GpType.Byte;
                case TypeCode.String:
                    return GpType.String;
                case TypeCode.Boolean:
                    return GpType.Boolean;
                case TypeCode.Int16:
                    return GpType.Short;
                case TypeCode.Int32:
                    return GpType.Integer;
                case TypeCode.Int64:
                    return GpType.Long;
                case TypeCode.Single:
                    return GpType.Float;
                case TypeCode.Double:
                    return GpType.Double;
            }
#endif

            // TODO: find out if this could be done simpler / faster?!
            if (type.IsArray)
            {
                if (type == typeof(byte[]))
                {
                    return GpType.ByteArray;
                }

                return GpType.Array;
            }

            if (type == typeof(Hashtable))
            {
                return GpType.Hashtable;
            }

#if NETFX_CORE || WINDOWS_PHONE
            if (type.IsConstructedGenericType && typeof(Dictionary<,>) == type.GetGenericTypeDefinition())
            {
                return GpType.Dictionary;
            }
#else
            if (type.IsGenericType && typeof(Dictionary<,>) == type.GetGenericTypeDefinition())
            {
                return GpType.Dictionary;
            }
#endif

            if (type == typeof(EventData))
            {
                return GpType.EventData;
            }
            if (type == typeof(OperationRequest))
            {
                return GpType.OperationRequest;
            }
            if (type == typeof(OperationResponse))
            {
                return GpType.OperationResponse;
            }

            return GpType.Unknown;
        }

        private static Array CreateArrayByType(byte arrayType, short length)
        {
            return Array.CreateInstance(GetTypeOfCode(arrayType), length);
        }

        #endregion

        #region Operation, Response and Event De/Serialization

        internal static void SerializeOperationRequest(MemoryStream memStream, OperationRequest serObject, bool setType)
        {
            SerializeOperationRequest(memStream, serObject.OperationCode, serObject.Parameters, setType);
        }

        internal static void SerializeOperationRequest(MemoryStream memStream, byte operationCode, Dictionary<byte, object> parameters, bool setType)
        {
            if (setType)
            {
                memStream.WriteByte((byte)GpType.OperationRequest);
            }

            // write operation and number of paramters
            memStream.WriteByte(operationCode);

            SerializeParameterTable(memStream, parameters);
        }

        internal static OperationRequest DeserializeOperationRequest(MemoryStream din)
        {
            OperationRequest request = new OperationRequest();
            request.OperationCode = DeserializeByte(din);
            request.Parameters = DeserializeParameterTable(din);

            return request;
        }

        internal static void SerializeOperationResponse(MemoryStream memStream, OperationResponse serObject, bool setType)
        {
            if (setType)
            {
                memStream.WriteByte((byte)GpType.OperationResponse);
            }

            // write operation code and return code
            memStream.WriteByte((byte)serObject.OperationCode);
            SerializeShort(memStream, (short)serObject.ReturnCode, false);

            // debug message might be null
            if (string.IsNullOrEmpty(serObject.DebugMessage))
            {
                memStream.WriteByte((byte)GpType.Null);
            }
            else
            {
                SerializeString(memStream, serObject.DebugMessage, false);
            }

            SerializeParameterTable(memStream, serObject.Parameters);
        }

        internal static OperationResponse DeserializeOperationResponse(MemoryStream memoryStream)
        {
            OperationResponse response = new OperationResponse();
            response.OperationCode = DeserializeByte(memoryStream);
            response.ReturnCode = DeserializeShort(memoryStream);
            response.DebugMessage = Deserialize(memoryStream, DeserializeByte(memoryStream)) as string;
            response.Parameters = DeserializeParameterTable(memoryStream);

            return response;
        }

        internal static void SerializeEventData(MemoryStream memStream, EventData serObject, bool setType)
        {
            if (setType)
            {
                memStream.WriteByte((byte)GpType.EventData);
            }

            memStream.WriteByte((byte)serObject.Code);

            SerializeParameterTable(memStream, serObject.Parameters);
        }

        internal static EventData DeserializeEventData(MemoryStream din)
        {
            EventData result = new EventData();
            result.Code = DeserializeByte(din);
            result.Parameters = DeserializeParameterTable(din);

            return result;
        }

        private static void SerializeParameterTable(MemoryStream memStream, Dictionary<byte, object> parameters)
        {
            // allow simple operation calls without any parameters
            if (parameters == null || parameters.Count == 0)
            {
                SerializeShort(memStream, (short)0, false);
                return;
            }

            // Start of actual data: parameter-count and parameters
            SerializeShort(memStream, (short)parameters.Count, false);

            // iterate over all parameters
            foreach (KeyValuePair<byte, object> pair in parameters)
            {
                // write key (always byte currently) and value (any type)
                memStream.WriteByte((byte)pair.Key);
                Serialize(memStream, pair.Value, true); // NOTE protocol used 1.5 here (for Photon)
            }
        }

        private static Dictionary<byte, object> DeserializeParameterTable(MemoryStream memoryStream)
        {
            // number of return values and some object to save return value
            short numRetVals = DeserializeShort(memoryStream);

            Dictionary<byte, object> retVals = new Dictionary<byte, object>(numRetVals);
            object valueObject;
            byte keyByteCode;

            // iterate over all return values
            for (int i = 0; i < numRetVals; i++)
            {
                // read key of parameter (always a byte)
                keyByteCode = (byte) memoryStream.ReadByte();

                // read value-type and value (in one go. types are encoded as single byte)
                valueObject = Deserialize(memoryStream, (byte) memoryStream.ReadByte());

                // add return value
                retVals[(byte) keyByteCode] = valueObject;
            }

            return retVals;
        }

        #endregion

        #region Serialize Types

        /// <summary>
        /// Calls the correct serialization method for the passed object.
        /// </summary>
        private static void Serialize(MemoryStream dout, object serObject, bool setType)
        {
            // new type: Null
            if (serObject == null)
            {
                if (setType)
                {
                    dout.WriteByte((byte)'*');
                }

                return;
            }

            GpType typeCode = GetCodeOfType(serObject.GetType());// this is not supported by Win8RT (api for store apps)
            switch (typeCode)
            {
                case GpType.Byte:
                    SerializeByte(dout, (byte)serObject, setType);
                    return;
                case GpType.String:
                    SerializeString(dout, (string)serObject, setType);
                    return;
                case GpType.Boolean:
                    SerializeBoolean(dout, (bool)serObject, setType);
                    return;
                case GpType.Short:
                    SerializeShort(dout, (short)serObject, setType);
                    return;
                case GpType.Integer:
                    SerializeInteger(dout, (int)serObject, setType);
                    return;
                case GpType.Long:
                    SerializeLong(dout, (long)serObject, setType);
                    return;
                case GpType.Float:
                    SerializeFloat(dout, (float)serObject, setType);
                    return;
                case GpType.Double:
                    SerializeDouble(dout, (double)serObject, setType);
                    return;
                case GpType.Hashtable:
                    SerializeHashTable(dout, (Hashtable)serObject, setType);
                    break;
                case GpType.ByteArray:
                    SerializeByteArray(dout, (byte[])serObject, setType);
                    break;
                case GpType.Array:
                    if (serObject is int[])
                    {
                        SerializeIntArrayOptimized(dout, (int[]) serObject, setType);
                    }
                    else if (serObject.GetType().GetElementType() == typeof (object))
                    {
                        SerializeObjectArray(dout, serObject as object[], setType);
                    }
                    else
                    {
                        SerializeArray(dout, (Array) serObject, setType);
                    }
                    break;
                case GpType.Dictionary:
                    SerializeDictionary(dout, (IDictionary)serObject, setType);
                    break;
                case GpType.EventData:
                    SerializeEventData(dout, (EventData)serObject, setType);
                    break;
                case GpType.OperationResponse:
                    SerializeOperationResponse(dout, (OperationResponse)serObject, setType);
                    break;
                case GpType.OperationRequest:
                    SerializeOperationRequest(dout, (OperationRequest)serObject, setType);
                    break;

                default:
                    if (!SerializeCustom(dout, serObject))
                    {
                        throw new Exception("cannot serialize(): " + serObject.GetType());
                    }
                    break;
            }
        }

        // object-array is non-strict typed -> each element can have another type and must write the code
        private static void SerializeByte(MemoryStream dout, Byte serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'b');
            }

            dout.WriteByte((byte)serObject);
        }

        private static void SerializeBoolean(MemoryStream dout, Boolean serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'o');
            }

            dout.WriteByte((serObject) ? (byte)1 : (byte)0);
        }


        static readonly byte[] memShort = new byte[2];
        private static void SerializeShort(MemoryStream dout, Int16 serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'k');
            }

            // due to shifting, no IsLittleEndian-check is needed!
            lock (memShort)
            {
                byte[] temp = memShort;
                temp[0] = (byte) (serObject >> 8);
                temp[1] = (byte) (serObject >> 0);

                dout.Write(temp, 0, 2);
            }
        }

        /// <summary>
        /// Serializes a short typed value into a byte-array (target) starting at the also given targetOffset.
        /// The altered offset is known to the caller, because it is given via a referenced parameter.
        /// </summary>
        /// <param name="value">The short value to be serialized</param>
        /// <param name="target">The byte-array to serialize the short to</param>
        /// <param name="targetOffset">The offset in the byte-array</param>
        public static void Serialize(short value, byte[] target, ref int targetOffset)
        {
            target[targetOffset++] = (byte)(value >> 8);
            target[targetOffset++] = (byte)(value >> 0);
        }

        private static void SerializeInteger(MemoryStream dout, Int32 serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'i');
            }

            lock (memInteger)
            {
                byte[] buff = memInteger;

                // due to shifting, no IsLittleEndian-check is needed!
                buff[0] = (byte) (serObject >> 24);
                buff[1] = (byte) (serObject >> 16);
                buff[2] = (byte) (serObject >> 8);
                buff[3] = (byte) (serObject >> 0);

                dout.Write(buff, 0 , 4);
            }
        }

        /// <summary>
        /// Serializes an int typed value into a byte-array (target) starting at the also given targetOffset.
        /// The altered offset is known to the caller, because it is given via a referenced parameter.
        /// </summary>
        /// <param name="value">The int value to be serialized</param>
        /// <param name="target">The byte-array to serialize the short to</param>
        /// <param name="targetOffset">The offset in the byte-array</param>
        public static void Serialize(int value, byte[] target, ref int targetOffset)
        {
            // due to shifting, no IsLittleEndian-check is needed!
            target[targetOffset++] = (byte)(value >> 24);
            target[targetOffset++] = (byte)(value >> 16);
            target[targetOffset++] = (byte)(value >> 8);
            target[targetOffset++] = (byte)(value >> 0);
        }

        static readonly long[] memLongBlock = new long[1];
        static readonly byte[] memLongBlockBytes = new byte[8];
        private static void SerializeLong(MemoryStream dout, Int64 serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'l');
            }

            lock (memLongBlock)
            {
                memLongBlock[0] = serObject;
                Buffer.BlockCopy(memLongBlock, 0, memLongBlockBytes, 0, 8);
                byte[] data = memLongBlockBytes;

                if (BitConverter.IsLittleEndian)
                {
                    byte temp0 = data[0];
                    byte temp1 = data[1];
                    byte temp2 = data[2];
                    byte temp3 = data[3];
                    data[0] = data[7];
                    data[1] = data[6];
                    data[2] = data[5];
                    data[3] = data[4];
                    data[4] = temp3;
                    data[5] = temp2;
                    data[6] = temp1;
                    data[7] = temp0;
                }

                dout.Write(data, 0, 8);
            }
        }

        static readonly float[] memFloatBlock = new float[1];
        static readonly byte[] memFloatBlockBytes = new byte[4];
        private static void SerializeFloat(MemoryStream dout, float serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'f');
            }

            lock (memFloatBlockBytes)
            {
                memFloatBlock[0] = serObject;
                Buffer.BlockCopy(memFloatBlock, 0, memFloatBlockBytes, 0, 4);
                //byte[] data = memFloatBlockBytes;

                if (BitConverter.IsLittleEndian)
                {
                    byte temp0 = memFloatBlockBytes[0];
                    byte temp1 = memFloatBlockBytes[1];
                    memFloatBlockBytes[0] = memFloatBlockBytes[3];
                    memFloatBlockBytes[1] = memFloatBlockBytes[2];
                    memFloatBlockBytes[2] = temp1;
                    memFloatBlockBytes[3] = temp0;
                }

                dout.Write(memFloatBlockBytes, 0, 4);
            }
        }

        /// <summary>
        /// Serializes an float typed value into a byte-array (target) starting at the also given targetOffset.
        /// The altered offset is known to the caller, because it is given via a referenced parameter.
        /// </summary>
        /// <param name="value">The float value to be serialized</param>
        /// <param name="target">The byte-array to serialize the short to</param>
        /// <param name="targetOffset">The offset in the byte-array</param>
        public static void Serialize(float value, byte[] target, ref int targetOffset)
        {
            lock (memFloatBlock)
            {
                memFloatBlock[0] = value;
                Buffer.BlockCopy(memFloatBlock, 0, target, targetOffset, 4);
            }

            if (BitConverter.IsLittleEndian)
            {
                byte temp0 = target[targetOffset];
                byte temp1 = target[targetOffset+1];

                target[targetOffset+0] = target[targetOffset+3];
                target[targetOffset+1] = target[targetOffset+2];
                target[targetOffset+2] = temp1;
                target[targetOffset+3] = temp0;
            }

            targetOffset += 4;
        }


        static readonly double[] memDoubleBlock = new double[1];
        static readonly byte[] memDoubleBlockBytes = new byte[8];
        private static void SerializeDouble(MemoryStream dout, double serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'d');
            }


            lock (memDoubleBlockBytes)
            {
                memDoubleBlock[0] = serObject;
                Buffer.BlockCopy(memDoubleBlock, 0, memDoubleBlockBytes, 0, 8);
                byte[] data = memDoubleBlockBytes;

                if (BitConverter.IsLittleEndian)
                {
                    //Array.Reverse(data);

                    byte temp0 = data[0];
                    byte temp1 = data[1];
                    byte temp2 = data[2];
                    byte temp3 = data[3];
                    data[0] = data[7];
                    data[1] = data[6];
                    data[2] = data[5];
                    data[3] = data[4];
                    data[4] = temp3;
                    data[5] = temp2;
                    data[6] = temp1;
                    data[7] = temp0;
                }

                dout.Write(data, 0, 8);
            }
        }

        private static void SerializeString(MemoryStream dout, String serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'s');
            }

            byte[] Write = Encoding.UTF8.GetBytes(serObject);

            if (Write.Length > short.MaxValue)
            {
                throw new NotSupportedException("Strings that exceed a UTF8-encoded byte-length of 32767 (short.MaxValue) are not supported. Yours is: " + Write.Length);
            }

            SerializeShort(dout, (short)Write.Length, false);
            dout.Write(Write, 0, Write.Length);
        }

        private static void SerializeArray(MemoryStream dout, Array serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'y');
            }

            if (serObject.Length > short.MaxValue)
            {
                throw new NotSupportedException("String[] that exceed 32767 (short.MaxValue) entries are not supported. Yours is: " + serObject.Length);
            }

            SerializeShort(dout, (short)serObject.Length, false);

            // find out the type of the elements. it's 0 if the type is not a built-in one
            Type elementType = serObject.GetType().GetElementType();
            GpType contentTypeCode = GetCodeOfType(elementType);
            if (contentTypeCode != GpType.Unknown)
            {
                // the content's type is always written, even for 0 elements
                dout.WriteByte((byte)contentTypeCode);

                if (contentTypeCode == GpType.Dictionary)
                {
                    // special handling for dictionaries
                    bool setKeyType;
                    bool setValueType;
                    SerializeDictionaryHeader(dout, serObject, out setKeyType, out setValueType);

                    for (int index = 0; index < serObject.Length; index++)
                    {
                        object element = serObject.GetValue(index);
                        SerializeDictionaryElements(dout, element, setKeyType, setValueType);
                    }
                }
                else
                {
                    for (int index = 0; index < serObject.Length; index++)
                    {
                        object o = serObject.GetValue(index);
                        Serialize(dout, o, false);
                    }
                }
            }
            else
            {
                // try to find a custom type code for this type of object and if found, use it
                CustomType customType;
                if (TypeDict.TryGetValue(elementType, out customType))
                {
                    dout.WriteByte((byte)'c');
                    dout.WriteByte(customType.Code);

                    for (int index = 0; index < serObject.Length; index++)
                    {
                        object obj = serObject.GetValue(index);

                        if (customType.SerializeStreamFunction == null)
                        {
                            byte[] bytesOfCustomType = customType.SerializeFunction(obj);

                            SerializeShort(dout, (short)bytesOfCustomType.Length, false);
                            dout.Write(bytesOfCustomType, 0, bytesOfCustomType.Length);
                        }
                        else
                        {
                            long posOfLengthInfo = dout.Position;
                            dout.Position = dout.Position + 2;

                            short serializedLength = customType.SerializeStreamFunction(dout, obj);
                            long newPos = dout.Position;
                            dout.Position = posOfLengthInfo;
                            SerializeShort(dout, (short)serializedLength, false);
                            dout.Position = dout.Position + serializedLength;

                            if (dout.Position != newPos)
                            {
                                throw new Exception("Serialization failed. Stream position corrupted. Should be " + newPos + " is now: " + dout.Position + " serializedLength: " + serializedLength);
                            }
                        }
                    }
                }
                else
                {
                    // not serializable content in array
                    throw new NotSupportedException("cannot serialize array of type " + elementType);
                }
            }
        }

        private static void SerializeByteArray(MemoryStream dout, byte[] serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'x');
            }

            SerializeInteger(dout, serObject.Length, false);
            dout.Write(serObject, 0, serObject.Length);
        }

        private static void SerializeIntArrayOptimized(MemoryStream inWriter, int[] serObject, bool setType)
        {
            if (setType)
            {
                inWriter.WriteByte((byte)'y');
            }

            // like all arrays (except byte[]) this is limited to short.Max entries
            SerializeShort(inWriter, (short)serObject.Length, false);
            inWriter.WriteByte((byte)'i');

            // this is a optimized serialization that should be much faster than writing individual ints but it eats some memory
            byte[] temp = new byte[serObject.Length * 4];
            int x = 0;

            for (int i = 0; i < serObject.Length; i++)
            {
                // due to shifting, no IsLittleEndian-check is needed!
                temp[x++] = (byte)(serObject[i] >> 24);
                temp[x++] = (byte)(serObject[i] >> 16);
                temp[x++] = (byte)(serObject[i] >> 8);
                temp[x++] = (byte)(serObject[i] >> 0);
            }

            inWriter.Write(temp, 0, temp.Length);
        }

        private static void SerializeStringArray(MemoryStream dout, String[] serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'a');
            }

            SerializeShort(dout, (short)serObject.Length, false);

            for (int i = 0; i < serObject.Length; i++)
            {
                SerializeString(dout, serObject[i], false);
            }
        }

        private static void SerializeObjectArray(MemoryStream dout, object[] objects, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'z');
            }

            SerializeShort(dout, (short)objects.Length, false);
            for (int index = 0; index < objects.Length; index++)
            {
                object obj = objects[index];
                Serialize(dout, obj, true);
            }
        }

        private static void SerializeHashTable(MemoryStream dout, Hashtable serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'h');
            }

            SerializeShort(dout, (short)serObject.Count, false);

            foreach (DictionaryEntry entry in serObject)
            {
                Serialize(dout, entry.Key, true);
                Serialize(dout, entry.Value, true);
            }
        }

        private static void SerializeDictionary(MemoryStream dout, IDictionary serObject, bool setType)
        {
            if (setType)
            {
                dout.WriteByte((byte)'D');
            }

            bool setKeyType;
            bool setValueType;
            SerializeDictionaryHeader(dout, serObject, out setKeyType, out setValueType);
            SerializeDictionaryElements(dout, serObject, setKeyType, setValueType);
        }

        private static void SerializeDictionaryHeader(MemoryStream writer, Type dictType)
        {
            bool setKeyType;
            bool setValueType;
            SerializeDictionaryHeader(writer, dictType, out setKeyType, out setValueType);
        }

        private static void SerializeDictionaryHeader(MemoryStream writer, object dict, out bool setKeyType, out bool setValueType)
        {
#if NETFX_CORE
            Type[] types = dict.GetType().GenericTypeArguments;
#else
            Type[] types = dict.GetType().GetGenericArguments();
#endif
            setKeyType = types[0] == typeof(object);
            setValueType = types[1] == typeof(object);

            if (setKeyType)
            {
                writer.WriteByte((byte)GpType.Unknown);
            }
            else
            {
                GpType keyType = (GpType)GetCodeOfType(types[0]);
                if (keyType == GpType.Unknown || keyType == GpType.Dictionary)
                {
                    throw new Exception("Unexpected - cannot serialize Dictionary with key type: " + types[0]);
                }

                writer.WriteByte((byte)keyType);
            }

            if (setValueType)
            {
                writer.WriteByte((byte)GpType.Unknown);
            }
            else
            {
                GpType valueType = (GpType)GetCodeOfType(types[1]);
                if (valueType == GpType.Unknown)
                {
                    throw new Exception("Unexpected - cannot serialize Dictionary with value type: " + types[0]);
                }

                writer.WriteByte((byte)valueType);

                if (valueType == GpType.Dictionary)
                {
                    SerializeDictionaryHeader(writer, types[1]);
                }
            }
        }

        private static void SerializeDictionaryElements(MemoryStream writer, object dict, bool setKeyType, bool setValueType)
        {
            var d = (IDictionary)dict;
            SerializeShort(writer, (short)d.Count, false);

            foreach (DictionaryEntry entry in d)
            {
                if (!setValueType && entry.Value == null)
                {
                    throw new Exception("Can't serialize null in Dictionary with specific value-type.");
                }
                if (!setKeyType && entry.Key == null)
                {
                    throw new Exception("Can't serialize null in Dictionary with specific key-type.");
                }
                Serialize(writer, entry.Key, setKeyType);
                Serialize(writer, entry.Value, setValueType);
            }
        }

        #endregion

        #region Deserialize Types

        private static object Deserialize(MemoryStream din, byte type)
        {
            switch (type)
            {
                case (byte)'i':
                    return DeserializeInteger(din);

                case (byte)'s':
                    return DeserializeString(din);

                case (byte)'a':
                    return DeserializeStringArray(din);

                case (byte)'x':
                    return DeserializeByteArray(din);

                case (byte)'n':
                    return DeserializeIntArray(din);

                case (byte)'h':
                    return DeserializeHashTable(din);

                case (byte)'D':
                    return DeserializeDictionary(din);

                case (byte)'o':
                    return DeserializeBoolean(din);

                case (byte)'k':
                    return DeserializeShort(din);

                case (byte)'l':
                    return DeserializeLong(din);

                case (byte)'b':
                    return DeserializeByte(din);

                case (byte)'f':
                    return DeserializeFloat(din);

                case (byte)'d':
                    return DeserializeDouble(din);

                case (byte)'y':
                    return DeserializeArray(din);

                case (byte)'c':
                    byte typeCode = (byte)din.ReadByte();
                    return DeserializeCustom(din, typeCode);

                case (byte)'z':
                    return DeserializeObjectArray(din);

                case (byte)'e':
                    return DeserializeEventData(din);

                case (byte)'q':
                    return DeserializeOperationRequest(din);

                case (byte)'p':
                    return DeserializeOperationResponse(din);

                case (byte)'*':
                case (byte)0:
                    return null;

                default:
                    Debug.WriteLine("missing type: " + type);
                    throw new Exception("deserialize(): " + type);
            }
        }

        private static byte DeserializeByte(MemoryStream din)
        {
            return (byte)din.ReadByte();
        }

        private static bool DeserializeBoolean(MemoryStream din)
        {
            return din.ReadByte() != 0; // note: ReadByte might return -1 if stream ended!
        }


        private static short DeserializeShort(MemoryStream din)
        {
            lock (memShort)
            {
                byte[] data = memShort;
                din.Read(data, 0, 2);
                return (short) (data[0] << 8 | data[1] << 0);
            }
        }

        /// <summary>
        /// Deserialize fills the given short typed value with the given byte-array (source) starting at the also given offset.
        /// The result is placed in a variable (value). There is no need to return a value because the parameter value is given by reference.
        /// The altered offset is this way also known to the caller.
        /// </summary>
        /// <param name="value">The short value to deserialized into</param>
        /// <param name="source">The byte-array to deserialize from</param>
        /// <param name="offset">The offset in the byte-array</param>
        public static void Deserialize(out short value, byte[] source, ref int offset)
        {
            value = (short)(source[offset++] << 8 | source[offset++] << 0);
        }

        private static readonly byte[] memInteger = new byte[4];
        /// <summary>
        /// DeserializeInteger returns an Integer typed value from the given Memorystream.
        /// </summary>
        private static int DeserializeInteger(MemoryStream din)
        {
            lock (memInteger)
            {
                byte[] data = memInteger;
                din.Read(data, 0, 4);

                return (data[0] << 24) | (data[1] << 16) | (data[2] << 8) | (data[3] << 0);
            }
        }

        /// <summary>
        /// Deserialize fills the given int typed value with the given byte-array (source) starting at the also given offset.
        /// The result is placed in a variable (value). There is no need to return a value because the parameter value is given by reference.
        /// The altered offset is this way also known to the caller.
        /// </summary>
        /// <param name="value">The int value to deserialize into</param>
        /// <param name="source">The byte-array to deserialize from</param>
        /// <param name="offset">The offset in the byte-array</param>
        public static void Deserialize(out int value, byte[] source, ref int offset)
        {
            value = (source[offset++] << 24) | (source[offset++] << 16) | (source[offset++] << 8) | (source[offset++] << 0);
        }

        private static readonly byte[] memLong = new byte[8];
        private static long DeserializeLong(MemoryStream din)
        {
            lock (memLong)
            {
                byte[] data = memLong;
                din.Read(data, 0, 8);

                if (BitConverter.IsLittleEndian)
                {
                return ((long)data[0] << 56) | ((long)data[1] << 48) | ((long)data[2] << 40) | ((long)data[3] << 32) |
                       ((long)data[4] << 24) | ((long)data[5] << 16) | ((long)data[6] << 8) | data[7];
                }
                else
                {
                    return BitConverter.ToInt64(data, 0);
                }
            }
        }

        private static readonly byte[] memFloat = new byte[4];
        private static float DeserializeFloat(MemoryStream din)
        {
            lock (memFloat)
            {
                byte[] data = memFloat;
                din.Read(data, 0, 4);

                if (BitConverter.IsLittleEndian)
                {
                    byte temp0 = data[0];
                    byte temp1 = data[1];
                    data[0] = data[3];
                    data[1] = data[2];
                    data[2] = temp1;
                    data[3] = temp0;
                }

                return BitConverter.ToSingle(data, 0);
            }
        }


        private static readonly byte[] memDeserialize = new byte[4];
        /// <summary>
        /// Deserialize fills the given float typed value with the given byte-array (source) starting at the also given offset.
        /// The result is placed in a variable (value). There is no need to return a value because the parameter value is given by reference.
        /// The altered offset is this way also known to the caller.
        /// </summary>
        /// <param name="value">The float value to deserialize</param>
        /// <param name="source">The byte-array to deserialize from</param>
        /// <param name="offset">The offset in the byte-array</param>
        public static void Deserialize(out float value, byte[] source, ref int offset)
        {
            if (BitConverter.IsLittleEndian)
            {
                lock (memDeserialize)
                {
                    byte[] data = memDeserialize;

                    data[3] = source[offset++];
                    data[2] = source[offset++];
                    data[1] = source[offset++];
                    data[0] = source[offset++];

                    value = BitConverter.ToSingle(data, 0);
                }
            }
            else
            {
                value = BitConverter.ToSingle(source, offset);
                offset += 4;
            }
        }

        private static readonly byte[] memDouble = new byte[8];

        private static double DeserializeDouble(MemoryStream din)
        {
            lock (memDouble)
            {
                byte[] data = memDouble;
                din.Read(data, 0, 8);

                if (BitConverter.IsLittleEndian)
                {
                    //Array.Reverse(data);

                    byte temp0 = data[0];
                    byte temp1 = data[1];
                    byte temp2 = data[2];
                    byte temp3 = data[3];
                    data[0] = data[7];
                    data[1] = data[6];
                    data[2] = data[5];
                    data[3] = data[4];
                    data[4] = temp3;
                    data[5] = temp2;
                    data[6] = temp1;
                    data[7] = temp0;
                }

                return BitConverter.ToDouble(data, 0);
            }
        }

        private static String DeserializeString(MemoryStream din)
        {
            short length = DeserializeShort(din);
            if (length == 0)
                return "";

            byte[] Read = new byte[length];
            din.Read(Read, 0, Read.Length);
            return Encoding.UTF8.GetString(Read, 0, Read.Length);
        }

        private static Array DeserializeArray(MemoryStream din)
        {
            // read length (type: short)
            short arrayLength = DeserializeShort(din);
            byte valuesType = (byte)din.ReadByte();

            Array resultArray;
            if (valuesType == 'y')
            {
                // array in array
                Array innerArray = DeserializeArray(din);
                Type elementType = innerArray.GetType();
                resultArray = Array.CreateInstance(elementType, arrayLength);
                resultArray.SetValue(innerArray, 0);

                for (short i = 1; i < arrayLength; i++)
                {
                    innerArray = DeserializeArray(din);
                    resultArray.SetValue(innerArray, i);
                }
            }
            else if (valuesType == 'x')
            {
                // byte-array in array
                Array innerArray;
                resultArray = Array.CreateInstance(typeof(byte[]), arrayLength);

                for (short i = 0; i < arrayLength; i++)
                {
                    innerArray = DeserializeByteArray(din);
                    resultArray.SetValue(innerArray, i);
                }
            }
            else if (valuesType == 'c')
            {
                byte customTypeCode = (byte)din.ReadByte();
                CustomType customType;
                if (CodeDict.TryGetValue(customTypeCode, out customType))
                {
                    resultArray = Array.CreateInstance(customType.Type, arrayLength);

                    for (int i = 0; i < arrayLength; i++)
                    {
                        short objLength = DeserializeShort(din);


                        if (customType.DeserializeStreamFunction == null)
                        {
                            byte[] bytes = new byte[objLength];
                            din.Read(bytes, 0, objLength);
                            resultArray.SetValue(customType.DeserializeFunction(bytes), i);
                        }
                        else
                        {
                            resultArray.SetValue(customType.DeserializeStreamFunction(din, objLength), i);
                        }
                    }
                }
                else
                {
                    throw new Exception("Cannot find deserializer for custom type: " + customTypeCode);
                }
            }
            else if (valuesType == 'D')
            {
                // special handling for dictionaries
                Array result = null;
                DeserializeDictionaryArray(din, arrayLength, out result);
                return result;
            }
            else
            {
                resultArray = CreateArrayByType(valuesType, arrayLength);

                // read each value
                for (short i = 0; i < arrayLength; i++)
                {
                    resultArray.SetValue(Deserialize(din, valuesType), i);
                }
            }

            return resultArray;
        }

        private static byte[] DeserializeByteArray(MemoryStream din)
        {
            int size = DeserializeInteger(din);
            byte[] retVal = new byte[size];
            din.Read(retVal, 0, size);

            return retVal;
        }

        private static int[] DeserializeIntArray(MemoryStream din)
        {
            int size = DeserializeInteger(din);

            int[] retVal = new int[size];
            for (int i = 0; i < size; i++)
                retVal[i] = DeserializeInteger(din);

            return retVal;
        }

        private static String[] DeserializeStringArray(MemoryStream din)
        {
            int size = DeserializeShort(din);
            String[] val = new String[size];

            for (int i = 0; i < size; i++)
            {
                val[i] = DeserializeString(din);
            }

            return val;
        }

        private static object[] DeserializeObjectArray(MemoryStream din)
        {
            short arrayLength = DeserializeShort(din);
            object[] resultArray = new object[arrayLength];

            for (int i = 0; i < arrayLength; i++)
            {
                byte typeCode = (byte)din.ReadByte();
                resultArray[i] = Deserialize(din, typeCode);
                //resultArray.SetValue(Deserialize(din, typeCode), i);  // might be needed
            }

            return resultArray;
        }

        private static Hashtable DeserializeHashTable(MemoryStream din)
        {
            int size = DeserializeShort(din);
            Hashtable value = new Hashtable(size);

            for (int i = 0; i < size; i++)
            {
                object serKey = Deserialize(din, (byte)din.ReadByte());
                object serValue = Deserialize(din, (byte)din.ReadByte());

                value[serKey] = serValue;
            }

            return value;
        }

        private static IDictionary DeserializeDictionary(MemoryStream din)
        {
            byte keyType = (byte)din.ReadByte();
            byte valType = (byte)din.ReadByte();
            int size = DeserializeShort(din);

            bool readKeyType = (keyType == (byte)0 || keyType == (byte)'*');
            bool readValType = (valType == (byte)0 || valType == (byte)'*');

            Type k = Protocol.GetTypeOfCode(keyType);
            Type v = Protocol.GetTypeOfCode(valType);

            Type dict = typeof(Dictionary<,>).MakeGenericType(new Type[] { k, v });
            IDictionary value = Activator.CreateInstance(dict) as IDictionary;

            for (int i = 0; i < size; i++)
            {
                object serKey = Deserialize(din, readKeyType ? (byte)din.ReadByte() : keyType);
                object serValue = Deserialize(din, readValType ? (byte)din.ReadByte() : valType);

                value.Add(serKey, serValue);    // TODO: check if value[key] = value might be faster or use less mem
            }

            return value;
        }

        private static bool DeserializeDictionaryArray(MemoryStream din, short size, out Array arrayResult)
        {
            byte keyTypeCode;
            byte valTypeCode;
            var dictType = DeserializeDictionaryType(din, out keyTypeCode, out valTypeCode);

            arrayResult = Array.CreateInstance(dictType, size);
            for (short i = 0; i < size; i++)
            {
                var dict = Activator.CreateInstance((Type)dictType) as IDictionary;
                if (dict == null)
                {
                    return false;
                }

                var dictSize = DeserializeShort(din);

                for (int j = 0; j < dictSize; j++)
                {
                    object key;
                    if (keyTypeCode != 0)
                    {
                        key = Deserialize(din, keyTypeCode);
                    }
                    else
                    {
                        byte type = (byte)din.ReadByte();
                        key = Deserialize(din, type);
                    }

                    object value;
                    if (valTypeCode != 0)
                    {
                        value = Deserialize(din, valTypeCode);
                    }
                    else
                    {
                        byte type = (byte)din.ReadByte();
                        value = Deserialize(din, type);
                    }

                    dict.Add(key, value);
                }

                arrayResult.SetValue(dict, i);
            }

            return true;
        }

        private static Type DeserializeDictionaryType(MemoryStream reader, out byte keyTypeCode, out byte valTypeCode)
        {
            keyTypeCode = (byte)reader.ReadByte();
            valTypeCode = (byte)reader.ReadByte();
            var keyType = (GpType)keyTypeCode;
            var valueType = (GpType)valTypeCode;

            Type keyClrType;

            if (keyType == GpType.Unknown)
            {
                keyClrType = typeof(object);
            }
            else
            {
                keyClrType = GetTypeOfCode(keyTypeCode);
            }

            Type valueClrType;

            if (valueType == GpType.Unknown)
            {
                valueClrType = typeof(object);
            }
            else
            {
                valueClrType = GetTypeOfCode(valTypeCode);
            }

            return typeof(Dictionary<,>).MakeGenericType(new[] { keyClrType, valueClrType });
        }

        #endregion
    } // class Protocol
}