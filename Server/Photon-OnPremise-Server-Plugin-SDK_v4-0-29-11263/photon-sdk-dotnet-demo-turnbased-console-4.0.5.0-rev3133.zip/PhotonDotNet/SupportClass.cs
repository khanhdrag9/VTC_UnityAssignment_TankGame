// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SupportClass.cs" company="Exit Games GmbH">
//   Exit Games GmbH 2012
// </copyright>
// <summary>
//   Contains several (more or less) useful static methods, mostly used for debugging.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ExitGames.Client.Photon
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Text;
    using System.Threading;

    /// <summary>
    /// Contains several (more or less) useful static methods, mostly used for debugging.
    /// </summary>
    public class SupportClass
    {
        public static uint CalculateCrc(byte[] buffer, int length)
        {
            uint crc = 0xFFFFFFFF;
            uint poly = 0xEDB88320;
            byte current = 0;
            for (int bufferIndex = 0; bufferIndex < length; bufferIndex++)
            {
                current = buffer[bufferIndex];
                crc = crc ^ current;
                for (int i = 0; i < 8; i++)
                {
                    if ((crc & 1) != 0)
                        crc = (crc >> 1) ^ poly;
                    else
                        crc >>= 1;
                }
            }

            return crc;
        }

        public static List<MethodInfo> GetMethods(Type type, Type attribute)
        {
            List<MethodInfo> fittingMethods = new List<MethodInfo>();

            if (type == null)
            {
                return fittingMethods;
            }

            //IEnumerable<MethodInfo> declaredMethods = type.GetTypeInfo().DeclaredMethods;
            MethodInfo[] declaredMethods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (MethodInfo methodInfo in declaredMethods)
            {
                if (attribute == null || methodInfo.IsDefined(attribute, false))
                {
                    fittingMethods.Add(methodInfo);
                }
            }

            return fittingMethods;
        }

        public delegate int IntegerMillisecondsDelegate();

        internal protected static IntegerMillisecondsDelegate IntegerMilliseconds = () => (int)(Environment.TickCount);

        /// <summary>
        /// Gets the local machine's "milliseconds since start" value (precision is described in remarks).
        /// </summary>
        /// <remarks>
        /// This method uses Environment.TickCount (cheap but with only 16ms precision).
        /// PhotonPeer.LocalMsTimestampDelegate is available to set the delegate (unless already connected).
        /// </remarks>
        /// <returns>Fraction of the current time in Milliseconds (this is not a proper datetime timestamp).</returns>
        public static int GetTickCount()
        {
            return IntegerMilliseconds();
        }

        /// <summary>
        /// Creates a background thread that calls the passed function in 100ms intervals, as long as that returns true.
        /// </summary>
        /// <param name="myThread"></param>
        public static void CallInBackground(Func<bool> myThread)
        {
            CallInBackground(myThread, 100);
        }

        /// <summary>
        /// Creates a background thread that calls the passed function in 100ms intervals, as long as that returns true.
        /// </summary>
        /// <param name="myThread"></param>
        /// <param name="millisecondsInterval">Milliseconds to sleep between calls of myThread.</param>
        public static void CallInBackground(Func<bool> myThread, int millisecondsInterval)
        {
            Thread x = new Thread(() => { while (myThread()) { Thread.Sleep(millisecondsInterval); } });
            x.IsBackground = true;
            x.Start();
        }

        /// <summary>
        /// Writes the exception's stack trace to the received stream.
        /// </summary>
        /// <param name="throwable">Exception to obtain information from.</param>
        /// <param name="stream">Output sream used to write to.</param>
        public static void WriteStackTrace(System.Exception throwable, System.IO.TextWriter stream)
        {
            if (stream != null)
            {
                stream.WriteLine(throwable.ToString());
                stream.WriteLine(throwable.StackTrace);
                stream.Flush();
            }
            else
            {
                System.Diagnostics.Debug.WriteLine(throwable.ToString());
                System.Diagnostics.Debug.WriteLine(throwable.StackTrace);
                //System.Diagnostics.Debug.Flush();
            }
        }

        /// <summary>
        /// Writes the exception's stack trace to the received stream. Writes to: System.Diagnostics.Debug.
        /// </summary>
        /// <param name="throwable">Exception to obtain information from.</param>
		public static void WriteStackTrace(System.Exception throwable)
		{
			SupportClass.WriteStackTrace(throwable, null);
		}

        /// <summary>
        /// This method returns a string, representing the content of the given IDictionary.
        /// Returns "null" if parameter is null.
        /// </summary>
        /// <param name="dictionary">
        /// IDictionary to return as string.
        /// </param>
        /// <returns>
        /// The string representation of keys and values in IDictionary.
        /// </returns>
        public static string DictionaryToString(IDictionary dictionary)
        {
            return DictionaryToString(dictionary, true);
        }

        /// <summary>
        /// This method returns a string, representing the content of the given IDictionary.
        /// Returns "null" if parameter is null.
        /// </summary>
        /// <param name="dictionary">IDictionary to return as string.</param>
        /// <param name="includeTypes"> </param>
        public static string DictionaryToString(IDictionary dictionary, bool includeTypes)
        {
            if (dictionary == null)
            {
                return "null";
            }

            StringBuilder sb = new StringBuilder();
            sb.Append("{");

            Type valueType;
            string value;

            foreach (object key in dictionary.Keys)
            {
                if (sb.Length > 1)
                {
                    sb.Append(", ");
                }

                if (dictionary[key] == null)
                {
                    valueType = typeof(System.Object);
                    value = "null";
                }
                else
                {
                    valueType = dictionary[key].GetType();
                    value = dictionary[key].ToString();
                }

                if (typeof(IDictionary) == valueType || typeof(Hashtable) == valueType)
                {
                    value = DictionaryToString((IDictionary)dictionary[key]);
                }

                if (typeof(string[]) == valueType)
                {
                    value = string.Format("{{{0}}}", string.Join(",", (string[])dictionary[key]));
                }

                if (includeTypes)
                {
                    sb.AppendFormat("({0}){1}=({2}){3}", key.GetType().Name, key, valueType.Name, value);
                }
                else
                {
                    sb.AppendFormat("{0}={1}", key, value);
                }
            }

            sb.Append("}");
            return sb.ToString();
        }

        [Obsolete("Use DictionaryToString() instead.")]
        public static string HashtableToString(Hashtable hash)
        {
            return DictionaryToString((IDictionary)hash);
        }

        /// <summary>
        /// Inserts the number's value into the byte array, using Big-Endian order (a.k.a. Network-byte-order).
        /// </summary>
        /// <param name="buffer">Byte array to write into.</param>
        /// <param name="index">Index of first position to write to.</param>
        /// <param name="number">Number to write.</param>
        [Obsolete("Use Protocol.Serialize() instead.")]
        public static void NumberToByteArray(byte[] buffer, int index, short number)
        {
            Protocol.Serialize(number, buffer, ref index);
        }

        /// <summary>
        /// Inserts the number's value into the byte array, using Big-Endian order (a.k.a. Network-byte-order).
        /// </summary>
        /// <param name="buffer">Byte array to write into.</param>
        /// <param name="index">Index of first position to write to.</param>
        /// <param name="number">Number to write.</param>
        [Obsolete("Use Protocol.Serialize() instead.")]
        public static void NumberToByteArray(byte[] buffer, int index, int number)
        {
            Protocol.Serialize(number, buffer, ref index);
        }

        /// <summary>
        /// Converts a byte-array to string (useful as debugging output).
        /// Uses BitConverter.ToString(list) internally after a null-check of list.
        /// </summary>
        /// <param name="list">Byte-array to convert to string.</param>
        /// <returns>
        /// List of bytes as string.
        /// </returns>
        public static string ByteArrayToString(byte[] list)
        {
            if (list == null)
            {
                return string.Empty;
            }

            return BitConverter.ToString(list);
        }

        /// <summary>
        /// Class to wrap static access to the random.Next() call in a thread safe manner.
        /// </summary>
        public class ThreadSafeRandom
        {
            private static readonly Random _r = new Random();

            public static int Next()
            {
                lock (_r)
                {
                    return _r.Next();
                }
            }
        }
    }
}