﻿#define NO_NAMESERVER
using ExitGames.Client.Photon;
using System;
using System.Collections.Generic;
using System.Linq;

namespace TurnbasedConsole
{
    using System.Collections;
    using System.Diagnostics;
    using System.Diagnostics.CodeAnalysis;
    using System.Threading;
    using ExitGames.Client.Photon.LoadBalancing;

    internal class ConsoleCommand
    {
        public string Name { get; set; }
        public string Note { get; set; }
        public Action Handler { get; set; }
        public HashSet<ClientState> PreconditionStates { get; set; }
    }

    class SavedGameInfo
    {
        public string Name { get; set; }
        public int ActorNr { get; set; }
        public Dictionary<string, object> Properties { get; set; }

        public override string ToString()
        {
            return string.Format("Saved Game: '{0}' actor: {1} customProps: {2}", this.Name, this.ActorNr, SupportClass.DictionaryToString(this.Properties));
        }
    }

    class TurnbasedConsoleClient : LoadBalancingClient
    {
        #region ...
        private List<SavedGameInfo> savedGamesList = new List<SavedGameInfo>();
        private string playerNr = (System.Diagnostics.Process.GetProcessesByName(
                System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location)).Count() - 1).ToString();

        static void Main(string[] args)
        {
            new TurnbasedConsoleClient().Run();
        }
        #endregion

        private RoomOptions myRoomOptions = new RoomOptions()
        {
            IsVisible = true,
            IsOpen = true,
            MaxPlayers = 0,
            PlayerTtl = 0,
            EmptyRoomTtl = 0, //29*1000,
            CleanupCacheOnLeave = true,
            CustomRoomProperties = null,
            CustomRoomPropertiesForLobby = null,
            CheckUserOnJoin = true,
        };

        public void GetPlayerNr()
        {
            Console.WriteLine("Enter player #: {0} (= default, press enter)", this.playerNr);
            var input = Console.ReadLine();
            if (!string.IsNullOrEmpty(input))
            {
                this.playerNr = input;
            }
        }

        public TurnbasedConsoleClient()
        {
            this.GetPlayerNr();
            this.AppId = "<your appid>"; // insert your own AppID
            this.AppVersion = "client-x.y.z";

            this.UserId = "MyUserId" + this.playerNr;
            this.NickName = "MyPlayer" + this.playerNr;

            this.OnStateChangeAction += this.OnStateChanged;

#if NO_NAMESERVER
            this.NameServerHost = "";
            this.MasterServerAddress = "localhost:5055"; // change ip:port if required
#else

#endif

            this.loadBalancingPeer.DebugOut = DebugLevel.WARNING; // set your prefered debug log level
        }

        public void Start()
        {
            if (!string.IsNullOrEmpty(this.NameServerHost))
            {
                Console.WriteLine("connecting to:{0} as:{1}", this.NameServerAddress, this.PlayerName);

                if (!this.ConnectToRegionMaster("EU"))
                {
                    this.DebugReturn(DebugLevel.ERROR, "Can't connect to NameServer: " + this.NameServerAddress);
                }
            }
            else
            {
                Console.WriteLine("connecting to:{0} as:{1}", this.MasterServerAddress, this.PlayerName);

                if (!this.Connect())
                {
                    this.DebugReturn(DebugLevel.ERROR, "Can't connect to MasterServer: " + this.MasterServerAddress);
                }
            }
        }

        bool done = false;
        void Run()
        {
            this.Start();
            Thread thread = new Thread(this.UpdateLoop); // windows forms are event based. we need a game loop despite this
            thread.IsBackground = true; // a background thread automatically ends when the app ends
            thread.Start();

            while (!done)
            {
                Thread.Sleep(500);
            }
        }

        string roomname = "MyRoom1";
        int actorNr = 0;
        string data = string.Empty;

        [SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1115:ParameterMustFollowComma", Justification = "Reviewed. Suppression is OK here.")]
        [SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1117:ParametersMustBeOnSameLineOrSeparateLines", Justification = "Reviewed. Suppression is OK here.")]
        private void UpdateLoop(object obj)
        {
            var commandKey = string.Empty;
            var keybuffer = string.Empty;

            myRoomOptions.PlayerTtl = int.MaxValue;
            myRoomOptions.MaxPlayers = 4;
            myRoomOptions.IsOpen = true;
            myRoomOptions.IsVisible = true;
            myRoomOptions.CustomRoomProperties = new Hashtable
                                                     {
                                                         { "prop1Key", "prop1Val" },
                                                         { "prop2Key", "prop2Val" },
                                                         { "lobby3Key", "lobby3Val" },
                                                         { "lobby4Key", "lobby4Val" },
                                                         { "map_name", "mymap" },
                                                     };
            myRoomOptions.CustomRoomPropertiesForLobby = new string[] { "lobby3Key", "lobby4Key" };
            //myRoomOptions.Plugins = new string[] { "Webhooks" };
            myRoomOptions.CheckUserOnJoin = true;

            var commandCollection = new Dictionary<string, ConsoleCommand>();
            commandCollection.Add(
                "h",
                new ConsoleCommand
                {
                    Name = "Help",
                    PreconditionStates = new HashSet<ClientState> { },
                    Handler = () =>
                    {
                        Console.WriteLine("-");
                        foreach (var cmd in commandCollection)
                        {
                            Console.WriteLine("{0}\t| {1} {2}", cmd.Key, cmd.Value.Name, cmd.Value.Note);
                        }
                        Console.WriteLine("-");
                    }
                });
            commandCollection.Add(
                "sa",
                new ConsoleCommand
                {
                    Name = "Set Actor",
                    Note = ": actornr as int",
                    PreconditionStates = new HashSet<ClientState> { },
                    Handler = () =>
                    {
                        int.TryParse(data, out this.actorNr);
                        Console.WriteLine("set to room:{0} actor#:{1}", roomname, this.actorNr);
                    }
                });
            commandCollection.Add(
                "sr",
                new ConsoleCommand
                {
                    Name = "Set Room",
                    Note = ": roomname",
                    PreconditionStates = new HashSet<ClientState> { },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            roomname = data;
                        }
                        Console.WriteLine("set to room:{0} actor#:{1}", roomname, this.actorNr);
                    }
                });

            commandCollection.Add(
                "c",
                new ConsoleCommand
                {
                    Name = "Create Room",
                    Note = ": roomname",
                    PreconditionStates = new HashSet<ClientState> { ClientState.JoinedLobby },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            roomname = data;
                        }

                        if (!LocalPlayer.CustomProperties.ContainsKey("player_id"))
                            LocalPlayer.CustomProperties.Add("player_id", "12345");
                        //LocalPlayer.SetCustomProperties(new Hashtable() { { } });
                        this.OpCreateRoom(roomname, myRoomOptions, this.CurrentLobby);
                    }
                });
            commandCollection.Add(
                "j",
                new ConsoleCommand
                {
                    Name = "Join Room",
                    Note = ": roomname",
                    PreconditionStates = new HashSet<ClientState> { ClientState.JoinedLobby },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            roomname = data;
                        }
                        Console.WriteLine("joining room:{0} with actor#:{1}", roomname, this.actorNr);

                        // actorNumber: 0 => means we reall only want to join 
                        this.OpJoinRoom(roomName: roomname, actorNumber: 0);
                    }
                });
            commandCollection.Add(
                "jrr",
                new ConsoleCommand
                {
                    Name = "Join Random Room",
                    Note = ": roomname",
                    PreconditionStates = new HashSet<ClientState> { ClientState.JoinedLobby },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            roomname = data;
                        }
                        Console.WriteLine("joining random room:{0} with actor#:{1}", roomname, this.actorNr);

                        this.OpJoinRandomRoom(null, myRoomOptions.MaxPlayers);
                    }
                });
            commandCollection.Add(
                "joc",
                new ConsoleCommand
                {
                    Name = "Join Or Create Room",
                    Note = ": roomname",
                    PreconditionStates = new HashSet<ClientState> { ClientState.JoinedLobby },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            roomname = data;
                        }
                        Console.WriteLine("joinorcreate room:{0}", roomname);

                        this.OpJoinOrCreateRoom(roomName: roomname, roomOptions: myRoomOptions, lobby: TypedLobby.Default);
                    }
                });
            commandCollection.Add(
                "jr",
                new ConsoleCommand
                {
                    Name = "Re-Join Room",
                    Note = ": roomname",
                    PreconditionStates = new HashSet<ClientState> { ClientState.JoinedLobby },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            roomname = data;
                        }
                        Console.WriteLine("re-joining room:{0}", roomname);

                        // actor!=0 means rejoin // setting it to -1 means the server selects the actor by userid Note: it only works with room property checkuser=true)
                        this.OpJoinRoom(roomName: roomname, actorNumber: -1);
                    }
                });
            commandCollection.Add(
                "sro",
                new ConsoleCommand
                {
                    Name = "Set Room isOpen",
                    Note = ": true|false",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            bool result;
                            if (bool.TryParse(data, out result))
                            {
                                this.CurrentRoom.IsOpen = result;
                                this.Service();
                                Console.WriteLine(this.CurrentRoom.ToString());
                            }
                        }
                    }
                });
            commandCollection.Add(
                "srv",
                new ConsoleCommand
                {
                    Name = "Set Room isVisible",
                    Note = ": true|false",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            bool result;
                            if (bool.TryParse(data, out result))
                            {
                                this.CurrentRoom.IsVisible = result;
                                this.Service();
                                Console.WriteLine(this.CurrentRoom.ToString());
                            }
                        }
                    }
                });
            commandCollection.Add(
                "llr",
                new ConsoleCommand
                {
                    Name = "List Lobby Rooms",
                    PreconditionStates = new HashSet<ClientState> { },
                    Handler = () =>
                    {
                        this.ListLobbyRoomsToConsole();
                    }
                });
            commandCollection.Add(
                "lsg",
                new ConsoleCommand
                {
                    Name = "List Saved Games",
                    PreconditionStates = new HashSet<ClientState> { },
                    Handler = () =>
                    {
                        this.ListSavedGamesToConsole();
                    }
                });
            commandCollection.Add(
                "gsg",
                new ConsoleCommand
                {
                    Name = "Get Saved Games",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined, ClientState.JoinedLobby },
                    Handler = () =>
                    {
                        //this.OpWebRpc("GetGameList?getpar1=1&getpar2=xyz", new Dictionary<string, object>() { { "p1", "one" }, { "p2", "two" } });
                        //this.OpWebRpc("GetGameList?getpar1=1&getpar2=xyz", new int[] { 1, 2, 3 });
                        this.OpWebRpc("GetGameList?getpar1=1&getpar2=xyz", null);
                    }
                });
            commandCollection.Add(
                "d",
                new ConsoleCommand
                {
                    Name = "Disconnect",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        this.loadBalancingPeer.Disconnect();
                    }
                });
            commandCollection.Add(
                "l",
                new ConsoleCommand
                {
                    Name = "Leave",
                    Note = "(abandon)",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        this.loadBalancingPeer.OpLeaveRoom(false);
                        //this.loadBalancingPeer.OpCustom(OperationCode.Leave, null, true);
                    }
                });
            commandCollection.Add(
                "q",
                new ConsoleCommand
                {
                    Name = "Quit",
                    PreconditionStates = new HashSet<ClientState> { },
                    Handler = () =>
                    {
                        this.Disconnect(); 
                        Thread.Sleep(1000);
                        done = true;
                    }
                });
            commandCollection.Add(
                "ce",
                new ConsoleCommand
                {
                    Name = "Cached Event",
                    Note = "(not forwarded) : event as string",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            //cached event
                            this.loadBalancingPeer.OpRaiseEvent((byte) 0, data, true, new RaiseEventOptions() { CachingOption = EventCaching.AddToRoomCache });

                            //var op = new OperationRequest()
                            //{
                            //    OperationCode = OperationCode.RaiseEvent,
                            //    Parameters =
                            //        new Dictionary<byte, object>()
                            //                         {
                            //                             { ParameterCode.Code, (byte)0 },
                            //                             { ParameterCode.Data, data },
                            //                             //{ ParameterCode.ActorList, this.CurrentRoom.Players.Keys.ToArray() }, //<<< not compatible with AddToRoomCache
                            //                             { ParameterCode.Cache, EventCaching.AddToRoomCache },
                            //                             //{ (byte)ParameterCode.EventForward, true },
                            //                             { ParameterCode.ReceiverGroup, (byte)ReceiverGroup.Others }
                            //                         }
                            //};
                            //this.loadBalancingPeer.OpCustom(op, true, 0, false);
                        }
                    }
                });
            commandCollection.Add(
                "fe",
                new ConsoleCommand
                {
                    Name = "Forward Event ",
                    Note = "(non-cached) : event as string",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            // forward / non-cached event
                            var op = new OperationRequest()
                            {
                                OperationCode = OperationCode.RaiseEvent,
                                Parameters =
                                    new Dictionary<byte, object>()
                                {
                                    { ParameterCode.Code, (byte)0 },
                                    {
                                        ParameterCode.Data, data
                                    },
                                    { ParameterCode.ActorList, this.CurrentRoom.Players.Keys.ToArray() },
                                    { ParameterCode.Cache, EventCaching.DoNotCache },
                                    { (byte)ParameterCode.EventForward, true },
                                }
                            };
                            this.loadBalancingPeer.OpCustom(op, true, 0, false);
                        }
                    }
                });
            commandCollection.Add(
                "sii",
                new ConsoleCommand
                {
                    Name = "Slice Increase Index",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        var op = new OperationRequest()
                        {
                            OperationCode = OperationCode.RaiseEvent,
                            Parameters =
                                new Dictionary<byte, object>() { { ParameterCode.Cache, EventCaching.SliceIncreaseIndex }, }
                        };
                        this.loadBalancingPeer.OpCustom(op, true, 0, false);
                    }
                });
            commandCollection.Add(
                "ssi",
                new ConsoleCommand
                {
                    Name = "Slice Set Index",
                    Note = ": index as int",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            var op = new OperationRequest()
                            {
                                OperationCode = OperationCode.RaiseEvent,
                                Parameters =
                                    new Dictionary<byte, object>()
                                                     {
                                                         { ParameterCode.Cache, EventCaching.SliceSetIndex },
                                                         { ParameterCode.CacheSliceIndex, int.Parse(data) },
                                                     }
                            };
                            this.loadBalancingPeer.OpCustom(op, true, 0, false);
                        }
                    }
                });
            commandCollection.Add(
                "spi",
                new ConsoleCommand
                {
                    Name = "Slice Purge Index",
                    Note = ": index as int",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            var op = new OperationRequest()
                            {
                                OperationCode = OperationCode.RaiseEvent,
                                Parameters =
                                    new Dictionary<byte, object>()
                                                     {
                                                         { ParameterCode.Cache, EventCaching.SlicePurgeIndex },
                                                         { ParameterCode.CacheSliceIndex, int.Parse(data) },
                                                     }
                            };
                            this.loadBalancingPeer.OpCustom(op, true, 0, false);
                        }
                    }
                });
            commandCollection.Add(
                "spu",
                new ConsoleCommand
                {
                    Name = "Slice Purge Up To Index",
                    Note = ": index as int",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined },
                    Handler = () =>
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            var op = new OperationRequest()
                            {
                                OperationCode = OperationCode.RaiseEvent,
                                Parameters =
                                    new Dictionary<byte, object>()
                                                     {
                                                         { ParameterCode.Cache, EventCaching.SlicePurgeUpToIndex },
                                                         { ParameterCode.CacheSliceIndex, int.Parse(data) },
                                                     }
                            };
                            this.loadBalancingPeer.OpCustom(op, true, 0, false);
                        }
                    }
                });
            commandCollection.Add(
                "spt",
                new ConsoleCommand
                {
                    Name = "Set Property Turn",
                    Note = ": actornr as int",
                    PreconditionStates = new HashSet<ClientState> { },
                    Handler = () =>
                    {
                        Dictionary<byte, object> opParameters = new Dictionary<byte, object>();
                        opParameters.Add(ParameterCode.Properties, new Hashtable()
                                                                           {
                                                                               { "turn", 1 }, //<<< expects actornr to sent push to
                                                                               { "lobby3Key", "test1a" }, 
                                                                               { "lobby4Key", "test1b" },
                                                                           });
                        opParameters.Add(ParameterCode.Broadcast, true);
                        opParameters.Add(ParameterCode.EventForward, true);

                        this.loadBalancingPeer.OpCustom((byte)OperationCode.SetProperties, opParameters, true, 0, false);
                    }
                });

            commandCollection.Add(
                "ac",
                new ConsoleCommand
                {
                    Name = "WebRpc with AuthCookie",
                    PreconditionStates = new HashSet<ClientState> { ClientState.Joined, ClientState.JoinedLobby },
                    Handler = () =>
                    {
                        Dictionary<byte, object> opParameters = new Dictionary<byte, object>();
                        opParameters.Add(ParameterCode.UriPath, "check-authcookie");
                        opParameters.Add(ParameterCode.WebRpcParameters, new int[] { 1, 2, 3 });
                        opParameters.Add(ParameterCode.EventForward, (byte)0x02);

                        this.loadBalancingPeer.OpCustom(OperationCode.WebRpc, opParameters, true);
                    }
                });

            //commandCollection.Add(
            //    "",
            //    new ConsoleCommand
            //    {
            //        nickName = "",
            //        PreconditionStates = new HashSet<ClientState> { },
            //        Handler = () =>
            //        {
            //        }
            //    });

            Console.WriteLine("-");
            foreach (var cmd in commandCollection)
            {
                Console.WriteLine("{0}\t| {1} {2}", cmd.Key, cmd.Value.Name, cmd.Value.Note);
            }
            Console.WriteLine("-");
            Console.WriteLine("\nFor help (list of all available commands see above) press: h<ENTER>");
            Console.WriteLine("Note: commands and parameteres are entered in one line separated trough ':',\nfor example c:myroom<ENTER> will create a room with name 'myroom'.\n");
            Console.WriteLine("------------------------ continuing to connect ...");

            var separator = new[] { ':' };
            while (!done)
            {
                while (this.loadBalancingPeer.DispatchIncomingCommands())
                {
                    // You could count dispatch calls to limit them to X, if they take too much time of a single frame
                }

                while (Console.KeyAvailable)
                {
                    var key = Console.ReadKey();
                    if (Char.IsLetterOrDigit(key.KeyChar) || key.KeyChar == ':' || key.Key == ConsoleKey.Enter)
                    {
                        if (key.Key == ConsoleKey.Enter)
                        {
                            var line = keybuffer.Split(separator, 2);
                            if (line.Length > 0)
                            {
                                commandKey = line[0];
                                if (line.Length > 1)
                                {
                                    data = line[1];
                                }
                            }

                            keybuffer = string.Empty;
                            break;
                        }
                        keybuffer += key.KeyChar;
                    }
                }

                if (!string.IsNullOrEmpty(commandKey))
                {
                    if (commandCollection.ContainsKey(commandKey))
                    {
                        var cmd = commandCollection[commandKey];

                        Console.WriteLine(">>> {0}:", cmd.Name);
                        if (cmd.PreconditionStates.Count == 0 || (cmd.PreconditionStates.Count > 0 && cmd.PreconditionStates.Contains(this.State)))
                        {
                            cmd.Handler();
                        }
                        else
                        {
                            Console.Write("'{0}' - only allowed in state(s):", cmd.Name);
                            foreach (var state in cmd.PreconditionStates)
                            {
                                Console.Write(" {0}", state);
                            }
                            Console.WriteLine();
                        }

                    }
                    else
                    {
                        Console.WriteLine(">>Unknown command={0} (data={1})", commandKey, data);
                    }
                }

                commandKey = string.Empty;
                data = string.Empty;
                this.loadBalancingPeer.SendOutgoingCommands();

                Thread.Sleep(50);
            }
        }

        private void OnStateChanged(ClientState clientState)
        {
            switch (clientState)
            {
                case ClientState.ConnectingToNameServer:
                    Console.WriteLine("State: {0} - {1}", clientState, this.NameServerAddress);
                    break;
                case ClientState.ConnectingToMasterserver:
                    Console.WriteLine("State: {0} - {1}", clientState, this.MasterServerAddress);
                    break;
                case ClientState.ConnectingToGameserver:
                    Console.WriteLine("State: {0} - {1}", clientState, this.CurrentServerAddress);
                    break;
                case ClientState.ConnectedToNameServer:
                    Console.WriteLine("State: {0}", clientState);
                    if (string.IsNullOrEmpty(this.CloudRegion))
                    {
                        this.OpGetRegions();
                    }
                    break;
                case ClientState.ConnectedToGameserver:
                    Console.WriteLine("State: {0}", clientState);
                    break;
                case ClientState.ConnectedToMaster:
                    Console.WriteLine("State: {0}", clientState);
                    //this.OpJoinLobby("mylobbyX", LobbyType.Default);
                    break;
            }
        }

        public override void OnOperationResponse(OperationResponse operationResponse)
        {
            base.OnOperationResponse(operationResponse);  // important to call, to keep state up to date

            if (operationResponse.ReturnCode != ErrorCode.Ok)
            {
                this.DebugReturn(DebugLevel.ERROR, operationResponse.ToStringFull() + " " + this.State);
            }

            switch (operationResponse.OperationCode)
            {
                case OperationCode.Authenticate:
                    if (operationResponse.ReturnCode == 0)
                    {
                        //var data = (Dictionary<string, object>)operationResponse.Parameters[ParameterCode.Data];
                        //var boolVal = (bool)data["key1"];
                        //var intVal = (int)data["key2"];
                        //var doubleVal = (double)data["key3"];
                        //var stringVal = (string)data["key4"];
                        //var arrayVal = (object[])data["key5"];
                        //var subObject = (Dictionary<string, object>)data["key6"];
                    }
                    break;

                case OperationCode.JoinRandomGame:
                    break;

                case OperationCode.JoinGame:
                case OperationCode.CreateGame:
                    if (this.State == ClientState.Joined)
                    {
                        this.actorNr = (int)operationResponse.Parameters[ParameterCode.ActorNr];
                    }
                    break;

                case OperationCode.WebRpc:

                    if (operationResponse.ReturnCode != 0)
                    {
                        DebugReturn(DebugLevel.ERROR, "WebRpc failed. Response: " + operationResponse.ToStringFull());
                    }
                    else
                    {
                        WebRpcResponse webResponse = new WebRpcResponse(operationResponse);
                        this.OnWebRpcResponse(webResponse);
                    }
                    break;
            }
        }

        public void OnWebRpcResponse(WebRpcResponse webResponse)
        {
            if (webResponse.ReturnCode != 0)
            {
                DebugReturn(
                    DebugLevel.ERROR,
                    "WebRpc '" + webResponse.Name + "' failed. Error: " + webResponse.ReturnCode + " Message: " + webResponse.DebugMessage);
                return;
            }

            switch (webResponse.Name)
            {
                case "GetGameList":
                    this.savedGamesList = new List<SavedGameInfo>();

                    var data = webResponse.Parameters;
                    if (data != null)
                    {
                        foreach (var item in data)
                        {
                            var gameInfo = new SavedGameInfo { Name = item.Key, ActorNr = -1, Properties = new Dictionary<string, object>() };
                            var listItem = item.Value as Dictionary<string, object>;
                            if (listItem != null)
                            {
                                gameInfo.ActorNr = (int)listItem["ActorNr"];
                                if (listItem.ContainsKey("Properties")) gameInfo.Properties = (Dictionary<string, object>)listItem["Properties"];
                            }
                            this.savedGamesList.Add(gameInfo);
                        }
                    }

                    this.ListSavedGamesToConsole();
                    break;
                default:
                    var result = string.Format("WebRpc Response Name={0} Params: '{1}",webResponse.Name, SupportClass.DictionaryToString(webResponse.Parameters));
                    this.DebugReturn(DebugLevel.INFO, result);
                    break;
            }
        }

        private void ListSavedGamesToConsole()
        {
            if (this.savedGamesList.Count > 0)
            {
                foreach (var gameInfo in this.savedGamesList)
                {
                    Console.WriteLine(gameInfo.ToString());
                }
            }
            else
            {
                Console.WriteLine(@"N\A - empty list");
            }
        }

        public override void OnEvent(EventData photonEvent)
        {
            //Console.WriteLine("\n---EventAction: " + photonEvent.Code);

            // most events have a sender / origin (but not all) - let's find the player sending this
            int actorNr = 0;
            if (photonEvent.Parameters.ContainsKey(ParameterCode.ActorNr))
            {
                actorNr = (int)photonEvent[ParameterCode.ActorNr];  // actorNr (a.k.a. playerNumber / ID) of sending player
            }

            base.OnEvent(photonEvent);  // important to call, to keep state up to date

            switch (photonEvent.Code)
            {
                case 0:
                    Console.WriteLine("e[{0}]: {1}", actorNr, (string)photonEvent[ParameterCode.CustomEventContent]);
                    break;

                case EventCode.Join:
                    Console.WriteLine("a[{0}]: {1}", actorNr, "joined");
                    break;
                case EventCode.Leave:
                    Console.WriteLine("a[{0}]: {1}", actorNr, "left");
                    break;

                case EventCode.GameList:
                case EventCode.GameListUpdate:
                    //Console.WriteLine("Event GameListUpdate: {0}", SupportClass.DictionaryToString(photonEvent.Parameters));                    
                    //this.ListLobbyRoomsToConsole();
                    break;

                case EventCode.AppStats:
                    //Console.WriteLine("PlayersInRoom#={0} Rooms#={1} PlayersOnMaster#={2}", this.PlayersInRoomsCount, this.RoomsCount, this.PlayersOnMasterCount);
                    break;
                case EventCode.CacheSliceChanged:
                    Console.WriteLine("SliceIndexChanged: {0}", (int)photonEvent[ParameterCode.CacheSliceIndex]);
                    break;
            }
        }

        private void ListLobbyRoomsToConsole()
        {
            if (this.RoomInfoList.Count > 0)
            {
                Console.WriteLine("--Lobby:");
                foreach (var roominfo in this.RoomInfoList.Values)
                {
                    Console.WriteLine(roominfo.ToString());
                }
            }
            else
            {
                Console.WriteLine(@"N\A - empty list");
            }
        }

        public override void OnStatusChanged(StatusCode statusCode)
        {
            base.OnStatusChanged(statusCode);  // important to call, to keep state up to date

            Console.WriteLine("StatusCode: {0}", statusCode);

            if (statusCode == StatusCode.Disconnect && this.DisconnectedCause != DisconnectCause.None)
            {
                DebugReturn(DebugLevel.ERROR, this.DisconnectedCause + " caused a disconnect. State: " + this.State + " statusCode: " + statusCode + ".");
            }
        }

        public override void DebugReturn(DebugLevel level, string message)
        {
            base.DebugReturn(level, message);

            Console.WriteLine(message);
        }
    }
}
